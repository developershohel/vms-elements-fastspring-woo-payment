( function ( config ) {
	'use strict';

	config = config || {};

	var i18nStrings = config.i18n || {};

	function t( key, fallback ) {
		return i18nStrings[ key ] || fallback;
	}

	function formatMessage( template, values ) {
		var output = template;
		var index;
		if ( ! values || ! values.length ) {
			return output;
		}
		for ( index = 0; index < values.length; index++ ) {
			output = output.replace( new RegExp( '%' + ( index + 1 ) + '\\$s', 'g' ), values[ index ] );
		}
		return output;
	}

	var state = {
		current: null,
		opened: false,
		pending: false,
	};

	function log( msg ) {
		if ( window.console && config.debug ) {
			console.info( '[VMS FastSpring Shortcode]', msg );
		}
	}

	function ready() {
		return (
			window.fastspring &&
			window.fastspring.builder &&
			typeof window.fastspring.builder.checkout === 'function'
		);
	}

	function whenBuilderReady( callback, maxTries ) {
		var tries = 0;
		var limit = maxTries || 150;

		if ( ready() ) {
			callback();
			return;
		}

		var timer = setInterval( function () {
			tries += 1;
			if ( ready() ) {
				clearInterval( timer );
				callback();
			} else if ( tries >= limit ) {
				clearInterval( timer );
				callback( new Error( t( 'loadFailed', 'FastSpring Store Builder did not load.' ) ) );
			}
		}, 100 );
	}

	function appendQueryParam( url, key, value ) {
		try {
			var target = new URL( url, window.location.origin );
			target.searchParams.set( key, value );
			return target.toString();
		} catch ( e ) {
			var join = url.indexOf( '?' ) === -1 ? '?' : '&';
			return url + join + encodeURIComponent( key ) + '=' + encodeURIComponent( value );
		}
	}

	function resolveRedirect( redirect ) {
		if ( ! redirect ) {
			return '';
		}
		try {
			return new URL( redirect, window.location.origin ).toString();
		} catch ( e ) {
			return redirect;
		}
	}

	function activateOverlayShell() {
		if (
			window.VMS_EFWP_OverlayApi &&
			typeof window.VMS_EFWP_OverlayApi.activate === 'function'
		) {
			window.VMS_EFWP_OverlayApi.activate();
		} else {
			document.documentElement.classList.add( 'vms-efwp-checkout-active' );
		}
	}

	function deactivateOverlayShell() {
		if (
			window.VMS_EFWP_OverlayApi &&
			typeof window.VMS_EFWP_OverlayApi.deactivate === 'function'
		) {
			window.VMS_EFWP_OverlayApi.deactivate();
		} else {
			document.documentElement.classList.remove( 'vms-efwp-checkout-active' );
		}
	}

	function mountOverlayShell() {
		if (
			window.VMS_EFWP_OverlayApi &&
			typeof window.VMS_EFWP_OverlayApi.mount === 'function'
		) {
			window.VMS_EFWP_OverlayApi.mount();
		}
	}

	function showError( message ) {
		state.opened = false;
		state.pending = false;
		state.current = null;
		deactivateOverlayShell();
		window.alert( message || t( 'error', 'FastSpring checkout could not open.' ) );
	}

	function openCheckout( payload ) {
		if ( ! payload || ! payload.productPath ) {
			return;
		}

		if ( state.opened || state.pending ) {
			return;
		}

		if ( ! config.popupStorefront ) {
			showError( t( 'error', 'FastSpring checkout could not open.' ) );
			return;
		}

		state.pending = true;
		state.current = payload;
		activateOverlayShell();

		whenBuilderReady( function ( err ) {
			state.pending = false;

			if ( err ) {
				showError( err.message );
				return;
			}

			try {
				state.opened = true;
				if ( typeof window.fastspring.builder.reset === 'function' ) {
					window.fastspring.builder.reset();
				}

				if ( typeof window.fastspring.builder.push === 'function' ) {
					window.fastspring.builder.push( {
						reset: true,
						products: [
							{
								path: payload.productPath,
								quantity: payload.quantity || 1,
							},
						],
					} );
				}

				window.fastspring.builder.checkout();
				mountOverlayShell();
				setTimeout( mountOverlayShell, 100 );
				setTimeout( mountOverlayShell, 500 );
			} catch ( e ) {
				showError( e && e.message ? e.message : t( 'error', 'FastSpring checkout could not open.' ) );
			}
		} );
	}

	function finishCheckout( orderReference ) {
		var payload = state.current;
		state.opened = false;
		state.pending = false;
		state.current = null;
		deactivateOverlayShell();

		if (
			window.fastspring &&
			window.fastspring.builder &&
			typeof window.fastspring.builder.reset === 'function'
		) {
			try {
				window.fastspring.builder.reset();
			} catch ( e ) {
				// Ignore reset errors.
			}
		}

		if ( ! payload ) {
			return;
		}

		if ( orderReference && orderReference.id ) {
			var redirect = resolveRedirect( payload.redirect || config.defaultRedirect || '' );
			if ( redirect ) {
				window.location.replace(
					appendQueryParam( redirect, 'fs_order', orderReference.id )
				);
				return;
			}
		}

		if ( ! orderReference || ! orderReference.id ) {
			log( t( 'checkoutClosed', 'Checkout closed without completing payment.' ) );
		}
	}

	window.VMS_EFWP_ShortcodePopupClosed = function ( orderReference ) {
		finishCheckout( orderReference );
	};

	window.VMS_EFWP_ShortcodeErrorCallback = function ( code, message ) {
		log( formatMessage( t( 'sblError', 'SBL error: %1$s — %2$s' ), [ code, message ] ) );
		if ( window.console && window.console.error ) {
			console.error( '[VMS FastSpring Shortcode]', code, message );
		}
		showError( message || t( 'error', 'FastSpring checkout could not open.' ) );
	};

	document.addEventListener( 'click', function ( event ) {
		var trigger = event.target.closest( '.vms-efwp-shortcode-trigger' );
		if ( ! trigger || state.opened || state.pending ) {
			return;
		}

		event.preventDefault();

		openCheckout( {
			productPath: trigger.getAttribute( 'data-product-path' ) || '',
			quantity: parseInt( trigger.getAttribute( 'data-quantity' ) || '1', 10 ) || 1,
			redirect: trigger.getAttribute( 'data-redirect' ) || '',
		} );
	} );
}( window.VMS_EFWP_Shortcode || {} ) );
