<?php
/**
 * Invoices screen.
 *
 * @package VMS_EFWP
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class VMS_EFWP_Admin_Invoices.
 */
class VMS_EFWP_Admin_Invoices {

	/**
	 * Render screen.
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$tab  = VMS_EFWP_Admin_Resource_Base::get_filter_key( 'tab', 'receipts' );
		$tabs = array(
			'receipts' => __( 'Order Receipts', 'vms-elements-fastspring-woo-payment-pro' ),
			'lookup'   => __( 'Lookup', 'vms-elements-fastspring-woo-payment-pro' ),
			'create'   => __( 'Create Invoice', 'vms-elements-fastspring-woo-payment-pro' ),
		);
		if ( ! isset( $tabs[ $tab ] ) ) {
			$tab = 'receipts';
		}
		$base = admin_url( 'admin.php?page=vms-efwp-invoices' );

		echo '<div class="wrap vms-efwp-wrap">';
		VMS_EFWP_Admin_Resource_Base::render_header(
			__( 'Invoices', 'vms-elements-fastspring-woo-payment-pro' ),
			__( 'View checkout order receipts and manage FastSpring payment invoices.', 'vms-elements-fastspring-woo-payment-pro' ),
			array(
				'<a class="button button-primary" href="' . esc_url( add_query_arg( 'tab', 'create', $base ) ) . '">' . esc_html__( 'Create invoice', 'vms-elements-fastspring-woo-payment-pro' ) . '</a>',
			)
		);

		if ( ! VMS_EFWP_Admin_Resource_Base::require_credentials() ) {
			echo '</div>';
			return;
		}

		if ( VMS_EFWP_Admin_Resource_Base::is_post_submit( 'vms_efwp_resend_invoice' ) && VMS_EFWP_Admin_Resource_Base::verify_post( 'vms_efwp_resend_invoice' ) ) {
			self::handle_resend_invoice();
		}

		if ( 'create' === $tab && VMS_EFWP_Admin_Resource_Base::is_post_submit( 'vms_efwp_create_invoice' ) && VMS_EFWP_Admin_Resource_Base::verify_post( 'vms_efwp_create_invoice' ) ) {
			self::handle_create_invoice();
		}

		VMS_EFWP_Admin_Resource_Base::render_nav_tabs( $tabs, $tab, $base );

		if ( 'create' === $tab ) {
			self::render_create_form();
		} elseif ( 'lookup' === $tab ) {
			self::render_lookup();
		} else {
			self::render_order_receipts();
		}

		VMS_EFWP_Admin_Resource_Base::render_json_modal();
		echo '</div>';
	}

	/**
	 * Handle POST create invoice.
	 */
	private static function handle_create_invoice() {
		$payload = self::build_invoice_payload_from_post();
		if ( is_wp_error( $payload ) ) {
			VMS_EFWP_Admin_Resource_Base::render_result_notice( $payload );
			return;
		}

		$result = vms_efwp()->api->create_payment_invoice( $payload );
		if ( is_wp_error( $result ) ) {
			VMS_EFWP_Admin_Resource_Base::render_result_notice( $result );
			return;
		}

		VMS_EFWP_Admin_Resource_Base::render_result_notice( $result );
		self::render_invoice_links_notice( $result );

		if ( ! empty( $result['id'] ) ) {
			printf(
				'<p><a class="button" href="%s">%s</a></p>',
				esc_url(
					add_query_arg(
						array(
							'page'       => 'vms-efwp-invoices',
							'tab'        => 'lookup',
							'invoice_id' => $result['id'],
						),
						admin_url( 'admin.php' )
					)
				),
				esc_html__( 'View invoice details', 'vms-elements-fastspring-woo-payment-pro' )
			);
		}
	}

	/**
	 * Handle resend invoice POST requests.
	 */
	public static function handle_resend_invoice() {
		$fs_order_id = VMS_EFWP_Admin_Resource_Base::post_text( 'fs_order_id' );
		$invoice_id  = VMS_EFWP_Admin_Resource_Base::post_text( 'invoice_id' );
		$recipient   = VMS_EFWP_Admin_Resource_Base::post_email( 'recipient_email' );

		if ( $fs_order_id ) {
			$result = vms_efwp()->api->resend_order_invoice_email( $fs_order_id, $recipient );
		} elseif ( $invoice_id ) {
			$result = vms_efwp()->api->resend_payment_invoice_email( $invoice_id, $recipient );
		} else {
			$result = new WP_Error(
				'vms_efwp_invoice_resend',
				__( 'Missing order or invoice ID for resend.', 'vms-elements-fastspring-woo-payment-pro' )
			);
		}

		VMS_EFWP_Admin_Resource_Base::render_result_notice( $result );
	}

	/**
	 * Render a resend-invoice submit button.
	 *
	 * @param array $args Button args.
	 */
	public static function render_resend_invoice_button( $args ) {
		$args = wp_parse_args(
			$args,
			array(
				'fs_order_id'     => '',
				'invoice_id'      => '',
				'recipient_email' => '',
				'page'            => 'vms-efwp-invoices',
				'tab'             => 'receipts',
				'label'           => __( 'Resend', 'vms-elements-fastspring-woo-payment-pro' ),
				'class'           => 'button button-small',
			)
		);

		if ( empty( $args['fs_order_id'] ) && empty( $args['invoice_id'] ) ) {
			return;
		}

		$form_action = add_query_arg(
			array(
				'page' => (string) $args['page'],
				'tab'  => (string) $args['tab'],
			),
			admin_url( 'admin.php' )
		);
		?>
		<form method="post" class="vms-efwp-inline-form" action="<?php echo esc_url( $form_action ); ?>">
			<?php wp_nonce_field( 'vms_efwp_resend_invoice' ); ?>
			<input type="hidden" name="vms_efwp_resend_invoice" value="1" />
			<?php if ( ! empty( $args['fs_order_id'] ) ) : ?>
				<input type="hidden" name="fs_order_id" value="<?php echo esc_attr( (string) $args['fs_order_id'] ); ?>" />
			<?php endif; ?>
			<?php if ( ! empty( $args['invoice_id'] ) ) : ?>
				<input type="hidden" name="invoice_id" value="<?php echo esc_attr( (string) $args['invoice_id'] ); ?>" />
			<?php endif; ?>
			<?php if ( ! empty( $args['recipient_email'] ) ) : ?>
				<input type="hidden" name="recipient_email" value="<?php echo esc_attr( (string) $args['recipient_email'] ); ?>" />
			<?php endif; ?>
			<button type="submit" class="<?php echo esc_attr( (string) $args['class'] ); ?>"><?php echo esc_html( (string) $args['label'] ); ?></button>
		</form>
		<?php
	}

	/**
	 * Build InvoiceRequest payload from POST fields.
	 *
	 * @return array|WP_Error
	 */
	private static function build_invoice_payload_from_post() {
		$currency = strtoupper( VMS_EFWP_Admin_Resource_Base::post_text( 'currency_code', 'USD' ) );
		$email    = VMS_EFWP_Admin_Resource_Base::post_email( 'bill_email' );
		$first    = VMS_EFWP_Admin_Resource_Base::post_text( 'bill_first_name' );
		$last     = VMS_EFWP_Admin_Resource_Base::post_text( 'bill_last_name' );

		if ( ! $email || ! $first || ! $last ) {
			return new WP_Error(
				'vms_efwp_invoice_validation',
				__( 'Bill-to email, first name, and last name are required.', 'vms-elements-fastspring-woo-payment-pro' )
			);
		}

		$items = self::parse_invoice_items_from_post();
		if ( empty( $items ) ) {
			return new WP_Error(
				'vms_efwp_invoice_validation',
				__( 'At least one invoice line item is required.', 'vms-elements-fastspring-woo-payment-pro' )
			);
		}

		$bill_contact = array(
			'contactType' => 'billTo',
			'contact'     => array_filter(
				array(
					'email'       => $email,
					'firstName'   => $first,
					'lastName'    => $last,
					'companyName' => VMS_EFWP_Admin_Resource_Base::post_text( 'bill_company' ),
					'phoneNumber' => VMS_EFWP_Admin_Resource_Base::post_text( 'bill_phone' ),
				)
			),
		);

		$bill_address = self::build_address_from_post( 'bill_' );
		if ( ! empty( $bill_address ) ) {
			$bill_contact['address'] = $bill_address;
		}

		$contacts = array( $bill_contact );

		if ( VMS_EFWP_Admin_Resource_Base::post_text( 'same_as_bill_to' ) ) {
			$deliver_contact = $bill_contact;
			$deliver_contact['contactType'] = 'deliverTo';
			$contacts[]                     = $deliver_contact;
		} else {
			$deliver_email = VMS_EFWP_Admin_Resource_Base::post_email( 'deliver_email' );
			$deliver_first = VMS_EFWP_Admin_Resource_Base::post_text( 'deliver_first_name' );
			$deliver_last  = VMS_EFWP_Admin_Resource_Base::post_text( 'deliver_last_name' );
			if ( $deliver_email && $deliver_first && $deliver_last ) {
				$deliver_contact = array(
					'contactType' => 'deliverTo',
					'contact'     => array_filter(
						array(
							'email'       => $deliver_email,
							'firstName'   => $deliver_first,
							'lastName'    => $deliver_last,
							'companyName' => VMS_EFWP_Admin_Resource_Base::post_text( 'deliver_company' ),
							'phoneNumber' => VMS_EFWP_Admin_Resource_Base::post_text( 'deliver_phone' ),
						)
					),
				);
				$deliver_address = self::build_address_from_post( 'deliver_' );
				if ( ! empty( $deliver_address ) ) {
					$deliver_contact['address'] = $deliver_address;
				}
				$contacts[] = $deliver_contact;
			}
		}

		$payload = array(
			'currencyCode'   => $currency,
			'contacts'       => $contacts,
			'invoiceItems'   => $items,
			'paymentMethod'  => VMS_EFWP_Admin_Resource_Base::post_text( 'payment_method', 'CARD' ),
			'mode'           => vms_efwp()->settings->is_sandbox() ? 'TEST' : 'LIVE',
			'languageCode'   => VMS_EFWP_Admin_Resource_Base::post_text( 'language_code', 'en' ),
			'invoiceNote'    => VMS_EFWP_Admin_Resource_Base::post_textarea( 'invoice_note' ),
		);

		if ( VMS_EFWP_Admin_Resource_Base::post_text( 'auto_convert_currency' ) ) {
			$payload['autoConvertPaymentCurrency'] = true;
		}

		$due_date = VMS_EFWP_Admin_Resource_Base::post_text( 'due_date' );
		if ( $due_date ) {
			$payload['dueDate'] = gmdate( 'Y-m-d\TH:i:s\Z', strtotime( $due_date . ' UTC' ) );
		}

		$tags_json = trim( VMS_EFWP_Admin_Resource_Base::post_textarea( 'tags_json' ) );
		if ( $tags_json ) {
			$decoded = json_decode( $tags_json, true );
			if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $decoded ) ) {
				return new WP_Error(
					'vms_efwp_invoice_validation',
					__( 'Tags JSON must be a valid JSON object string.', 'vms-elements-fastspring-woo-payment-pro' )
				);
			}
			$payload['tagsJson'] = wp_json_encode( $decoded );
		}

		return array_filter(
			$payload,
			static function ( $value ) {
				return null !== $value && '' !== $value;
			}
		);
	}

	/**
	 * Parse invoice line items from POST.
	 *
	 * @return array
	 */
	private static function parse_invoice_items_from_post() {
		$items        = array();
		$product_path = VMS_EFWP_Admin_Resource_Base::post_text( 'product_path' );
		$quantity     = max( 1, VMS_EFWP_Admin_Resource_Base::post_int( 'quantity', 1 ) );

		if ( $product_path ) {
			$use_catalog = VMS_EFWP_Admin_Resource_Base::post_bool( 'use_catalog_pricing', true );

			$items[] = array_filter(
				array(
					'productPath'             => $product_path,
					'quantity'                => $quantity,
					'useCatalogPricing'       => $use_catalog,
					'sku'                     => VMS_EFWP_Admin_Resource_Base::post_text( 'sku' ),
					'display'                 => VMS_EFWP_Admin_Resource_Base::post_text( 'item_display' ),
					'summary'                 => VMS_EFWP_Admin_Resource_Base::post_text( 'item_summary' ),
					'extendedItemDescription' => VMS_EFWP_Admin_Resource_Base::post_textarea( 'item_description' ),
				),
				static function ( $value ) {
					return null !== $value && '' !== $value;
				}
			);
		}

		$extra = VMS_EFWP_Admin_Resource_Base::post_text( 'additional_products' );
		if ( $extra ) {
			foreach ( array_filter( array_map( 'trim', explode( ',', $extra ) ) ) as $path_qty ) {
				$parts = array_map( 'trim', explode( ':', $path_qty ) );
				$path  = $parts[0] ?? '';
				$qty   = isset( $parts[1] ) ? max( 1, (int) $parts[1] ) : 1;
				if ( $path ) {
					$items[] = array(
						'productPath'       => $path,
						'quantity'          => $qty,
						'useCatalogPricing' => true,
					);
				}
			}
		}

		return $items;
	}

	/**
	 * Build an address array from prefixed POST fields.
	 *
	 * @param string $prefix Field prefix (e.g. bill_).
	 * @return array
	 */
	private static function build_address_from_post( $prefix ) {
		return array_filter(
			array(
				'addressLine1' => VMS_EFWP_Admin_Resource_Base::post_text( $prefix . 'address_line1' ),
				'addressLine2' => VMS_EFWP_Admin_Resource_Base::post_text( $prefix . 'address_line2' ),
				'city'         => VMS_EFWP_Admin_Resource_Base::post_text( $prefix . 'city' ),
				'region'       => VMS_EFWP_Admin_Resource_Base::post_text( $prefix . 'region' ),
				'postalCode'   => VMS_EFWP_Admin_Resource_Base::post_text( $prefix . 'postal_code' ),
				'country'      => strtoupper( VMS_EFWP_Admin_Resource_Base::post_text( $prefix . 'country' ) ),
			)
		);
	}

	/**
	 * Render create invoice form.
	 */
	private static function render_create_form() {
		?>
		<div class="vms-efwp-card">
			<h2><?php esc_html_e( 'Create payment invoice', 'vms-elements-fastspring-woo-payment-pro' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Creates and finalizes a payment invoice via POST /invoices/paymentInvoice.', 'vms-elements-fastspring-woo-payment-pro' ); ?></p>
			<form method="post">
				<?php wp_nonce_field( 'vms_efwp_create_invoice' ); ?>
				<input type="hidden" name="vms_efwp_create_invoice" value="1" />

				<h3><?php esc_html_e( 'Invoice', 'vms-elements-fastspring-woo-payment-pro' ); ?></h3>
				<div class="vms-efwp-grid vms-efwp-grid--two">
					<p><label><?php esc_html_e( 'Currency', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="currency_code" maxlength="3" value="USD" class="regular-text" required /></label></p>
					<p><label><?php esc_html_e( 'Language', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="language_code" value="en" class="regular-text" /></label></p>
					<p>
						<label><?php esc_html_e( 'Payment method', 'vms-elements-fastspring-woo-payment-pro' ); ?><br />
							<select name="payment_method">
								<?php foreach ( array( 'CARD', 'PAYPAL', 'WIRE', 'ACH' ) as $method ) : ?>
									<option value="<?php echo esc_attr( $method ); ?>" <?php selected( 'CARD', $method ); ?>><?php echo esc_html( $method ); ?></option>
								<?php endforeach; ?>
							</select>
						</label>
					</p>
					<p><label><?php esc_html_e( 'Due date', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="date" name="due_date" class="regular-text" /></label></p>
					<p><label><input type="checkbox" name="auto_convert_currency" value="1" checked /> <?php esc_html_e( 'Auto-convert payment currency', 'vms-elements-fastspring-woo-payment-pro' ); ?></label></p>
				</div>
				<p><label><?php esc_html_e( 'Invoice note', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><textarea name="invoice_note" rows="2" class="large-text"></textarea></label></p>
				<p><label><?php esc_html_e( 'Tags JSON', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><textarea name="tags_json" rows="2" class="large-text" placeholder='{"purchaseOrder":"PO-123"}'></textarea></label></p>

				<h3><?php esc_html_e( 'Bill to', 'vms-elements-fastspring-woo-payment-pro' ); ?></h3>
				<div class="vms-efwp-grid vms-efwp-grid--two">
					<p><label><?php esc_html_e( 'Email', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="email" name="bill_email" required class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'Company', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="bill_company" class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'First name', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="bill_first_name" required class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'Last name', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="bill_last_name" required class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'Phone', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="bill_phone" class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'Address line 1', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="bill_address_line1" class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'City', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="bill_city" class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'Region', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="bill_region" class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'Postal code', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="bill_postal_code" class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'Country', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="bill_country" maxlength="2" placeholder="US" class="regular-text" /></label></p>
				</div>

				<h3><?php esc_html_e( 'Deliver to', 'vms-elements-fastspring-woo-payment-pro' ); ?></h3>
				<p><label><input type="checkbox" name="same_as_bill_to" value="1" checked /> <?php esc_html_e( 'Same as bill to', 'vms-elements-fastspring-woo-payment-pro' ); ?></label></p>
				<div class="vms-efwp-grid vms-efwp-grid--two" data-vms-efwp-deliver-fields hidden>
					<p><label><?php esc_html_e( 'Email', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="email" name="deliver_email" class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'Company', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="deliver_company" class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'First name', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="deliver_first_name" class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'Last name', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="deliver_last_name" class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'Phone', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="deliver_phone" class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'Address line 1', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="deliver_address_line1" class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'City', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="deliver_city" class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'Region', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="deliver_region" class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'Postal code', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="deliver_postal_code" class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'Country', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="deliver_country" maxlength="2" placeholder="US" class="regular-text" /></label></p>
				</div>

				<h3><?php esc_html_e( 'Line items', 'vms-elements-fastspring-woo-payment-pro' ); ?></h3>
				<div class="vms-efwp-grid vms-efwp-grid--two">
					<p><label><?php esc_html_e( 'Product path', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="product_path" required class="regular-text" placeholder="sample-product" /></label></p>
					<p><label><?php esc_html_e( 'Quantity', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="number" name="quantity" min="1" value="1" class="small-text" /></label></p>
					<p><label><input type="checkbox" name="use_catalog_pricing" value="1" checked /> <?php esc_html_e( 'Use catalog pricing', 'vms-elements-fastspring-woo-payment-pro' ); ?></label></p>
					<p><label><?php esc_html_e( 'SKU', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="sku" class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'Display name', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="item_display" class="regular-text" /></label></p>
					<p><label><?php esc_html_e( 'Summary', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="item_summary" class="regular-text" /></label></p>
				</div>
				<p><label><?php esc_html_e( 'Extended description', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><textarea name="item_description" rows="2" class="large-text"></textarea></label></p>
				<p><label><?php esc_html_e( 'Additional products', 'vms-elements-fastspring-woo-payment-pro' ); ?><br /><input type="text" name="additional_products" class="large-text" placeholder="addon-product:2, another-product" /></label></p>
				<p class="description"><?php esc_html_e( 'Optional comma-separated product paths. Use path:quantity for custom quantities.', 'vms-elements-fastspring-woo-payment-pro' ); ?></p>

				<p><button class="button button-primary"><?php esc_html_e( 'Create invoice', 'vms-elements-fastspring-woo-payment-pro' ); ?></button></p>
			</form>
		</div>
		<?php
	}

	/**
	 * Tab: order receipts generated automatically by FastSpring checkout.
	 */
	private static function render_order_receipts() {
		$page     = max( 1, VMS_EFWP_Admin_Resource_Base::get_filter_int( 'paged', 1 ) );
		$search   = VMS_EFWP_Admin_Resource_Base::get_filter_text( 's' );
		$per_page = 20;

		$result = VMS_EFWP_Data_Store::get_orders(
			array(
				'page'       => $page,
				'per_page'   => $per_page,
				'search'     => $search,
				'status'     => 'completed',
				'scope_site' => true,
			)
		);

		$total_pages = max( 1, (int) ceil( $result['total'] / $per_page ) );
		?>
		<div class="notice notice-info inline">
			<p>
				<?php
				echo esc_html__(
					'FastSpring checkout receipts are tied to the order ID (for example 35sB9iMvR6q-no5XKBsq8A), not a separate invoices API ID. This list shows completed orders; use Lookup with the order ID to open the receipt. Manual B2B invoices created via Create Invoice do have a payment invoice ID.',
					'vms-elements-fastspring-woo-payment-pro'
				);
				?>
			</p>
		</div>

		<form method="get" class="vms-efwp-filters">
			<input type="hidden" name="page" value="vms-efwp-invoices" />
			<input type="hidden" name="tab" value="receipts" />
			<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search order, email, invoice ID...', 'vms-elements-fastspring-woo-payment-pro' ); ?>" />
			<button class="button"><?php esc_html_e( 'Filter', 'vms-elements-fastspring-woo-payment-pro' ); ?></button>
		</form>

		<table class="widefat striped vms-efwp-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Order', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
					<th><?php esc_html_e( 'Customer', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
					<th><?php esc_html_e( 'Total', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
					<th><?php esc_html_e( 'Receipt / Invoice ID', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
					<th><?php esc_html_e( 'Date', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
					<th><?php esc_html_e( 'Actions', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php if ( empty( $result['rows'] ) ) : ?>
				<tr>
					<td colspan="6">
						<?php
						esc_html_e(
							'No completed orders stored yet. Place a checkout order or save one from FastSpring → Orders → Lookup, then return here.',
							'vms-elements-fastspring-woo-payment-pro'
						);
						?>
					</td>
				</tr>
			<?php else : ?>
				<?php foreach ( $result['rows'] as $row ) : ?>
					<?php
					$display     = VMS_EFWP_Data_Store::get_order_invoice_display( $row );
					$invoice_url = $display['invoice_url'];
					$pdf_url     = $invoice_url ? untrailingslashit( $invoice_url ) . '/pdf' : '';
					$lookup_url  = add_query_arg(
						array(
							'tab'        => 'lookup',
							'invoice_id' => $display['lookup_id'],
						),
						admin_url( 'admin.php?page=vms-efwp-invoices' )
					);
					?>
					<tr>
						<td>
							<strong><?php echo esc_html( $row['fs_order_id'] ); ?></strong>
							<?php if ( (int) $row['is_test'] ) : ?>
								<span class="vms-efwp-badge vms-efwp-badge--warning"><?php esc_html_e( 'TEST', 'vms-elements-fastspring-woo-payment-pro' ); ?></span>
							<?php endif; ?>
						</td>
						<td>
							<?php echo esc_html( $row['customer_name'] ); ?>
							<div class="row-actions"><?php echo esc_html( $row['email'] ); ?></div>
						</td>
						<td><?php echo esc_html( trim( ( $row['currency'] ?? '' ) . ' ' . number_format_i18n( (float) $row['total'], 2 ) ) ); ?></td>
						<td>
							<div><span class="description"><?php esc_html_e( 'Order ID', 'vms-elements-fastspring-woo-payment-pro' ); ?>:</span> <code><?php echo esc_html( $display['order_id'] ); ?></code></div>
							<?php if ( ! empty( $display['payment_invoice_id'] ) ) : ?>
								<div><span class="description"><?php esc_html_e( 'Payment invoice ID', 'vms-elements-fastspring-woo-payment-pro' ); ?>:</span> <code><?php echo esc_html( $display['payment_invoice_id'] ); ?></code></div>
							<?php endif; ?>
							<?php if ( ! empty( $display['order_reference'] ) ) : ?>
								<div class="row-actions"><span class="description"><?php esc_html_e( 'Reference', 'vms-elements-fastspring-woo-payment-pro' ); ?>:</span> <?php echo esc_html( $display['order_reference'] ); ?></div>
							<?php elseif ( ! empty( $display['receipt_reference'] ) ) : ?>
								<div class="row-actions"><span class="description"><?php esc_html_e( 'Receipt ref', 'vms-elements-fastspring-woo-payment-pro' ); ?>:</span> <?php echo esc_html( $display['receipt_reference'] ); ?></div>
							<?php endif; ?>
							<?php if ( ! $invoice_url ) : ?>
								<div class="row-actions"><?php esc_html_e( 'Receipt URL not stored yet', 'vms-elements-fastspring-woo-payment-pro' ); ?></div>
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( mysql2date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $row['created_at'] ) ); ?></td>
						<td>
							<a class="button button-small" href="<?php echo esc_url( $lookup_url ); ?>"><?php esc_html_e( 'Lookup', 'vms-elements-fastspring-woo-payment-pro' ); ?></a>
							<?php if ( $invoice_url ) : ?>
								<a class="button button-small" href="<?php echo esc_url( $invoice_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'View', 'vms-elements-fastspring-woo-payment-pro' ); ?></a>
								<a class="button button-small" href="<?php echo esc_url( $pdf_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'PDF', 'vms-elements-fastspring-woo-payment-pro' ); ?></a>
							<?php endif; ?>
							<?php
							if ( ( $invoice_url || $display['order_id'] ) && ! empty( $row['email'] ) ) {
								self::render_resend_invoice_button(
									array(
										'fs_order_id'     => $row['fs_order_id'],
										'invoice_id'      => $display['payment_invoice_id'],
										'recipient_email' => $row['email'],
										'tab'             => 'receipts',
									)
								);
							}
							?>
						</td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
			</tbody>
		</table>

		<?php
		if ( $total_pages > 1 ) {
			$base_url = add_query_arg(
				array(
					'page' => 'vms-efwp-invoices',
					'tab'  => 'receipts',
					's'    => $search,
				),
				admin_url( 'admin.php' )
			);
			echo wp_kses_post(
				'<div class="tablenav"><div class="tablenav-pages">' . paginate_links(
					array(
						'base'    => add_query_arg( 'paged', '%#%', $base_url ),
						'format'  => '',
						'current' => $page,
						'total'   => $total_pages,
					)
				) . '</div></div>'
			);
		}
	}

	/**
	 * Lookup a single invoice.
	 */
	private static function render_lookup() {
		$lookup_id = VMS_EFWP_Admin_Resource_Base::get_filter_text( 'invoice_id' );
		VMS_EFWP_Admin_Resource_Base::render_lookup_form(
			'vms-efwp-invoices',
			'invoice_id',
			__( 'Invoice or Order ID', 'vms-elements-fastspring-woo-payment-pro' ),
			__( 'Payment invoice ID or FastSpring order ID', 'vms-elements-fastspring-woo-payment-pro' ),
			$lookup_id,
			array( 'tab' => 'lookup' )
		);
		if ( ! $lookup_id ) {
			printf(
				'<p class="description">%s</p>',
				esc_html__( 'Payment invoices use GET /invoices/{invoiceId}. Checkout order receipts use the order ID via GET /orders/{orderId} and the invoiceUrl field — not the invoices API.', 'vms-elements-fastspring-woo-payment-pro' )
			);
			return;
		}

		$result = vms_efwp()->api->lookup_invoice_resource( $lookup_id );
		if ( is_wp_error( $result ) ) {
			VMS_EFWP_Admin_Resource_Base::render_result_notice( $result );
			return;
		}

		if ( 'order_receipt' === ( $result['type'] ?? '' ) ) {
			self::render_order_receipt_lookup( $lookup_id, $result['data'], $result['invoice_meta'] ?? array() );
			return;
		}

		$invoice = $result['data'];
		self::render_invoice_summary( $invoice );
		self::render_invoice_links_notice( $invoice );
		$recipient = (string) ( $invoice['purchaser']['email'] ?? ( $invoice['receiver']['email'] ?? '' ) );
		?>
		<div class="vms-efwp-card vms-efwp-card--actions">
			<?php
			self::render_resend_invoice_button(
				array(
					'invoice_id'      => $lookup_id,
					'recipient_email' => $recipient,
					'tab'             => 'lookup',
					'label'           => __( 'Resend invoice email', 'vms-elements-fastspring-woo-payment-pro' ),
					'class'           => 'button',
				)
			);
			?>
			<p class="description">
				<?php
				echo esc_html__(
					'Sends invoice links to the customer from your WordPress site. FastSpring branded receipt emails must still be resent from the FastSpring order dashboard.',
					'vms-elements-fastspring-woo-payment-pro'
				);
				?>
			</p>
		</div>
		<?php
		VMS_EFWP_Admin_Resource_Base::render_api_detail_card( $invoice, __( 'Invoice details', 'vms-elements-fastspring-woo-payment-pro' ) );
	}

	/**
	 * Render checkout order receipt details resolved from an order ID lookup.
	 *
	 * @param string $order_id     FastSpring order ID.
	 * @param array  $order        Order payload.
	 * @param array  $invoice_meta Invoice URL metadata.
	 */
	private static function render_order_receipt_lookup( $order_id, $order, $invoice_meta ) {
		$customer = $order['customer'] ?? array();
		$email    = $customer['email'] ?? ( $order['email'] ?? '' );
		$name     = trim( ( $customer['first'] ?? $customer['firstName'] ?? '' ) . ' ' . ( $customer['last'] ?? $customer['lastName'] ?? '' ) );
		$currency = (string) ( $order['currency'] ?? '' );
		$total    = (float) ( $order['total'] ?? 0 );
		$status   = ! empty( $order['completed'] ) ? 'completed' : ( $order['status'] ?? 'pending' );
		$view_url = $invoice_meta['invoice_url'] ?? '';
		$pdf_url  = $view_url ? untrailingslashit( $view_url ) . '/pdf' : '';
		$payment_invoice_id = (string) ( $invoice_meta['fs_invoice_id'] ?? '' );
		if ( '' === $payment_invoice_id && function_exists( 'vms_efwp' ) && vms_efwp()->api ) {
			$extracted = vms_efwp()->api->extract_order_invoice_meta( $order );
			$payment_invoice_id = (string) ( $extracted['fs_invoice_id'] ?? '' );
		}
		?>
		<div class="notice notice-info inline">
			<p>
				<?php
				echo esc_html__(
					'This is a checkout order receipt, not a manual payment invoice. FastSpring stores the receipt on the order object (invoiceUrl), so GET /invoices returns not found for order IDs.',
					'vms-elements-fastspring-woo-payment-pro'
				);
				?>
			</p>
		</div>

		<div class="vms-efwp-card vms-efwp-card--wide">
			<h2><?php esc_html_e( 'Order receipt', 'vms-elements-fastspring-woo-payment-pro' ); ?></h2>
			<table class="widefat striped vms-efwp-table vms-efwp-table--meta">
				<tbody>
					<tr><th><?php esc_html_e( 'Order ID', 'vms-elements-fastspring-woo-payment-pro' ); ?></th><td><code><?php echo esc_html( $order_id ); ?></code></td></tr>
					<?php if ( $payment_invoice_id ) : ?>
						<tr><th><?php esc_html_e( 'Receipt invoice ID', 'vms-elements-fastspring-woo-payment-pro' ); ?></th><td><code><?php echo esc_html( $payment_invoice_id ); ?></code></td></tr>
					<?php endif; ?>
					<tr><th><?php esc_html_e( 'Reference', 'vms-elements-fastspring-woo-payment-pro' ); ?></th><td><?php echo esc_html( (string) ( $order['reference'] ?? '' ) ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Status', 'vms-elements-fastspring-woo-payment-pro' ); ?></th><td><span class="vms-efwp-status vms-efwp-status--<?php echo esc_attr( sanitize_key( (string) $status ) ); ?>"><?php echo esc_html( (string) $status ); ?></span></td></tr>
					<tr><th><?php esc_html_e( 'Customer', 'vms-elements-fastspring-woo-payment-pro' ); ?></th><td><?php echo esc_html( $name ); ?><?php if ( $email ) : ?><div class="row-actions"><?php echo esc_html( $email ); ?></div><?php endif; ?></td></tr>
					<tr><th><?php esc_html_e( 'Total', 'vms-elements-fastspring-woo-payment-pro' ); ?></th><td><?php echo esc_html( trim( $currency . ' ' . number_format_i18n( $total, 2 ) ) ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Receipt URL', 'vms-elements-fastspring-woo-payment-pro' ); ?></th><td><?php echo $view_url ? '<a href="' . esc_url( $view_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $view_url ) . '</a>' : '&mdash;'; ?></td></tr>
				</tbody>
			</table>
		</div>

		<?php if ( $view_url ) : ?>
			<div class="vms-efwp-card vms-efwp-card--actions">
				<a class="button button-primary" href="<?php echo esc_url( $view_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'View receipt', 'vms-elements-fastspring-woo-payment-pro' ); ?></a>
				<a class="button" href="<?php echo esc_url( $pdf_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Download PDF', 'vms-elements-fastspring-woo-payment-pro' ); ?></a>
				<?php
				if ( $email ) {
					self::render_resend_invoice_button(
						array(
							'fs_order_id'     => $order_id,
							'recipient_email' => $email,
							'tab'             => 'lookup',
							'label'           => __( 'Resend receipt email', 'vms-elements-fastspring-woo-payment-pro' ),
							'class'           => 'button',
						)
					);
				}
				?>
			</div>
		<?php else : ?>
			<div class="notice notice-warning inline">
				<p><?php esc_html_e( 'This order does not include an invoiceUrl yet. It may still be pending or incomplete.', 'vms-elements-fastspring-woo-payment-pro' ); ?></p>
			</div>
		<?php endif; ?>

		<?php
		printf(
			'<p><a class="button" href="%s">%s</a></p>',
			esc_url(
				add_query_arg(
					array(
						'page'     => 'vms-efwp-orders',
						'tab'      => 'lookup',
						'order_id' => $order_id,
					),
					admin_url( 'admin.php' )
				)
			),
			esc_html__( 'Open full order lookup', 'vms-elements-fastspring-woo-payment-pro' )
		);

		VMS_EFWP_Admin_Resource_Base::render_api_detail_card( $order, __( 'Order details', 'vms-elements-fastspring-woo-payment-pro' ) );
	}

	/**
	 * Render invoice summary table.
	 *
	 * @param array $invoice Invoice object.
	 */
	private static function render_invoice_summary( $invoice ) {
		$status   = $invoice['status'] ?? '';
		$currency = $invoice['currency'] ?? ( $invoice['paymentCurrencyCode'] ?? '' );
		$total    = $invoice['totalOrderValue'] ?? ( $invoice['paymentTotals']['payableTotal'] ?? 0 );
		$bill_to  = $invoice['purchaser']['email'] ?? '';
		$ship_to  = $invoice['receiver']['email'] ?? '';
		?>
		<div class="vms-efwp-card vms-efwp-card--wide">
			<h2><?php esc_html_e( 'Invoice summary', 'vms-elements-fastspring-woo-payment-pro' ); ?></h2>
			<table class="widefat striped vms-efwp-table vms-efwp-table--meta">
				<tbody>
					<tr><th><?php esc_html_e( 'Invoice ID', 'vms-elements-fastspring-woo-payment-pro' ); ?></th><td><code><?php echo esc_html( $invoice['id'] ?? '' ); ?></code></td></tr>
					<tr><th><?php esc_html_e( 'Status', 'vms-elements-fastspring-woo-payment-pro' ); ?></th><td><span class="vms-efwp-status vms-efwp-status--<?php echo esc_attr( strtolower( $status ) ); ?>"><?php echo esc_html( $status ); ?></span></td></tr>
					<tr><th><?php esc_html_e( 'Type', 'vms-elements-fastspring-woo-payment-pro' ); ?></th><td><?php echo esc_html( $invoice['invoiceType'] ?? '' ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Order reference', 'vms-elements-fastspring-woo-payment-pro' ); ?></th><td><?php echo esc_html( $invoice['orderReference'] ?? ( $invoice['paymentOrderReference'] ?? '' ) ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Total', 'vms-elements-fastspring-woo-payment-pro' ); ?></th><td><?php echo esc_html( trim( $currency . ' ' . number_format_i18n( (float) $total, 2 ) ) ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Created', 'vms-elements-fastspring-woo-payment-pro' ); ?></th><td><?php echo esc_html( $invoice['createdOn'] ?? '' ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Due', 'vms-elements-fastspring-woo-payment-pro' ); ?></th><td><?php echo esc_html( $invoice['dueDate'] ?? ( $invoice['paymentDueDate'] ?? '' ) ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Bill to', 'vms-elements-fastspring-woo-payment-pro' ); ?></th><td><?php echo esc_html( $bill_to ); ?></td></tr>
					<tr><th><?php esc_html_e( 'Deliver to', 'vms-elements-fastspring-woo-payment-pro' ); ?></th><td><?php echo esc_html( $ship_to ); ?></td></tr>
				</tbody>
			</table>

			<?php if ( ! empty( $invoice['items'] ) && is_array( $invoice['items'] ) ) : ?>
				<h3><?php esc_html_e( 'Line items', 'vms-elements-fastspring-woo-payment-pro' ); ?></h3>
				<table class="widefat striped vms-efwp-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Product', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
							<th><?php esc_html_e( 'Display', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
							<th><?php esc_html_e( 'Qty', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
							<th><?php esc_html_e( 'Line total', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $invoice['items'] as $item ) : ?>
							<tr>
								<td><code><?php echo esc_html( $item['productPath'] ?? '' ); ?></code></td>
								<td><?php echo esc_html( $item['display'] ?? '' ); ?></td>
								<td><?php echo esc_html( (string) ( $item['quantity'] ?? 1 ) ); ?></td>
								<td><?php echo esc_html( number_format_i18n( (float) ( $item['totalPreShippingPrice'] ?? 0 ), 2 ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render payment / PDF links when present.
	 *
	 * @param array $invoice Invoice object.
	 */
	private static function render_invoice_links_notice( $invoice ) {
		$links = array_filter(
			array(
				'paymentInvoiceWebPayLink' => __( 'Pay invoice', 'vms-elements-fastspring-woo-payment-pro' ),
				'paymentInvoiceWebLink'    => __( 'View invoice', 'vms-elements-fastspring-woo-payment-pro' ),
				'paymentInvoicePdfLink'    => __( 'Download PDF', 'vms-elements-fastspring-woo-payment-pro' ),
			),
			static function ( $label, $key ) use ( $invoice ) {
				return ! empty( $invoice[ $key ] );
			},
			ARRAY_FILTER_USE_BOTH
		);

		if ( empty( $links ) ) {
			return;
		}
		?>
		<div class="vms-efwp-card vms-efwp-card--actions">
			<?php foreach ( $links as $key => $label ) : ?>
				<a class="button" href="<?php echo esc_url( $invoice[ $key ] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
		</div>
		<?php
	}
}
