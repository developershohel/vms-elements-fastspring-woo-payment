<?php
/**
 * Shortcode builder admin screen.
 *
 * @package VMS_EFWP
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class VMS_EFWP_Admin_Shortcodes.
 */
class VMS_EFWP_Admin_Shortcodes {

	/**
	 * Render screen.
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		echo '<div class="wrap vms-efwp-wrap">';
		VMS_EFWP_Admin_Resource_Base::render_header(
			__( 'Shortcodes', 'vms-elements-fastspring-woo-payment-pro' ),
			__( 'Build overlay checkout buttons for products and subscriptions.', 'vms-elements-fastspring-woo-payment-pro' )
		);

		if ( ! VMS_EFWP_Admin_Resource_Base::require_credentials() ) {
			echo '</div>';
			return;
		}

		$settings = vms_efwp()->settings;
		if ( ! $settings->has_popup_checkout() ) {
			printf(
				'<div class="notice notice-warning"><p>%s <a href="%s">%s</a></p></div>',
				esc_html__( 'Popup checkout is not configured yet. Shortcodes open the FastSpring overlay checkout and require a popup checkout path.', 'vms-elements-fastspring-woo-payment-pro' ),
				esc_url( admin_url( 'admin.php?page=vms-efwp-settings' ) ),
				esc_html__( 'Open settings', 'vms-elements-fastspring-woo-payment-pro' )
			);
		}

		$tab = VMS_EFWP_Admin_Resource_Base::get_filter_key( 'tab', 'product' );
		if ( ! in_array( $tab, array( 'product', 'subscription' ), true ) ) {
			$tab = 'product';
		}

		$base_url = admin_url( 'admin.php?page=vms-efwp-shortcodes' );
		VMS_EFWP_Admin_Resource_Base::render_nav_tabs(
			array(
				'product'      => __( 'Product shortcode', 'vms-elements-fastspring-woo-payment-pro' ),
				'subscription' => __( 'Subscription shortcode', 'vms-elements-fastspring-woo-payment-pro' ),
			),
			$tab,
			$base_url
		);

		$products = self::load_catalog_products( 'subscription' === $tab );
		self::render_builder( $tab, $products );
		self::render_reference( $tab );

		echo '</div>';
	}

	/**
	 * Load catalog products for the picker.
	 *
	 * @param bool $subscriptions_only Whether to return subscription products only.
	 * @return array
	 */
	private static function load_catalog_products( $subscriptions_only ) {
		$api  = vms_efwp()->api;
		$list = $api->list_products();
		if ( is_wp_error( $list ) ) {
			VMS_EFWP_Admin_Resource_Base::render_result_notice( $list );
			return array();
		}

		$paths = $api->extract_product_paths( $list );
		if ( empty( $paths ) ) {
			return array();
		}

		$details = $api->get_products( array_slice( $paths, 0, 100 ) );
		if ( is_wp_error( $details ) ) {
			VMS_EFWP_Admin_Resource_Base::render_result_notice( $details );
			return array();
		}

		$products = $api->parse_products( $details );
		return array_values(
			array_filter(
				$products,
				static function ( $product ) use ( $subscriptions_only ) {
					$is_sub = VMS_EFWP_Admin_Products::is_subscription_product( $product );
					return $subscriptions_only ? $is_sub : ! $is_sub;
				}
			)
		);
	}

	/**
	 * Render the shortcode builder UI.
	 *
	 * @param string $type     product|subscription.
	 * @param array  $products Catalog products.
	 */
	private static function render_builder( $type, $products ) {
		$default_text = 'subscription' === $type
			? __( 'Subscribe now', 'vms-elements-fastspring-woo-payment-pro' )
			: __( 'Buy now', 'vms-elements-fastspring-woo-payment-pro' );
		$shortcode_tag = 'subscription' === $type ? 'fastspring_subscription' : 'fastspring_product';
		?>
		<div class="vms-efwp-card vms-efwp-card--wide vms-efwp-shortcode-builder" data-vms-efwp-shortcode-type="<?php echo esc_attr( $type ); ?>">
			<div class="vms-efwp-card__head">
				<h2><?php echo 'subscription' === $type ? esc_html__( 'Subscription checkout button', 'vms-elements-fastspring-woo-payment-pro' ) : esc_html__( 'Product checkout button', 'vms-elements-fastspring-woo-payment-pro' ); ?></h2>
			</div>

			<div class="vms-efwp-shortcode-builder__grid">
				<div class="vms-efwp-shortcode-builder__form">
					<p>
						<label for="vms-efwp-shortcode-id-<?php echo esc_attr( $type ); ?>">
							<?php esc_html_e( 'Product path', 'vms-elements-fastspring-woo-payment-pro' ); ?>
						</label>
						<select id="vms-efwp-shortcode-id-<?php echo esc_attr( $type ); ?>" class="regular-text vms-efwp-shortcode-field" data-field="id">
							<option value=""><?php esc_html_e( 'Select a catalog item…', 'vms-elements-fastspring-woo-payment-pro' ); ?></option>
							<?php foreach ( $products as $product ) : ?>
								<?php
								$path          = $product['product'] ?? '';
								$display       = $product['display'] ?? array();
								$display_first = is_array( $display ) ? reset( $display ) : (string) $display;
								?>
								<option value="<?php echo esc_attr( $path ); ?>"><?php echo esc_html( $display_first ? $display_first . ' (' . $path . ')' : $path ); ?></option>
							<?php endforeach; ?>
						</select>
					</p>
					<p>
						<label for="vms-efwp-shortcode-id-manual-<?php echo esc_attr( $type ); ?>">
							<?php esc_html_e( 'Or enter path manually', 'vms-elements-fastspring-woo-payment-pro' ); ?>
						</label>
						<input type="text" id="vms-efwp-shortcode-id-manual-<?php echo esc_attr( $type ); ?>" class="regular-text vms-efwp-shortcode-field" data-field="id_manual" placeholder="<?php esc_attr_e( 'e.g. my-product', 'vms-elements-fastspring-woo-payment-pro' ); ?>" />
					</p>
					<p>
						<label for="vms-efwp-shortcode-text-<?php echo esc_attr( $type ); ?>">
							<?php esc_html_e( 'Button text', 'vms-elements-fastspring-woo-payment-pro' ); ?>
						</label>
						<input type="text" id="vms-efwp-shortcode-text-<?php echo esc_attr( $type ); ?>" class="regular-text vms-efwp-shortcode-field" data-field="text" value="<?php echo esc_attr( $default_text ); ?>" />
					</p>
					<p>
						<label for="vms-efwp-shortcode-style-<?php echo esc_attr( $type ); ?>">
							<?php esc_html_e( 'Button style', 'vms-elements-fastspring-woo-payment-pro' ); ?>
						</label>
						<select id="vms-efwp-shortcode-style-<?php echo esc_attr( $type ); ?>" class="regular-text vms-efwp-shortcode-field" data-field="style">
							<?php foreach ( VMS_EFWP_Shortcodes::get_style_presets() as $style ) : ?>
								<option value="<?php echo esc_attr( $style ); ?>" <?php selected( 'primary', $style ); ?>><?php echo esc_html( ucfirst( $style ) ); ?></option>
							<?php endforeach; ?>
						</select>
					</p>
					<p>
						<label for="vms-efwp-shortcode-align-<?php echo esc_attr( $type ); ?>">
							<?php esc_html_e( 'Alignment', 'vms-elements-fastspring-woo-payment-pro' ); ?>
						</label>
						<select id="vms-efwp-shortcode-align-<?php echo esc_attr( $type ); ?>" class="regular-text vms-efwp-shortcode-field" data-field="align">
							<?php foreach ( VMS_EFWP_Shortcodes::get_alignments() as $align ) : ?>
								<option value="<?php echo esc_attr( $align ); ?>" <?php selected( 'left', $align ); ?>><?php echo esc_html( ucfirst( $align ) ); ?></option>
							<?php endforeach; ?>
						</select>
					</p>
					<p>
						<label for="vms-efwp-shortcode-class-<?php echo esc_attr( $type ); ?>">
							<?php esc_html_e( 'Extra CSS class', 'vms-elements-fastspring-woo-payment-pro' ); ?>
						</label>
						<input type="text" id="vms-efwp-shortcode-class-<?php echo esc_attr( $type ); ?>" class="regular-text vms-efwp-shortcode-field" data-field="class" placeholder="<?php esc_attr_e( 'optional', 'vms-elements-fastspring-woo-payment-pro' ); ?>" />
					</p>
					<p>
						<label for="vms-efwp-shortcode-quantity-<?php echo esc_attr( $type ); ?>">
							<?php esc_html_e( 'Quantity', 'vms-elements-fastspring-woo-payment-pro' ); ?>
						</label>
						<input type="number" min="1" id="vms-efwp-shortcode-quantity-<?php echo esc_attr( $type ); ?>" class="small-text vms-efwp-shortcode-field" data-field="quantity" value="1" />
					</p>
					<p>
						<label for="vms-efwp-shortcode-redirect-<?php echo esc_attr( $type ); ?>">
							<?php esc_html_e( 'Redirect after payment', 'vms-elements-fastspring-woo-payment-pro' ); ?>
						</label>
						<input type="text" id="vms-efwp-shortcode-redirect-<?php echo esc_attr( $type ); ?>" class="regular-text vms-efwp-shortcode-field" data-field="redirect" placeholder="<?php echo esc_attr( home_url( '/thank-you/' ) ); ?>" />
						<span class="description">
							<?php
							printf(
								/* translators: %s: default success page URL */
								esc_html__( 'Optional. Leave empty to use the default success page (%s). Custom URLs receive ?fs_order= after payment.', 'vms-elements-fastspring-woo-payment-pro' ),
								esc_html( VMS_EFWP_Payment_Success::get_success_page_url() )
							);
							?>
						</span>
					</p>
					<p>
						<label for="vms-efwp-shortcode-details-<?php echo esc_attr( $type ); ?>">
							<input type="checkbox" id="vms-efwp-shortcode-details-<?php echo esc_attr( $type ); ?>" class="vms-efwp-shortcode-field" data-field="details" value="1" <?php checked( VMS_EFWP_Payment_Success::default_show_details() ); ?> />
							<?php esc_html_e( 'Show payment details on the success page', 'vms-elements-fastspring-woo-payment-pro' ); ?>
						</label>
					</p>

					<div class="vms-efwp-shortcode-style-panel">
						<h3><?php esc_html_e( 'Button styling', 'vms-elements-fastspring-woo-payment-pro' ); ?></h3>
						<div class="vms-efwp-shortcode-style-grid">
							<p>
								<label for="vms-efwp-shortcode-bg-<?php echo esc_attr( $type ); ?>"><?php esc_html_e( 'Background', 'vms-elements-fastspring-woo-payment-pro' ); ?></label>
								<span class="vms-efwp-color-field">
									<input type="color" class="vms-efwp-shortcode-field vms-efwp-shortcode-color" data-field="bg" value="#2271b1" />
									<input type="text" id="vms-efwp-shortcode-bg-<?php echo esc_attr( $type ); ?>" class="regular-text vms-efwp-shortcode-field" data-field="bg" placeholder="#2271b1" />
								</span>
							</p>
							<p>
								<label for="vms-efwp-shortcode-color-<?php echo esc_attr( $type ); ?>"><?php esc_html_e( 'Text color', 'vms-elements-fastspring-woo-payment-pro' ); ?></label>
								<span class="vms-efwp-color-field">
									<input type="color" class="vms-efwp-shortcode-field vms-efwp-shortcode-color" data-field="color" value="#ffffff" />
									<input type="text" id="vms-efwp-shortcode-color-<?php echo esc_attr( $type ); ?>" class="regular-text vms-efwp-shortcode-field" data-field="color" placeholder="#ffffff" />
								</span>
							</p>
							<p>
								<label for="vms-efwp-shortcode-font-size-<?php echo esc_attr( $type ); ?>"><?php esc_html_e( 'Font size', 'vms-elements-fastspring-woo-payment-pro' ); ?></label>
								<input type="text" id="vms-efwp-shortcode-font-size-<?php echo esc_attr( $type ); ?>" class="regular-text vms-efwp-shortcode-field" data-field="font_size" placeholder="16px" />
							</p>
							<p>
								<label for="vms-efwp-shortcode-padding-<?php echo esc_attr( $type ); ?>"><?php esc_html_e( 'Padding', 'vms-elements-fastspring-woo-payment-pro' ); ?></label>
								<input type="text" id="vms-efwp-shortcode-padding-<?php echo esc_attr( $type ); ?>" class="regular-text vms-efwp-shortcode-field" data-field="padding" placeholder="12px 20px" />
							</p>
							<p>
								<label for="vms-efwp-shortcode-margin-<?php echo esc_attr( $type ); ?>"><?php esc_html_e( 'Margin', 'vms-elements-fastspring-woo-payment-pro' ); ?></label>
								<input type="text" id="vms-efwp-shortcode-margin-<?php echo esc_attr( $type ); ?>" class="regular-text vms-efwp-shortcode-field" data-field="margin" placeholder="12px 0" />
							</p>
							<p>
								<label for="vms-efwp-shortcode-border-radius-<?php echo esc_attr( $type ); ?>"><?php esc_html_e( 'Border radius', 'vms-elements-fastspring-woo-payment-pro' ); ?></label>
								<input type="text" id="vms-efwp-shortcode-border-radius-<?php echo esc_attr( $type ); ?>" class="regular-text vms-efwp-shortcode-field" data-field="border_radius" placeholder="6px" />
							</p>
							<p>
								<label for="vms-efwp-shortcode-border-width-<?php echo esc_attr( $type ); ?>"><?php esc_html_e( 'Border width', 'vms-elements-fastspring-woo-payment-pro' ); ?></label>
								<input type="text" id="vms-efwp-shortcode-border-width-<?php echo esc_attr( $type ); ?>" class="regular-text vms-efwp-shortcode-field" data-field="border_width" placeholder="1px" />
							</p>
							<p>
								<label for="vms-efwp-shortcode-border-color-<?php echo esc_attr( $type ); ?>"><?php esc_html_e( 'Border color', 'vms-elements-fastspring-woo-payment-pro' ); ?></label>
								<span class="vms-efwp-color-field">
									<input type="color" class="vms-efwp-shortcode-field vms-efwp-shortcode-color" data-field="border_color" value="#2271b1" />
									<input type="text" id="vms-efwp-shortcode-border-color-<?php echo esc_attr( $type ); ?>" class="regular-text vms-efwp-shortcode-field" data-field="border_color" placeholder="#2271b1" />
								</span>
							</p>
						</div>
					</div>
				</div>

				<div class="vms-efwp-shortcode-builder__output">
					<h3><?php esc_html_e( 'Preview', 'vms-elements-fastspring-woo-payment-pro' ); ?></h3>
					<div class="vms-efwp-shortcode-builder__preview" id="vms-efwp-shortcode-preview-<?php echo esc_attr( $type ); ?>"></div>

					<h3><?php esc_html_e( 'Shortcode', 'vms-elements-fastspring-woo-payment-pro' ); ?></h3>
					<div class="vms-efwp-copy-field">
						<div class="vms-efwp-copy-field__row">
							<input type="text" class="large-text code vms-efwp-shortcode-output" id="vms-efwp-shortcode-output-<?php echo esc_attr( $type ); ?>" readonly value="<?php echo esc_attr( '[' . $shortcode_tag . ' id="" text="' . $default_text . '"]' ); ?>" />
							<button type="button" class="button vms-efwp-copy-shortcode" data-target="#vms-efwp-shortcode-output-<?php echo esc_attr( $type ); ?>"><?php esc_html_e( 'Copy shortcode', 'vms-elements-fastspring-woo-payment-pro' ); ?></button>
						</div>
					</div>

					<p class="description">
						<?php
						printf(
							/* translators: %s: shortcode tag */
							esc_html__( 'Paste the generated shortcode into any page, post, or block. Alias tags also work: %s.', 'vms-elements-fastspring-woo-payment-pro' ),
							esc_html( 'subscription' === $type ? '[fastspring_subscriptions …]' : '[fastspring_products …]' )
						);
						?>
					</p>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render attribute reference.
	 *
	 * @param string $type product|subscription.
	 */
	private static function render_reference( $type ) {
		$tag = 'subscription' === $type ? 'fastspring_subscription' : 'fastspring_product';
		?>
		<div class="vms-efwp-card vms-efwp-card--wide">
			<div class="vms-efwp-card__head">
				<h2><?php esc_html_e( 'Shortcode reference', 'vms-elements-fastspring-woo-payment-pro' ); ?></h2>
			</div>
			<pre class="vms-efwp-json vms-efwp-json--inline">[<?php echo esc_html( $tag ); ?> id="product-path" redirect="/thank-you/" details="1" text="Buy now" style="primary" bg="#2271b1" color="#ffffff" font_size="16px" padding="12px 20px" margin="12px 0" border_radius="6px" align="left" class="my-button" quantity="1"]</pre>
			<ul class="vms-efwp-shortcode-ref">
				<li><code>id</code> — <?php esc_html_e( 'Required. FastSpring catalog product path.', 'vms-elements-fastspring-woo-payment-pro' ); ?></li>
				<li><code>redirect</code> — <?php esc_html_e( 'Optional URL or site path to open after successful payment. Leave empty to use the default success page.', 'vms-elements-fastspring-woo-payment-pro' ); ?></li>
				<li><code>details</code> — <?php esc_html_e( 'Show order details on the default success page: 1/yes or 0/no.', 'vms-elements-fastspring-woo-payment-pro' ); ?></li>
				<li><code>text</code> — <?php esc_html_e( 'Button label shown on the page.', 'vms-elements-fastspring-woo-payment-pro' ); ?></li>
				<li><code>style</code> — <?php esc_html_e( 'Button preset: primary, secondary, outline, or link.', 'vms-elements-fastspring-woo-payment-pro' ); ?></li>
				<li><code>bg</code>, <code>color</code>, <code>font_size</code>, <code>padding</code>, <code>margin</code>, <code>border_radius</code>, <code>border_width</code>, <code>border_color</code> — <?php esc_html_e( 'Optional inline button styling.', 'vms-elements-fastspring-woo-payment-pro' ); ?></li>
				<li><code>align</code> — <?php esc_html_e( 'Wrapper alignment: left, center, or right.', 'vms-elements-fastspring-woo-payment-pro' ); ?></li>
				<li><code>class</code> — <?php esc_html_e( 'Extra CSS classes for the button.', 'vms-elements-fastspring-woo-payment-pro' ); ?></li>
				<li><code>quantity</code> — <?php esc_html_e( 'Quantity added to the popup checkout cart (default 1).', 'vms-elements-fastspring-woo-payment-pro' ); ?></li>
			</ul>
		</div>
		<?php
	}
}
