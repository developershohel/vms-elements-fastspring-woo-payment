<?php
/**
 * Tools screen (logs, manual sync).
 *
 * @package VMS_EFWP
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class VMS_EFWP_Admin_Tools.
 */
class VMS_EFWP_Admin_Tools {

	/**
	 * Handle bulk WooCommerce → FastSpring product sync.
	 */
	public static function handle_sync_all_products() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'vms-elements-fastspring-woo-payment-pro' ) );
		}
		check_admin_referer( 'vms_efwp_sync_all_products' );

		$summary = function_exists( 'vms_efwp' ) && vms_efwp()->product_sync
			? vms_efwp()->product_sync->sync_all_products()
			: array( 'synced' => 0, 'failed' => 0, 'skipped' => 0, 'errors' => array( __( 'Product sync is unavailable.', 'vms-elements-fastspring-woo-payment-pro' ) ) );

		$message = sprintf(
			/* translators: 1: synced count 2: failed count 3: skipped count */
			__( 'Bulk sync finished. Synced: %1$d, failed: %2$d, skipped: %3$d.', 'vms-elements-fastspring-woo-payment-pro' ),
			(int) $summary['synced'],
			(int) $summary['failed'],
			(int) $summary['skipped']
		);
		if ( ! empty( $summary['errors'] ) ) {
			$message .= ' ' . implode( ' | ', array_slice( (array) $summary['errors'], 0, 3 ) );
		}

		set_transient( 'vms_efwp_tools_notice', $message, 60 );
		wp_safe_redirect( admin_url( 'admin.php?page=vms-efwp-tools' ) );
		exit;
	}

	/**
	 * Render tools.
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		global $wpdb;

		$notice = get_transient( 'vms_efwp_tools_notice' );
		if ( $notice ) {
			delete_transient( 'vms_efwp_tools_notice' );
			printf( '<div class="notice notice-success is-dismissible"><p>%s</p></div>', esc_html( $notice ) );
		}

		$log_table    = VMS_EFWP_Install::table_name( 'log' );
		$events_table = VMS_EFWP_Install::table_name( 'events' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$logs = $wpdb->get_results(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"SELECT * FROM {$log_table} ORDER BY id DESC LIMIT 100",
			ARRAY_A
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$events = $wpdb->get_results(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"SELECT * FROM {$events_table} ORDER BY id DESC LIMIT 50",
			ARRAY_A
		);
		?>
		<div class="wrap vms-efwp-wrap">
			<?php
			VMS_EFWP_Admin_Resource_Base::render_header(
				__( 'Tools', 'vms-elements-fastspring-woo-payment-pro' ),
				__( 'Diagnostics, bulk sync, and local webhook/log data.', 'vms-elements-fastspring-woo-payment-pro' )
			);

			if ( VMS_EFWP_Webhook::is_localhost_environment() ) {
				self::render_localhost_webhook_card();
			}
			?>

			<div class="vms-efwp-card vms-efwp-card--wide">
				<h2><?php esc_html_e( 'Maintenance actions', 'vms-elements-fastspring-woo-payment-pro' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Run one-off tasks against FastSpring and WooCommerce.', 'vms-elements-fastspring-woo-payment-pro' ); ?></p>
				<p>
					<button type="button" class="button" id="vms-efwp-test-connection"><?php esc_html_e( 'Test API connection', 'vms-elements-fastspring-woo-payment-pro' ); ?></button>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;">
						<?php wp_nonce_field( 'vms_efwp_sync_all_products' ); ?>
						<input type="hidden" name="action" value="vms_efwp_sync_all_products" />
						<button type="submit" class="button button-primary" onclick="return confirm('<?php esc_attr_e( 'Sync all published WooCommerce products to FastSpring?', 'vms-elements-fastspring-woo-payment-pro' ); ?>');"><?php esc_html_e( 'Bulk sync WooCommerce products', 'vms-elements-fastspring-woo-payment-pro' ); ?></button>
					</form>
					<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=vms-efwp-events' ) ); ?>"><?php esc_html_e( 'View all webhook events', 'vms-elements-fastspring-woo-payment-pro' ); ?></a>
					<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=vms-efwp-settings' ) ); ?>"><?php esc_html_e( 'Open settings', 'vms-elements-fastspring-woo-payment-pro' ); ?></a>
				</p>
			</div>

			<div class="vms-efwp-card vms-efwp-card--wide">
				<h2><?php esc_html_e( 'Recent webhook events', 'vms-elements-fastspring-woo-payment-pro' ); ?></h2>
				<table class="widefat striped vms-efwp-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Event ID', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
							<th><?php esc_html_e( 'Type', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
							<th><?php esc_html_e( 'Live', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
							<th><?php esc_html_e( 'Processed', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
							<th><?php esc_html_e( 'Created', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
							<th><?php esc_html_e( 'Error', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
						</tr>
					</thead>
					<tbody>
					<?php if ( empty( $events ) ) : ?>
						<tr><td colspan="6"><?php esc_html_e( 'No events received yet.', 'vms-elements-fastspring-woo-payment-pro' ); ?></td></tr>
					<?php else : ?>
						<?php foreach ( $events as $e ) : ?>
							<tr>
								<td><code><?php echo esc_html( $e['event_id'] ); ?></code></td>
								<td><?php echo esc_html( $e['event_type'] ); ?></td>
								<td><?php echo (int) $e['live'] ? '<span class="vms-efwp-badge vms-efwp-badge--ok">LIVE</span>' : '<span class="vms-efwp-badge vms-efwp-badge--warning">TEST</span>'; ?></td>
								<td><?php echo (int) $e['processed'] ? esc_html__( 'Yes', 'vms-elements-fastspring-woo-payment-pro' ) : esc_html__( 'No', 'vms-elements-fastspring-woo-payment-pro' ); ?></td>
								<td><?php echo esc_html( $e['created_at'] ); ?></td>
								<td><?php echo esc_html( $e['error_message'] ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
					</tbody>
				</table>
			</div>

			<div class="vms-efwp-card vms-efwp-card--wide">
				<h2><?php esc_html_e( 'Recent log entries', 'vms-elements-fastspring-woo-payment-pro' ); ?></h2>
				<table class="widefat striped vms-efwp-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Level', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
							<th><?php esc_html_e( 'Channel', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
							<th><?php esc_html_e( 'Message', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
							<th><?php esc_html_e( 'When', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
						</tr>
					</thead>
					<tbody>
					<?php if ( empty( $logs ) ) : ?>
						<tr><td colspan="4"><?php esc_html_e( 'No log entries yet.', 'vms-elements-fastspring-woo-payment-pro' ); ?></td></tr>
					<?php else : ?>
						<?php foreach ( $logs as $log ) : ?>
							<tr>
								<td><span class="vms-efwp-status vms-efwp-status--<?php echo esc_attr( $log['level'] ); ?>"><?php echo esc_html( $log['level'] ); ?></span></td>
								<td><?php echo esc_html( $log['channel'] ); ?></td>
								<td><?php echo esc_html( $log['message'] ); ?></td>
								<td><?php echo esc_html( $log['created_at'] ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
					</tbody>
				</table>
			</div>
		</div>
		<?php
	}

	/**
	 * Localhost-only webhook simulator instructions.
	 */
	private static function render_localhost_webhook_card() {
		$base_url = VMS_EFWP_Webhook::localhost_dev_webhook_url();
		?>
		<div class="vms-efwp-card vms-efwp-card--wide vms-efwp-card--dev-webhook">
			<h2><?php esc_html_e( 'Localhost webhook simulator', 'vms-elements-fastspring-woo-payment-pro' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'FastSpring cannot reach 127.0.0.1 or localhost. While developing locally, inject webhook JSON through this dev-only endpoint. It is automatically disabled on live domains.', 'vms-elements-fastspring-woo-payment-pro' ); ?>
			</p>
			<p>
				<strong><?php esc_html_e( 'Dev endpoint', 'vms-elements-fastspring-woo-payment-pro' ); ?></strong><br />
				<input type="text" readonly class="large-text code" value="<?php echo esc_attr( $base_url ); ?>" onclick="this.select();" />
			</p>
			<h3><?php esc_html_e( 'Option 1 — POST JSON body', 'vms-elements-fastspring-woo-payment-pro' ); ?></h3>
			<pre class="vms-efwp-json"><code>curl -X POST "<?php echo esc_html( $base_url ); ?>" ^
  -H "Content-Type: application/json" ^
  -d "{\"events\":[{\"id\":\"dev-1\",\"live\":false,\"type\":\"order.completed\",\"data\":{...}}]}"</code></pre>
			<h3><?php esc_html_e( 'Option 2 — payload query parameter', 'vms-elements-fastspring-woo-payment-pro' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Paste URL-encoded or base64-encoded FastSpring webhook JSON in the payload parameter.', 'vms-elements-fastspring-woo-payment-pro' ); ?></p>
			<pre class="vms-efwp-json"><code><?php echo esc_html( $base_url . '&payload=' . rawurlencode( '{"events":[{"id":"dev-1","live":false,"type":"subscription.activated","data":{}}]}' ) ); ?></code></pre>
			<h3><?php esc_html_e( 'Option 3 — fetch JSON from a URL', 'vms-elements-fastspring-woo-payment-pro' ); ?></h3>
			<pre class="vms-efwp-json"><code><?php echo esc_html( VMS_EFWP_Webhook::localhost_dev_webhook_url( array( 'url' => 'https://example.com/webhook-sample.json' ) ) ); ?></code></pre>
			<p class="description">
				<?php esc_html_e( 'Successful responses look like: {"ok":true,"processed":1,"mode":"localhost_dev"}. Events are stored in the local events table and run the same handlers as a real webhook (signature not required on localhost).', 'vms-elements-fastspring-woo-payment-pro' ); ?>
			</p>
		</div>
		<?php
	}
}
