<?php
/**
 * Pro admin AJAX and admin_post handlers.
 *
 * @package VMS_EFWP_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class VMS_EFWP_Pro_Admin_Ajax.
 */
class VMS_EFWP_Pro_Admin_Ajax {

	/**
	 * Register Pro admin AJAX and admin_post hooks.
	 */
	public static function init() {
		add_action( 'wp_ajax_vms_efwp_dashboard_data', array( __CLASS__, 'ajax_dashboard_data' ) );
		add_action( 'wp_ajax_vms_efwp_sync_subscription', array( __CLASS__, 'ajax_sync_subscription' ) );
		add_action( 'wp_ajax_vms_efwp_cancel_subscription', array( __CLASS__, 'ajax_cancel_subscription' ) );
		add_action( 'wp_ajax_vms_efwp_pause_subscription', array( __CLASS__, 'ajax_pause_subscription' ) );
		add_action( 'wp_ajax_vms_efwp_resume_subscription', array( __CLASS__, 'ajax_resume_subscription' ) );
		add_action( 'wp_ajax_vms_efwp_uncancel_subscription', array( __CLASS__, 'ajax_uncancel_subscription' ) );
		add_action( 'wp_ajax_vms_efwp_charge_subscription', array( __CLASS__, 'ajax_charge_subscription' ) );
		add_action( 'wp_ajax_vms_efwp_convert_subscription', array( __CLASS__, 'ajax_convert_subscription' ) );
		add_action( 'wp_ajax_vms_efwp_sync_order', array( __CLASS__, 'ajax_sync_order' ) );
		add_action( 'wp_ajax_vms_efwp_cancel_quote', array( __CLASS__, 'ajax_cancel_quote' ) );
		add_action( 'wp_ajax_vms_efwp_get_checkout_link', array( __CLASS__, 'ajax_get_checkout_link' ) );
		add_action( 'admin_post_vms_efwp_sync_all_products', array( __CLASS__, 'handle_sync_all_products' ) );
	}

	/**
	 * admin_post: bulk WooCommerce → FastSpring product sync.
	 */
	public static function handle_sync_all_products() {
		VMS_EFWP_Admin_Tools::handle_sync_all_products();
	}

	/**
	 * AJAX: dashboard data.
	 */
	public static function ajax_dashboard_data() {
		check_ajax_referer( 'vms_efwp_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'vms-elements-fastspring-woo-payment-pro' ) ), 403 );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verified above.
		$range = isset( $_REQUEST['range'] ) ? max( 1, min( 365, (int) $_REQUEST['range'] ) ) : 30;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Nonce verified above.
		$include_test = isset( $_REQUEST['include_test'] ) && '1' === $_REQUEST['include_test'];

		$today_end   = gmdate( 'Y-m-d 23:59:59' );
		$today_start = gmdate( 'Y-m-d 00:00:00' );
		$week_start  = gmdate( 'Y-m-d 00:00:00', time() - 6 * DAY_IN_SECONDS );
		$month_start = gmdate( 'Y-m-d 00:00:00', time() - 29 * DAY_IN_SECONDS );
		$range_start = gmdate( 'Y-m-d 00:00:00', time() - ( ( $range - 1 ) * DAY_IN_SECONDS ) );

		wp_send_json_success(
			array(
				'kpis'          => array(
					'today'    => VMS_EFWP_Stats::sales_summary( $today_start, $today_end, $include_test ),
					'week'     => VMS_EFWP_Stats::sales_summary( $week_start, $today_end, $include_test ),
					'month'    => VMS_EFWP_Stats::sales_summary( $month_start, $today_end, $include_test ),
					'all_time' => VMS_EFWP_Stats::sales_summary( '1970-01-01 00:00:00', $today_end, $include_test ),
				),
				'daily'         => VMS_EFWP_Stats::daily_revenue( $range, $include_test ),
				'top_products'  => VMS_EFWP_Stats::top_products( 6, $include_test, $range_start, $today_end ),
				'top_countries' => VMS_EFWP_Stats::top_countries( 6, $include_test, $range_start, $today_end ),
				'subscriptions' => VMS_EFWP_Stats::subscriptions_summary( $include_test ),
				'recent_orders' => VMS_EFWP_Stats::recent_orders( 8, $include_test ),
			)
		);
	}

	/**
	 * AJAX: pull a fresh copy of a subscription from the API.
	 */
	public static function ajax_sync_subscription() {
		check_ajax_referer( 'vms_efwp_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'vms-elements-fastspring-woo-payment-pro' ) ), 403 );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; value sanitized below.
		$id = isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '';
		if ( ! $id ) {
			wp_send_json_error( array( 'message' => __( 'Missing subscription id.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
		}
		$result = vms_efwp()->api->get_subscription( $id );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		$subscription = vms_efwp()->api->parse_subscription( $result );
		if ( is_wp_error( $subscription ) ) {
			wp_send_json_error( array( 'message' => $subscription->get_error_message() ) );
		}
		$is_test = ! empty( $subscription['live'] ) ? ! $subscription['live'] : vms_efwp()->settings->is_sandbox();
		VMS_EFWP_Data_Store::upsert_subscription( $subscription, $is_test );
		wp_send_json_success( array( 'message' => __( 'Subscription synced.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
	}

	/**
	 * AJAX: cancel a subscription.
	 */
	public static function ajax_cancel_subscription() {
		check_ajax_referer( 'vms_efwp_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'vms-elements-fastspring-woo-payment-pro' ) ), 403 );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; value sanitized below.
		$id = isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '';
		if ( ! $id ) {
			wp_send_json_error( array( 'message' => __( 'Missing subscription id.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		$immediate = isset( $_POST['immediate'] ) && '1' === $_POST['immediate'];
		$result    = vms_efwp()->api->cancel_subscription( $id, $immediate );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		VMS_EFWP_Data_Store::set_subscription_status( $id, 'canceled' );
		wp_send_json_success( array( 'message' => __( 'Subscription cancellation requested.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
	}

	/**
	 * AJAX: pause a subscription.
	 */
	public static function ajax_pause_subscription() {
		check_ajax_referer( 'vms_efwp_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'vms-elements-fastspring-woo-payment-pro' ) ), 403 );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; value sanitized below.
		$id = isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '';
		if ( ! $id ) {
			wp_send_json_error( array( 'message' => __( 'Missing subscription id.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		$periods = isset( $_POST['pause_period_count'] ) ? max( 1, (int) $_POST['pause_period_count'] ) : 1;
		$result  = vms_efwp()->api->pause_subscription( $id, array( 'pausePeriodCount' => $periods ) );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		$subscription = vms_efwp()->api->parse_subscription( $result );
		if ( ! is_wp_error( $subscription ) ) {
			VMS_EFWP_Data_Store::upsert_subscription( $subscription, vms_efwp()->settings->is_sandbox() );
		} else {
			VMS_EFWP_Data_Store::set_subscription_status( $id, 'paused' );
		}
		wp_send_json_success( array( 'message' => __( 'Subscription paused.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
	}

	/**
	 * AJAX: resume a subscription.
	 */
	public static function ajax_resume_subscription() {
		check_ajax_referer( 'vms_efwp_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'vms-elements-fastspring-woo-payment-pro' ) ), 403 );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; value sanitized below.
		$id = isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '';
		if ( ! $id ) {
			wp_send_json_error( array( 'message' => __( 'Missing subscription id.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
		}
		$result = vms_efwp()->api->resume_subscription( $id );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		$subscription = vms_efwp()->api->parse_subscription( $result );
		if ( ! is_wp_error( $subscription ) ) {
			VMS_EFWP_Data_Store::upsert_subscription( $subscription, vms_efwp()->settings->is_sandbox() );
		} else {
			VMS_EFWP_Data_Store::set_subscription_status( $id, 'active' );
		}
		wp_send_json_success( array( 'message' => __( 'Subscription resumed.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
	}

	/**
	 * AJAX: uncancel a subscription.
	 */
	public static function ajax_uncancel_subscription() {
		check_ajax_referer( 'vms_efwp_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'vms-elements-fastspring-woo-payment-pro' ) ), 403 );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; value sanitized below.
		$id = isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '';
		if ( ! $id ) {
			wp_send_json_error( array( 'message' => __( 'Missing subscription id.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
		}
		$result = vms_efwp()->api->uncancel_subscription( $id );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		VMS_EFWP_Data_Store::set_subscription_status( $id, 'active' );
		wp_send_json_success( array( 'message' => __( 'Subscription uncanceled.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
	}

	/**
	 * AJAX: charge a managed subscription.
	 */
	public static function ajax_charge_subscription() {
		check_ajax_referer( 'vms_efwp_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'vms-elements-fastspring-woo-payment-pro' ) ), 403 );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; value sanitized below.
		$id = isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '';
		if ( ! $id ) {
			wp_send_json_error( array( 'message' => __( 'Missing subscription id.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
		}
		$result = vms_efwp()->api->charge_subscriptions( $id );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		wp_send_json_success( array( 'message' => __( 'Subscription charge requested.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
	}

	/**
	 * AJAX: convert a deactivated trial subscription.
	 */
	public static function ajax_convert_subscription() {
		check_ajax_referer( 'vms_efwp_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'vms-elements-fastspring-woo-payment-pro' ) ), 403 );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; value sanitized below.
		$id = isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '';
		if ( ! $id ) {
			wp_send_json_error( array( 'message' => __( 'Missing subscription id.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
		}
		$result = vms_efwp()->api->convert_subscription( $id );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		wp_send_json_success(
			array(
				'message' => __( 'Conversion session created.', 'vms-elements-fastspring-woo-payment-pro' ),
				'session' => $result,
			)
		);
	}

	/**
	 * AJAX: save an API order to the local database.
	 */
	public static function ajax_sync_order() {
		check_ajax_referer( 'vms_efwp_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'vms-elements-fastspring-woo-payment-pro' ) ), 403 );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; value sanitized below.
		$id = isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '';
		if ( ! $id ) {
			wp_send_json_error( array( 'message' => __( 'Missing order id.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
		}
		$result = vms_efwp()->api->get_order( $id );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		$order = vms_efwp()->api->parse_order( $result );
		if ( is_wp_error( $order ) ) {
			wp_send_json_error( array( 'message' => $order->get_error_message() ) );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		$is_test = isset( $_POST['is_test'] ) && '1' === $_POST['is_test'];
		VMS_EFWP_Data_Store::upsert_order( $order, $is_test );
		wp_send_json_success( array( 'message' => __( 'Order saved locally.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
	}

	/**
	 * AJAX: cancel a quote.
	 */
	public static function ajax_cancel_quote() {
		check_ajax_referer( 'vms_efwp_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'vms-elements-fastspring-woo-payment-pro' ) ), 403 );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above; value sanitized below.
		$id = isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '';
		if ( ! $id ) {
			wp_send_json_error( array( 'message' => __( 'Missing quote id.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
		}
		$result = vms_efwp()->api->cancel_quote( $id );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		wp_send_json_success( array( 'message' => __( 'Quote canceled.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
	}

	/**
	 * AJAX: overlay checkout links for a catalog product.
	 */
	public static function ajax_get_checkout_link() {
		check_ajax_referer( 'vms_efwp_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'vms-elements-fastspring-woo-payment-pro' ) ), 403 );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		$product_path = isset( $_POST['product_path'] ) ? sanitize_text_field( wp_unslash( $_POST['product_path'] ) ) : '';
		if ( ! $product_path ) {
			wp_send_json_error( array( 'message' => __( 'Missing product path.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		$create_session = ! empty( $_POST['create_session'] ) && '1' === $_POST['create_session'];

		$links = VMS_EFWP_Checkout_Links::get_product_checkout_links(
			$product_path,
			array(
				'create_session' => $create_session,
			)
		);

		if ( is_wp_error( $links ) ) {
			wp_send_json_error( array( 'message' => $links->get_error_message() ) );
		}

		wp_send_json_success( $links );
	}
}
