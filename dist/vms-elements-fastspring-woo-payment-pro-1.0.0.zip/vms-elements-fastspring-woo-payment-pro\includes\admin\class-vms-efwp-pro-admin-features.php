<?php
/**
 * Pro admin menus and catalog highlight (Pro plugin only).
 *
 * @package VMS_EFWP_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class VMS_EFWP_Pro_Admin_Features.
 */
class VMS_EFWP_Pro_Admin_Features {

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'vms_efwp_register_admin_menu', array( __CLASS__, 'register_menus' ), 10, 1 );
		add_filter( 'submenu_file', array( __CLASS__, 'highlight_subscription_catalog_menu' ), 10, 2 );
		VMS_EFWP_Pro_Admin_Ajax::init();
	}

	/**
	 * Register Pro admin submenus under FastSpring.
	 *
	 * @param string $parent_slug Parent menu slug.
	 */
	public static function register_menus( $parent_slug ) {
		$pages = array(
			array( 'separator', 'vms-efwp-sep-sales', __( '— Sales —', 'vms-elements-fastspring-woo-payment-pro' ) ),
			array( 'vms-efwp-subscriptions', __( 'Subscriptions', 'vms-elements-fastspring-woo-payment-pro' ), array( 'VMS_EFWP_Admin_Subscriptions', 'render' ) ),
			array( 'vms-efwp-invoices', __( 'Invoices', 'vms-elements-fastspring-woo-payment-pro' ), array( 'VMS_EFWP_Admin_Invoices', 'render' ) ),
			array( 'vms-efwp-quotes', __( 'Quotes', 'vms-elements-fastspring-woo-payment-pro' ), array( 'VMS_EFWP_Admin_Quotes', 'render' ) ),
			array( 'vms-efwp-returns', __( 'Returns', 'vms-elements-fastspring-woo-payment-pro' ), array( 'VMS_EFWP_Admin_Returns', 'render' ) ),
			array( 'separator', 'vms-efwp-sep-catalog', __( '— Catalog —', 'vms-elements-fastspring-woo-payment-pro' ) ),
			array( 'vms-efwp-products', __( 'Products', 'vms-elements-fastspring-woo-payment-pro' ), array( 'VMS_EFWP_Admin_Products', 'render' ) ),
			array( 'vms-efwp-subscription-catalog', __( 'Subscription Products', 'vms-elements-fastspring-woo-payment-pro' ), array( 'VMS_EFWP_Admin_Subscriptions', 'render_catalog_page' ) ),
			array( 'vms-efwp-coupons', __( 'Coupons', 'vms-elements-fastspring-woo-payment-pro' ), array( 'VMS_EFWP_Admin_Coupons', 'render' ) ),
			array( 'vms-efwp-shortcodes', __( 'Shortcodes', 'vms-elements-fastspring-woo-payment-pro' ), array( 'VMS_EFWP_Admin_Shortcodes', 'render' ) ),
			array( 'separator', 'vms-efwp-sep-customers', __( '— Customers —', 'vms-elements-fastspring-woo-payment-pro' ) ),
			array( 'vms-efwp-accounts', __( 'Accounts', 'vms-elements-fastspring-woo-payment-pro' ), array( 'VMS_EFWP_Admin_Accounts', 'render' ) ),
			array( 'vms-efwp-sessions', __( 'Sessions', 'vms-elements-fastspring-woo-payment-pro' ), array( 'VMS_EFWP_Admin_Sessions', 'render' ) ),
			array( 'separator', 'vms-efwp-sep-integrations', __( '— Integrations —', 'vms-elements-fastspring-woo-payment-pro' ) ),
			array( 'vms-efwp-events', __( 'Events', 'vms-elements-fastspring-woo-payment-pro' ), array( 'VMS_EFWP_Admin_Events', 'render' ) ),
			array( 'vms-efwp-reports', __( 'Reports', 'vms-elements-fastspring-woo-payment-pro' ), array( 'VMS_EFWP_Admin_Reports', 'render' ) ),
			array( 'vms-efwp-webhooks', __( 'Webhooks', 'vms-elements-fastspring-woo-payment-pro' ), array( 'VMS_EFWP_Admin_Webhooks', 'render' ) ),
			array( 'separator', 'vms-efwp-sep-system', __( '— System —', 'vms-elements-fastspring-woo-payment-pro' ) ),
			array( 'vms-efwp-tools', __( 'Tools', 'vms-elements-fastspring-woo-payment-pro' ), array( 'VMS_EFWP_Admin_Tools', 'render' ) ),
		);

		foreach ( $pages as $page ) {
			if ( 'separator' === $page[0] ) {
				add_submenu_page( $parent_slug, '', $page[2], 'manage_options', $page[1], '__return_false' );
				continue;
			}
			add_submenu_page( $parent_slug, $page[1], $page[1], 'manage_options', $page[0], $page[2] );
		}
	}

	/**
	 * Highlight Catalog → Subscription Products when viewing the catalog tab.
	 *
	 * @param string|null $submenu_file Active submenu file.
	 * @param string      $parent_file  Active parent file.
	 * @return string|null
	 */
	public static function highlight_subscription_catalog_menu( $submenu_file, $parent_file ) {
		if ( 'vms-efwp' !== $parent_file ) {
			return $submenu_file;
		}

		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( 'vms-efwp-subscriptions' === $page && 'catalog' === $tab ) {
			return 'vms-efwp-subscription-catalog';
		}

		return $submenu_file;
	}
}
