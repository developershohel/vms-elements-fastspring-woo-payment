<?php
/**
 * Pro plugin admin helpers.
 *
 * @package VMS_EFWP_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class VMS_EFWP_Pro_Admin.
 */
class VMS_EFWP_Pro_Admin {

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_filter( 'plugin_action_links_' . VMS_EFWP_PRO_BASENAME, array( __CLASS__, 'action_links' ) );
	}

	/**
	 * Plugin row action links.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public static function action_links( $links ) {
		$links[] = '<a href="' . esc_url( admin_url( 'admin.php?page=vms-efwp-pro-license' ) ) . '">' . esc_html__( 'License', 'vms-elements-fastspring-woo-payment-pro' ) . '</a>';
		return $links;
	}
}
