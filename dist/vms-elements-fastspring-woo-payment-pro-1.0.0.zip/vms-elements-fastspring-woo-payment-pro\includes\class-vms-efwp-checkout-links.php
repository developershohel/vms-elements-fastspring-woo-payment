<?php
/**
 * FastSpring popup overlay checkout links for catalog products.
 *
 * @package VMS_EFWP
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class VMS_EFWP_Checkout_Links.
 */
class VMS_EFWP_Checkout_Links {

	const SBL_SCRIPT_URL = 'https://sbl.onfastspring.com/sbl/1.0.7/fastspring-builder.min.js';

	const CHECKOUT_PAGE_OPTION = 'vms_efwp_checkout_page_id';

	const REWRITE_VERSION_OPTION = 'vms_efwp_checkout_rewrite_version';

	const REWRITE_VERSION = '2';

	const CHECKOUT_ENDPOINT = 'fastspring-checkout';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_rewrite_rules' ), 5 );
		add_filter( 'query_vars', array( __CLASS__, 'register_query_vars' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_render_payment_page' ), 5 );
		self::maybe_flush_rewrite_rules();
	}

	/**
	 * Register the public checkout endpoint rewrite rule.
	 */
	public static function register_rewrite_rules() {
		add_rewrite_rule(
			self::CHECKOUT_ENDPOINT . '/?$',
			'index.php?vms_efwp_checkout=1',
			'top'
		);
	}

	/**
	 * Register public query vars.
	 *
	 * @param string[] $vars Query vars.
	 * @return string[]
	 */
	public static function register_query_vars( $vars ) {
		$vars[] = 'vms_efwp_checkout';
		return $vars;
	}

	/**
	 * Flush rewrite rules after plugin updates or endpoint changes.
	 */
	public static function maybe_flush_rewrite_rules() {
		$stored = (string) get_option( self::REWRITE_VERSION_OPTION, '' );
		if ( $stored === self::REWRITE_VERSION ) {
			return;
		}

		self::register_rewrite_rules();
		flush_rewrite_rules( false );
		update_option( self::REWRITE_VERSION_OPTION, self::REWRITE_VERSION, false );
	}

	/**
	 * Flush rewrite rules immediately (activation / manual repair).
	 */
	public static function flush_rewrite_rules_now() {
		self::register_rewrite_rules();
		flush_rewrite_rules( false );
		update_option( self::REWRITE_VERSION_OPTION, self::REWRITE_VERSION, false );
	}

	/**
	 * Ensure a hidden frontend checkout page exists.
	 *
	 * @return int Page ID.
	 */
	public static function ensure_checkout_page() {
		$page_id = absint( get_option( self::CHECKOUT_PAGE_OPTION, 0 ) );
		if ( $page_id && get_post( $page_id ) && 'page' === get_post_type( $page_id ) ) {
			return $page_id;
		}

		$existing = get_page_by_path( 'fastspring-checkout', OBJECT, 'page' );
		if ( $existing instanceof WP_Post ) {
			update_option( self::CHECKOUT_PAGE_OPTION, (int) $existing->ID, false );
			return (int) $existing->ID;
		}

		$page_id = wp_insert_post(
			array(
				'post_title'     => __( 'FastSpring Checkout', 'vms-elements-fastspring-woo-payment-pro' ),
				'post_name'      => 'fastspring-checkout',
				'post_status'    => 'publish',
				'post_type'      => 'page',
				'post_content'   => '<!-- FastSpring overlay checkout page -->',
				'comment_status' => 'closed',
				'ping_status'    => 'closed',
			),
			true
		);

		if ( is_wp_error( $page_id ) || ! $page_id ) {
			return 0;
		}

		update_option( self::CHECKOUT_PAGE_OPTION, (int) $page_id, false );
		return (int) $page_id;
	}

	/**
	 * Resolve the WordPress page used for public payment links.
	 *
	 * @return int
	 */
	public static function get_checkout_page_id() {
		$configured = 0;
		if ( function_exists( 'vms_efwp' ) && vms_efwp()->settings ) {
			$configured = absint( vms_efwp()->settings->get( 'checkout_page_id', 0 ) );
		}

		if ( $configured && get_post( $configured ) && 'page' === get_post_type( $configured ) ) {
			return $configured;
		}

		return self::ensure_checkout_page();
	}

	/**
	 * Base URL for public overlay payment links.
	 *
	 * Uses the configured page when set, otherwise the rewrite endpoint.
	 *
	 * @return string|WP_Error
	 */
	public static function get_checkout_page_base_url() {
		if ( function_exists( 'vms_efwp' ) && vms_efwp()->settings ) {
			$configured = absint( vms_efwp()->settings->get( 'checkout_page_id', 0 ) );
			if ( $configured && get_post( $configured ) && 'page' === get_post_type( $configured ) ) {
				$url = get_permalink( $configured );
				if ( $url ) {
					return $url;
				}
			}
		}

		return self::get_checkout_endpoint_url();
	}

	/**
	 * Public rewrite endpoint for overlay checkout links.
	 *
	 * @return string
	 */
	public static function get_checkout_endpoint_url() {
		return home_url( user_trailingslashit( self::CHECKOUT_ENDPOINT ) );
	}

	/**
	 * Whether the current request should open the overlay checkout bridge.
	 *
	 * @return bool
	 */
	private static function is_checkout_route_request() {
		if ( get_query_var( 'vms_efwp_checkout' ) ) {
			return true;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public route detection only.
		if ( ! empty( $_GET['vms_efwp_checkout'] ) ) {
			return true;
		}

		$page_id = self::get_checkout_page_id();
		if ( $page_id && is_page( $page_id ) ) {
			return true;
		}

		global $wp;
		if ( isset( $wp->request ) && preg_match( '#(^|/)' . preg_quote( self::CHECKOUT_ENDPOINT, '#' ) . '/?$#', (string) $wp->request ) ) {
			return true;
		}

		$pagename = get_query_var( 'pagename' );
		if ( self::CHECKOUT_ENDPOINT === $pagename ) {
			return true;
		}

		return false;
	}

	/**
	 * Build the public popup overlay URL for a catalog product path.
	 *
	 * @param string $product_path FastSpring product path.
	 * @return string|WP_Error
	 */
	public static function build_product_overlay_url( $product_path ) {
		$product_path = sanitize_text_field( (string) $product_path );
		if ( '' === $product_path ) {
			return new WP_Error(
				'vms_efwp_checkout_link',
				__( 'A product path is required.', 'vms-elements-fastspring-woo-payment-pro' )
			);
		}

		if ( ! function_exists( 'vms_efwp' ) || ! vms_efwp()->settings || ! vms_efwp()->settings->has_popup_checkout() ) {
			return new WP_Error(
				'vms_efwp_checkout_link',
				__( 'Configure the popup checkout path in FastSpring → Settings.', 'vms-elements-fastspring-woo-payment-pro' )
			);
		}

		$popup_storefront = vms_efwp()->settings->popup_storefront();
		$segments         = array_filter( explode( '/', trim( $product_path, '/' ) ) );
		$encoded_path     = implode( '/', array_map( 'rawurlencode', $segments ) );

		return sprintf( 'https://%s/%s', $popup_storefront, $encoded_path );
	}

	/**
	 * Build a public frontend payment link that opens overlay checkout on your site.
	 *
	 * @param string $product_path Product path.
	 * @param array  $args         Optional redirect, quantity, session_id.
	 * @return string|WP_Error
	 */
	public static function build_payment_link_url( $product_path, $args = array() ) {
		$product_path = sanitize_text_field( (string) $product_path );
		if ( '' === $product_path ) {
			return new WP_Error(
				'vms_efwp_checkout_link',
				__( 'A product path is required.', 'vms-elements-fastspring-woo-payment-pro' )
			);
		}

		if ( ! function_exists( 'vms_efwp' ) || ! vms_efwp()->settings || ! vms_efwp()->settings->has_popup_checkout() ) {
			return new WP_Error(
				'vms_efwp_checkout_link',
				__( 'Configure the popup checkout path in FastSpring → Settings.', 'vms-elements-fastspring-woo-payment-pro' )
			);
		}

		$args = wp_parse_args(
			$args,
			array(
				'redirect'   => '',
				'quantity'   => 1,
				'session_id' => '',
			)
		);

		$base = self::get_checkout_page_base_url();
		if ( is_wp_error( $base ) ) {
			return $base;
		}

		$query = array(
			'product' => $product_path,
		);

		$redirect = self::sanitize_redirect_param( $args['redirect'] );
		if ( $redirect ) {
			$query['redirect'] = $redirect;
		}

		$quantity = max( 1, absint( $args['quantity'] ) );
		if ( $quantity > 1 ) {
			$query['quantity'] = $quantity;
		}

		if ( ! empty( $args['session_id'] ) ) {
			$query['session_id'] = sanitize_text_field( (string) $args['session_id'] );
		}

		return add_query_arg( $query, $base );
	}

	/**
	 * Backward-compatible alias.
	 *
	 * @param string $product_path Product path.
	 * @param array  $args         Optional args.
	 * @return string|WP_Error
	 */
	public static function build_admin_preview_url( $product_path, $args = array() ) {
		return self::build_payment_link_url( $product_path, $args );
	}

	/**
	 * Collect overlay checkout links for a product.
	 *
	 * @param string $product_path Product path.
	 * @param array  $args         Args. create_session (bool), redirect (string).
	 * @return array|WP_Error
	 */
	public static function get_product_checkout_links( $product_path, $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'create_session' => false,
				'redirect'       => '',
			)
		);

		$overlay_url = self::build_product_overlay_url( $product_path );
		if ( is_wp_error( $overlay_url ) ) {
			return $overlay_url;
		}

		$session_id  = '';
		$session_url = '';

		if ( $args['create_session'] && function_exists( 'vms_efwp' ) && vms_efwp()->api ) {
			$session = vms_efwp()->api->create_session(
				array(
					'items' => array(
						array(
							'product'  => sanitize_text_field( (string) $product_path ),
							'quantity' => 1,
						),
					),
				)
			);

			if ( is_wp_error( $session ) ) {
				return $session;
			}

			$session_id = isset( $session['id'] ) ? (string) $session['id'] : '';
			if ( $session_id && vms_efwp()->settings ) {
				$storefront = vms_efwp()->settings->storefront();
				if ( $storefront ) {
					$session_url = sprintf( 'https://%s/session/%s', $storefront, rawurlencode( $session_id ) );
				}
			}
		}

		$link_args = array(
			'redirect'   => $args['redirect'],
			'session_id' => $session_id,
		);

		$payment_url = self::build_payment_link_url( $product_path, $link_args );
		if ( is_wp_error( $payment_url ) ) {
			return $payment_url;
		}

		$embed_html = sprintf(
			'<a href="%1$s">%2$s</a>',
			esc_url( $payment_url ),
			esc_html__( 'Buy now', 'vms-elements-fastspring-woo-payment-pro' )
		);

		$page_id = self::get_checkout_page_id();

		return array(
			'productPath'       => sanitize_text_field( (string) $product_path ),
			'paymentUrl'        => $payment_url,
			'previewUrl'        => $payment_url,
			'overlayUrl'        => $overlay_url,
			'sessionId'         => $session_id,
			'sessionUrl'        => $session_url,
			'embedHtml'         => $embed_html,
			'checkoutPageId'    => $page_id,
			'checkoutPageUrl'   => self::get_checkout_page_base_url(),
			'popupStorefront'   => function_exists( 'vms_efwp' ) && vms_efwp()->settings ? vms_efwp()->settings->popup_storefront() : '',
		);
	}

	/**
	 * Render the public payment page when a product query arg is present.
	 */
	public static function maybe_render_payment_page() {
		if ( is_admin() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public shareable payment link.
		$product_path = isset( $_GET['product'] ) ? sanitize_text_field( wp_unslash( $_GET['product'] ) ) : '';
		if ( '' === $product_path ) {
			return;
		}

		if ( ! self::is_checkout_route_request() ) {
			return;
		}

		if ( ! function_exists( 'vms_efwp' ) || ! vms_efwp()->settings || ! vms_efwp()->settings->has_popup_checkout() ) {
			wp_die( esc_html__( 'FastSpring checkout is not configured.', 'vms-elements-fastspring-woo-payment-pro' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public shareable payment link.
		$redirect_raw = isset( $_GET['redirect'] ) ? sanitize_text_field( wp_unslash( $_GET['redirect'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public shareable payment link.
		$details_flag = isset( $_GET['details'] ) ? sanitize_text_field( wp_unslash( $_GET['details'] ) ) : '';
		$show_details = VMS_EFWP_Payment_Success::parse_details_flag( $details_flag );
		if ( null === $show_details ) {
			$show_details = VMS_EFWP_Payment_Success::default_show_details();
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public shareable payment link.
		$quantity = isset( $_GET['quantity'] ) ? max( 1, absint( $_GET['quantity'] ) ) : 1;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public shareable payment link.
		$session_id = isset( $_GET['session_id'] ) ? sanitize_text_field( wp_unslash( $_GET['session_id'] ) ) : '';

		self::render_payment_page(
			$product_path,
			array(
				'redirect'     => self::sanitize_redirect_param( $redirect_raw ),
				'show_details' => $show_details,
				'quantity'     => $quantity,
				'session_id'   => $session_id,
			)
		);
		exit;
	}

	/**
	 * Output HTML that opens the FastSpring popup overlay checkout on the frontend.
	 *
	 * @param string $product_path Product path.
	 * @param array  $args         Optional redirect, quantity, session_id.
	 */
	public static function render_payment_page( $product_path, $args = array() ) {
		if ( ! function_exists( 'vms_efwp' ) || ! vms_efwp()->settings || ! vms_efwp()->settings->has_popup_checkout() ) {
			wp_die( esc_html__( 'Popup checkout is not configured.', 'vms-elements-fastspring-woo-payment-pro' ) );
		}

		$args = wp_parse_args(
			$args,
			array(
				'redirect'     => '',
				'show_details' => null,
				'quantity'     => 1,
				'session_id'   => '',
			)
		);

		$settings         = vms_efwp()->settings;
		$popup_storefront = $settings->popup_storefront();
		$access_key       = $settings->access_key();
		$product_path     = sanitize_text_field( (string) $product_path );
		$session_id       = sanitize_text_field( (string) $args['session_id'] );
		$show_details     = null === $args['show_details']
			? VMS_EFWP_Payment_Success::default_show_details()
			: (bool) $args['show_details'];
		$redirect         = VMS_EFWP_Payment_Success::resolve_post_payment_redirect(
			self::sanitize_redirect_param( $args['redirect'] ),
			$show_details
		);
		$quantity         = max( 1, absint( $args['quantity'] ) );
		$back_url         = home_url( '/' );
		$loading          = esc_html__( 'Opening secure checkout…', 'vms-elements-fastspring-woo-payment-pro' );
		$closed           = esc_html__( 'Checkout closed.', 'vms-elements-fastspring-woo-payment-pro' );
		$failed           = esc_html__( 'Could not open FastSpring checkout. Confirm your popup path and whitelisted domains.', 'vms-elements-fastspring-woo-payment-pro' );

		nocache_headers();
		?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> class="vms-efwp-fastspring-checkout">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta name="robots" content="noindex,nofollow" />
	<title><?php echo esc_html__( 'Secure checkout', 'vms-elements-fastspring-woo-payment-pro' ); ?></title>
	<?php
		VMS_EFWP_Assets::print_standalone_head_assets(
			array(
				'popup_storefront' => $popup_storefront,
				'access_key'       => $access_key,
				'popup_closed'     => 'VMS_EFWP_PaymentClosed',
				'error_callback'   => 'VMS_EFWP_PaymentError',
			)
		);
		?>
</head>
<body class="vms-efwp-fastspring-checkout">
	<main id="vms-efwp-fastspring-overlay-root" class="vms-efwp-fastspring-overlay-root" aria-live="polite">
		<div class="vms-efwp-checkout-shell vms-efwp-checkout-shell--loading">
			<div class="vms-efwp-spinner" aria-hidden="true"></div>
			<p id="vms-efwp-overlay-status"><?php echo $loading; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above. ?></p>
			<p><a href="<?php echo esc_url( $back_url ); ?>"><?php esc_html_e( 'Return to site', 'vms-elements-fastspring-woo-payment-pro' ); ?></a></p>
		</div>
	</main>
	<script>
	(function(){
		var PRODUCT = <?php echo wp_json_encode( $product_path ); ?>;
		var SESSION = <?php echo wp_json_encode( $session_id ); ?>;
		var QUANTITY = <?php echo wp_json_encode( $quantity ); ?>;
		var REDIRECT = <?php echo wp_json_encode( $redirect ); ?>;
		var FALLBACK_REDIRECT = <?php echo wp_json_encode( VMS_EFWP_Payment_Success::resolve_post_payment_redirect( '', $show_details ) ); ?>;
		var opened = false, done = false, tries = 0;

		function setStatus(msg) {
			var el = document.getElementById('vms-efwp-overlay-status');
			if (el) { el.textContent = msg; }
		}

		function appendQueryParam(url, key, value) {
			try {
				var target = new URL(url, window.location.origin);
				target.searchParams.set(key, value);
				return target.toString();
			} catch (e) {
				var join = url.indexOf('?') === -1 ? '?' : '&';
				return url + join + encodeURIComponent(key) + '=' + encodeURIComponent(value);
			}
		}

		function ready() {
			return window.fastspring && window.fastspring.builder && typeof window.fastspring.builder.checkout === 'function';
		}

		function openCheckout() {
			if (opened) { return; }
			if (!ready()) {
				tries += 1;
				if (tries < 150) { return; }
				setStatus(<?php echo wp_json_encode( $failed ); ?>);
				return;
			}
			opened = true;
			if (window.VMS_EFWP_OverlayApi && typeof window.VMS_EFWP_OverlayApi.activate === 'function') {
				window.VMS_EFWP_OverlayApi.activate();
			}
			try {
				if (typeof window.fastspring.builder.reset === 'function') {
					window.fastspring.builder.reset();
				}
				if (SESSION) {
					window.fastspring.builder.checkout(SESSION);
				} else if (typeof window.fastspring.builder.push === 'function') {
					window.fastspring.builder.push({
						products: [{ path: PRODUCT, quantity: QUANTITY }]
					});
					window.fastspring.builder.checkout();
				} else {
					window.fastspring.builder.checkout();
				}
				if (window.VMS_EFWP_OverlayApi && typeof window.VMS_EFWP_OverlayApi.mount === 'function') {
					window.VMS_EFWP_OverlayApi.mount();
					setTimeout(function () { window.VMS_EFWP_OverlayApi.mount(); }, 100);
					setTimeout(function () { window.VMS_EFWP_OverlayApi.mount(); }, 500);
				}
			} catch (e) {
				setStatus(e && e.message ? e.message : <?php echo wp_json_encode( $failed ); ?>);
			}
		}

		window.VMS_EFWP_PaymentClosed = function (orderReference) {
			if (done) { return; }
			done = true;
			if (window.VMS_EFWP_OverlayApi && typeof window.VMS_EFWP_OverlayApi.deactivate === 'function') {
				window.VMS_EFWP_OverlayApi.deactivate();
			}
			if (window.fastspring && window.fastspring.builder && typeof window.fastspring.builder.reset === 'function') {
				try { window.fastspring.builder.reset(); } catch (e) {}
			}
			if (orderReference && orderReference.id) {
				var target = REDIRECT || FALLBACK_REDIRECT;
				if (target) {
					window.location.replace(appendQueryParam(target, 'fs_order', orderReference.id));
					return;
				}
			}
			setStatus(<?php echo wp_json_encode( $closed ); ?>);
		};

		window.VMS_EFWP_PaymentError = function () {
			setStatus(<?php echo wp_json_encode( $failed ); ?>);
		};

		setInterval(openCheckout, 100);
	})();
	</script>
</body>
</html>
		<?php
	}

	/**
	 * Sanitize a redirect URL or relative path from query args.
	 *
	 * @param string $redirect Redirect value.
	 * @return string
	 */
	public static function sanitize_redirect_param( $redirect ) {
		$redirect = trim( (string) $redirect );
		if ( '' === $redirect ) {
			return '';
		}

		if ( 0 === strpos( $redirect, '/' ) ) {
			return esc_url_raw( home_url( $redirect ) );
		}

		return esc_url_raw( $redirect );
	}
}
