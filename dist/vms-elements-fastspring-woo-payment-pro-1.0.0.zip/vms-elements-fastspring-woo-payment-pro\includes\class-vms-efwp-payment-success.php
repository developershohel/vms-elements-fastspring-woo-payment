<?php
/**
 * Default payment success page for catalog / shortcode checkouts.
 *
 * @package VMS_EFWP
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class VMS_EFWP_Payment_Success.
 */
class VMS_EFWP_Payment_Success {

	const SUCCESS_PAGE_OPTION = 'vms_efwp_payment_success_page_id';

	const SUCCESS_PAGE_SLUG = 'fastspring-payment-success';

	const REWRITE_VERSION_OPTION = 'vms_efwp_payment_success_rewrite_version';

	const REWRITE_VERSION = '1';

	const SUCCESS_ENDPOINT = 'fastspring-payment-success';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_rewrite_rules' ), 5 );
		add_filter( 'query_vars', array( __CLASS__, 'register_query_vars' ) );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_render_success_page' ), 6 );
		self::maybe_flush_rewrite_rules();
	}

	/**
	 * Register the public success page endpoint rewrite rule.
	 */
	public static function register_rewrite_rules() {
		add_rewrite_rule(
			self::SUCCESS_ENDPOINT . '/?$',
			'index.php?vms_efwp_payment_success=1',
			'top'
		);
	}

	/**
	 * Register public query vars.
	 *
	 * @param string[] $vars Query vars.
	 * @return string[]
	 */
	public static function register_query_vars( $vars ) {
		$vars[] = 'vms_efwp_payment_success';
		return $vars;
	}

	/**
	 * Flush rewrite rules after endpoint changes.
	 */
	public static function maybe_flush_rewrite_rules() {
		$stored = (string) get_option( self::REWRITE_VERSION_OPTION, '' );
		if ( $stored === self::REWRITE_VERSION ) {
			return;
		}

		self::register_rewrite_rules();
		flush_rewrite_rules( false );
		update_option( self::REWRITE_VERSION_OPTION, self::REWRITE_VERSION, false );
	}

	/**
	 * Flush rewrite rules immediately (activation / manual repair).
	 */
	public static function flush_rewrite_rules_now() {
		self::register_rewrite_rules();
		flush_rewrite_rules( false );
		update_option( self::REWRITE_VERSION_OPTION, self::REWRITE_VERSION, false );
	}

	/**
	 * Ensure a hidden frontend success page exists.
	 *
	 * @return int Page ID.
	 */
	public static function ensure_success_page() {
		$page_id = absint( get_option( self::SUCCESS_PAGE_OPTION, 0 ) );
		if ( $page_id && get_post( $page_id ) && 'page' === get_post_type( $page_id ) ) {
			return $page_id;
		}

		$configured = 0;
		if ( function_exists( 'vms_efwp' ) && vms_efwp()->settings ) {
			$configured = absint( vms_efwp()->settings->get( 'payment_success_page_id', 0 ) );
		}
		if ( $configured && get_post( $configured ) && 'page' === get_post_type( $configured ) ) {
			update_option( self::SUCCESS_PAGE_OPTION, $configured, false );
			return $configured;
		}

		$existing = get_page_by_path( self::SUCCESS_PAGE_SLUG, OBJECT, 'page' );
		if ( $existing instanceof WP_Post ) {
			update_option( self::SUCCESS_PAGE_OPTION, (int) $existing->ID, false );
			return (int) $existing->ID;
		}

		$page_id = wp_insert_post(
			array(
				'post_title'     => __( 'Payment successful', 'vms-elements-fastspring-woo-payment-pro' ),
				'post_name'      => self::SUCCESS_PAGE_SLUG,
				'post_status'    => 'publish',
				'post_type'      => 'page',
				'post_content'   => '<!-- FastSpring payment success page -->',
				'comment_status' => 'closed',
				'ping_status'    => 'closed',
			),
			true
		);

		if ( is_wp_error( $page_id ) || ! $page_id ) {
			return 0;
		}

		update_option( self::SUCCESS_PAGE_OPTION, (int) $page_id, false );
		return (int) $page_id;
	}

	/**
	 * Resolve the success page ID.
	 *
	 * @return int
	 */
	public static function get_success_page_id() {
		return self::ensure_success_page();
	}

	/**
	 * Base URL for the default payment success page.
	 *
	 * @return string
	 */
	public static function get_success_page_url() {
		$page_id = self::get_success_page_id();
		if ( $page_id ) {
			$url = get_permalink( $page_id );
			if ( $url ) {
				return $url;
			}
		}

		return home_url( user_trailingslashit( self::SUCCESS_ENDPOINT ) );
	}

	/**
	 * Build the redirect URL after payment completes.
	 *
	 * @param string      $fs_order_id     FastSpring order ID.
	 * @param string      $custom_redirect Optional custom redirect URL/path.
	 * @param bool|null   $show_details    Whether to include details on the default page.
	 * @return string
	 */
	public static function build_post_payment_url( $fs_order_id, $custom_redirect = '', $show_details = null ) {
		$fs_order_id = sanitize_text_field( (string) $fs_order_id );
		$url         = self::resolve_post_payment_redirect( $custom_redirect, $show_details );

		if ( '' === $fs_order_id ) {
			return $url;
		}

		return add_query_arg( 'fs_order', $fs_order_id, $url );
	}

	/**
	 * Resolve redirect URL after payment.
	 *
	 * @param string $redirect     Custom redirect URL/path.
	 * @param bool   $show_details Whether order details should be shown on the default page.
	 * @return string
	 */
	public static function resolve_post_payment_redirect( $redirect, $show_details = null ) {
		$redirect = VMS_EFWP_Checkout_Links::sanitize_redirect_param( $redirect );
		if ( $redirect ) {
			return $redirect;
		}

		$url = self::get_success_page_url();
		if ( null === $show_details ) {
			$show_details = self::default_show_details();
		}

		if ( $show_details ) {
			$url = add_query_arg( 'details', '1', $url );
		}

		return $url;
	}

	/**
	 * Global default for showing order details on the success page.
	 *
	 * @return bool
	 */
	public static function default_show_details() {
		if ( ! function_exists( 'vms_efwp' ) || ! vms_efwp()->settings ) {
			return true;
		}

		return 'yes' === vms_efwp()->settings->get( 'payment_success_show_details', 'yes' );
	}

	/**
	 * Parse shortcode/details flag.
	 *
	 * @param string $value Raw attribute value.
	 * @return bool|null Null = use global default.
	 */
	public static function parse_details_flag( $value ) {
		$value = strtolower( trim( (string) $value ) );
		if ( '' === $value ) {
			return null;
		}

		if ( in_array( $value, array( '1', 'yes', 'true', 'on' ), true ) ) {
			return true;
		}

		if ( in_array( $value, array( '0', 'no', 'false', 'off' ), true ) ) {
			return false;
		}

		return null;
	}

	/**
	 * Whether the current request should render the success template.
	 *
	 * @return bool
	 */
	private static function is_success_page_request() {
		if ( get_query_var( 'vms_efwp_payment_success' ) ) {
			return true;
		}

		$page_id = self::get_success_page_id();
		if ( $page_id && is_page( $page_id ) ) {
			return true;
		}

		global $wp;
		if ( isset( $wp->request ) && preg_match( '#(^|/)' . preg_quote( self::SUCCESS_ENDPOINT, '#' ) . '/?$#', (string) $wp->request ) ) {
			return true;
		}

		$pagename = get_query_var( 'pagename' );
		return self::SUCCESS_PAGE_SLUG === $pagename || self::SUCCESS_ENDPOINT === $pagename;
	}

	/**
	 * Render the payment success page when fs_order is present.
	 */
	public static function maybe_render_success_page() {
		if ( is_admin() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public return URL from FastSpring checkout.
		$fs_order_id = isset( $_GET['fs_order'] ) ? sanitize_text_field( wp_unslash( $_GET['fs_order'] ) ) : '';
		if ( '' === $fs_order_id ) {
			return;
		}

		if ( ! self::is_success_page_request() ) {
			return;
		}

		$show_details = self::should_show_details_from_request();
		self::render_success_page( $fs_order_id, $show_details );
		exit;
	}

	/**
	 * Determine whether order details should render for this request.
	 *
	 * @return bool
	 */
	public static function should_show_details_from_request() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Public return URL flag.
		if ( isset( $_GET['details'] ) ) {
			$flag = sanitize_text_field( wp_unslash( $_GET['details'] ) );
			// phpcs:enable WordPress.Security.NonceVerification.Recommended
			return self::parse_details_flag( $flag ) ?? false;
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		return self::default_show_details();
	}

	/**
	 * Output the payment success page.
	 *
	 * @param string $fs_order_id  FastSpring order ID.
	 * @param bool   $show_details Whether to fetch and show order details.
	 */
	public static function render_success_page( $fs_order_id, $show_details = true ) {
		$fs_order_id = sanitize_text_field( (string) $fs_order_id );
		$order       = null;
		$order_error = '';
		$invoice_url = '';

		if ( function_exists( 'vms_efwp' ) && vms_efwp()->api ) {
			$synced = vms_efwp()->api->sync_completed_order( $fs_order_id );
			if ( is_wp_error( $synced ) ) {
				$order_error = $synced->get_error_message();
				$response    = vms_efwp()->api->get_order( $fs_order_id );
				if ( ! is_wp_error( $response ) ) {
					$parsed = vms_efwp()->api->parse_order( $response );
					if ( ! is_wp_error( $parsed ) ) {
						$order = $parsed;
					}
				}
			} else {
				$order = $synced;
			}

			if ( is_array( $order ) ) {
				$invoice_meta = VMS_EFWP_Data_Store::resolve_order_invoice_meta( $order );
				$invoice_url  = $invoice_meta['invoice_url'] ? (string) $invoice_meta['invoice_url'] : '';
			}
		}

		$title    = __( 'Payment successful', 'vms-elements-fastspring-woo-payment-pro' );
		$subtitle = __( 'Thank you for your purchase.', 'vms-elements-fastspring-woo-payment-pro' );
		$home_url = home_url( '/' );

		nocache_headers();
		?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta name="robots" content="noindex,nofollow" />
	<title><?php echo esc_html( $title ); ?></title>
	<?php
		VMS_EFWP_Assets::register_checkout_assets();
		wp_enqueue_style( 'vms-efwp-payment-success' );
		wp_print_styles( array( 'vms-efwp-payment-success' ) );
		?>
</head>
<body class="vms-efwp-payment-success">
	<main class="vms-efwp-payment-success__card">
		<div class="vms-efwp-payment-success__icon" aria-hidden="true">&#10003;</div>
		<h1><?php echo esc_html( $title ); ?></h1>
		<p class="vms-efwp-payment-success__lead"><?php echo esc_html( $subtitle ); ?></p>

		<?php if ( $show_details ) : ?>
			<?php self::render_order_details_block( $fs_order_id, $order, $order_error, $invoice_url ); ?>
		<?php else : ?>
			<p class="vms-efwp-payment-success__meta">
				<?php
				printf(
					/* translators: %s: FastSpring order ID */
					esc_html__( 'Order reference: %s', 'vms-elements-fastspring-woo-payment-pro' ),
					esc_html( $fs_order_id )
				);
				?>
			</p>
		<?php endif; ?>

		<p class="vms-efwp-payment-success__actions">
			<a class="vms-efwp-payment-success__button" href="<?php echo esc_url( $home_url ); ?>">
				<?php esc_html_e( 'Return to site', 'vms-elements-fastspring-woo-payment-pro' ); ?>
			</a>
		</p>
	</main>
</body>
</html>
		<?php
	}

	/**
	 * Render order details table/list.
	 *
	 * @param string     $fs_order_id FastSpring order ID.
	 * @param array|null $order       Parsed order payload.
	 * @param string     $order_error Optional fetch error.
	 * @param string     $invoice_url Invoice URL when available.
	 */
	private static function render_order_details_block( $fs_order_id, $order, $order_error = '', $invoice_url = '' ) {
		if ( $order_error ) {
			echo '<p class="vms-efwp-payment-success__notice">' . esc_html( $order_error ) . '</p>';
		}

		$reference = $fs_order_id;
		$email     = '';
		$total     = '';
		$currency  = '';
		$items     = array();

		if ( is_array( $order ) ) {
			$reference = isset( $order['id'] ) ? (string) $order['id'] : ( isset( $order['order'] ) ? (string) $order['order'] : $fs_order_id );
			$email     = isset( $order['customer']['email'] ) ? (string) $order['customer']['email'] : '';
			if ( '' === $email && isset( $order['payment']['email'] ) ) {
				$email = (string) $order['payment']['email'];
			}
			$currency = isset( $order['currency'] ) ? (string) $order['currency'] : '';
			if ( isset( $order['totalDisplay'] ) ) {
				$total = (string) $order['totalDisplay'];
			} elseif ( isset( $order['total'] ) ) {
				$total = (string) $order['total'];
				if ( $currency ) {
					$total = trim( $currency . ' ' . $total );
				}
			}
			if ( ! empty( $order['items'] ) && is_array( $order['items'] ) ) {
				$items = $order['items'];
			}
			if ( '' === $invoice_url ) {
				$invoice_meta = VMS_EFWP_Data_Store::resolve_order_invoice_meta( $order );
				$invoice_url  = $invoice_meta['invoice_url'] ? (string) $invoice_meta['invoice_url'] : '';
			}
		}
		?>
		<div class="vms-efwp-payment-success__details">
			<h2><?php esc_html_e( 'Order details', 'vms-elements-fastspring-woo-payment-pro' ); ?></h2>
			<dl class="vms-efwp-payment-success__meta-list">
				<div>
					<dt><?php esc_html_e( 'Order ID', 'vms-elements-fastspring-woo-payment-pro' ); ?></dt>
					<dd><?php echo esc_html( $reference ); ?></dd>
				</div>
				<?php if ( $email ) : ?>
				<div>
					<dt><?php esc_html_e( 'Email', 'vms-elements-fastspring-woo-payment-pro' ); ?></dt>
					<dd><?php echo esc_html( $email ); ?></dd>
				</div>
				<?php endif; ?>
				<?php if ( $total ) : ?>
				<div>
					<dt><?php esc_html_e( 'Total', 'vms-elements-fastspring-woo-payment-pro' ); ?></dt>
					<dd><?php echo esc_html( $total ); ?></dd>
				</div>
				<?php endif; ?>
				<?php if ( $invoice_url ) : ?>
				<div>
					<dt><?php esc_html_e( 'Invoice', 'vms-elements-fastspring-woo-payment-pro' ); ?></dt>
					<dd><a href="<?php echo esc_url( $invoice_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'View invoice', 'vms-elements-fastspring-woo-payment-pro' ); ?></a></dd>
				</div>
				<?php endif; ?>
			</dl>

			<?php if ( ! empty( $items ) ) : ?>
				<table class="vms-efwp-payment-success__items">
					<thead>
						<tr>
							<th scope="col"><?php esc_html_e( 'Product', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Qty', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Price', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $items as $item ) : ?>
							<?php
							if ( ! is_array( $item ) ) {
								continue;
							}
							$display = isset( $item['display'] ) ? (string) $item['display'] : ( isset( $item['product'] ) ? (string) $item['product'] : '' );
							$qty     = isset( $item['quantity'] ) ? (int) $item['quantity'] : 1;
							$price   = isset( $item['subtotalDisplay'] ) ? (string) $item['subtotalDisplay'] : ( isset( $item['subtotal'] ) ? (string) $item['subtotal'] : '' );
							?>
							<tr>
								<td><?php echo esc_html( $display ); ?></td>
								<td><?php echo esc_html( (string) $qty ); ?></td>
								<td><?php echo esc_html( $price ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
		<?php
	}
}
