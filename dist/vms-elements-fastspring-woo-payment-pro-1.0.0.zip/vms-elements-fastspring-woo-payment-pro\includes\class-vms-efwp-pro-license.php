<?php
/**
 * Pro license facade (VMS Elements license API).
 *
 * @package VMS_EFWP_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class VMS_EFWP_Pro_License.
 */
class VMS_EFWP_Pro_License {

	/**
	 * Legacy hook — licensing is bootstrapped from VMS_EFWP_Pro::init().
	 */
	public static function init() {
		// Intentionally empty.
	}

	/**
	 * Whether the stored license is valid.
	 *
	 * @return bool
	 */
	public static function is_valid() {
		if ( ! class_exists( 'VMS_EFWP_Pro\Licensing\License_Manager', false ) ) {
			return false;
		}

		return VMS_EFWP_Pro\Licensing\License_Manager::instance()->is_pro_active();
	}

	/**
	 * Get stored license data (legacy shape for admin helpers).
	 *
	 * @return array
	 */
	public static function get_data() {
		if ( ! class_exists( 'VMS_EFWP_Pro\Licensing\License_Manager', false ) ) {
			return array();
		}

		$info = VMS_EFWP_Pro\Licensing\License_Manager::instance()->get_info();
		if ( ! is_object( $info ) || empty( $info->license_key ) ) {
			return array();
		}

		$expire = isset( $info->expire_date ) ? (string) $info->expire_date : '';
		if ( 'No Expiry' === $expire || 'unlimited' === strtolower( $expire ) ) {
			$expire = 'lifetime';
		}

		return array(
			'key'        => (string) $info->license_key,
			'status'     => self::is_valid() ? 'valid' : 'invalid',
			'expires'    => $expire,
			'error'      => '',
			'last_check' => gmdate( 'Y-m-d H:i:s' ),
		);
	}

	/**
	 * Mask a license key for display.
	 *
	 * @param string $key License key.
	 * @return string
	 */
	public static function mask_key( $key ) {
		$key = sanitize_text_field( (string) $key );
		if ( strlen( $key ) <= 8 ) {
			return $key;
		}
		return substr( $key, 0, 4 ) . str_repeat( '*', max( 4, strlen( $key ) - 8 ) ) . substr( $key, -4 );
	}

	/**
	 * Activate a license key.
	 *
	 * @param string $license_key License key.
	 * @param string $email       Optional email.
	 * @return true|WP_Error
	 */
	public static function activate( $license_key, $email = '' ) {
		if ( ! class_exists( 'VMS_EFWP_Pro\Licensing\License_Manager', false ) ) {
			return new WP_Error( 'missing_license', __( 'License manager is not available.', 'vms-elements-fastspring-woo-payment-pro' ) );
		}

		$result = VMS_EFWP_Pro\Licensing\License_Manager::instance()->activate( (string) $license_key, (string) $email );
		if ( ! empty( $result['success'] ) ) {
			return true;
		}

		return new WP_Error( 'activation_failed', (string) ( $result['message'] ?? __( 'License activation failed.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
	}

	/**
	 * Deactivate the current license key.
	 *
	 * @return true|WP_Error
	 */
	public static function deactivate() {
		if ( ! class_exists( 'VMS_EFWP_Pro\Licensing\License_Manager', false ) ) {
			return true;
		}

		$result = VMS_EFWP_Pro\Licensing\License_Manager::instance()->deactivate();
		if ( ! empty( $result['success'] ) ) {
			return true;
		}

		return new WP_Error( 'deactivation_failed', (string) ( $result['message'] ?? __( 'Could not deactivate license.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
	}

	/**
	 * Refresh license status from the store.
	 *
	 * @return true|WP_Error
	 */
	public static function check() {
		if ( ! class_exists( 'VMS_EFWP_Pro\Licensing\License_Manager', false ) ) {
			return new WP_Error( 'missing_license', __( 'No license key saved.', 'vms-elements-fastspring-woo-payment-pro' ) );
		}

		$result = VMS_EFWP_Pro\Licensing\License_Manager::instance()->verify();
		if ( ! empty( $result['success'] ) ) {
			return true;
		}

		return new WP_Error( 'invalid_license', (string) ( $result['message'] ?? __( 'License is not valid for this site.', 'vms-elements-fastspring-woo-payment-pro' ) ) );
	}

	/**
	 * Human-readable license status label.
	 *
	 * @param string $status Raw status.
	 * @return string
	 */
	public static function status_label( $status ) {
		if ( class_exists( 'VMS_EFWP_Pro\Licensing\License_Manager', false ) ) {
			return VMS_EFWP_Pro\Licensing\License_Manager::instance()->status_label();
		}

		$labels = array(
			'valid'    => __( 'Valid', 'vms-elements-fastspring-woo-payment-pro' ),
			'active'   => __( 'Active', 'vms-elements-fastspring-woo-payment-pro' ),
			'invalid'  => __( 'Invalid', 'vms-elements-fastspring-woo-payment-pro' ),
			'inactive' => __( 'Inactive', 'vms-elements-fastspring-woo-payment-pro' ),
		);

		$status = sanitize_key( (string) $status );
		return isset( $labels[ $status ] ) ? $labels[ $status ] : ucfirst( $status );
	}
}
