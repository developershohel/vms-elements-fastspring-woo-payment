<?php
/**
 * Loads Pro-only modules after a valid license is confirmed.
 *
 * @package VMS_EFWP_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class VMS_EFWP_Pro_Modules.
 */
class VMS_EFWP_Pro_Modules {

	/**
	 * Boot Pro modules once the free plugin core is loaded.
	 */
	public static function boot() {
		if ( ! VMS_EFWP_Pro_License::is_valid() ) {
			return;
		}

		self::includes();

		add_action( 'vms_efwp_init', array( __CLASS__, 'on_init' ), 20 );

		if ( is_admin() ) {
			require_once VMS_EFWP_PRO_PATH . 'includes/admin/class-vms-efwp-pro-admin-features.php';
			VMS_EFWP_Pro_Admin_Features::init();
		}

		if ( function_exists( 'vms_efwp' ) && vms_efwp()->is_woocommerce_active() ) {
			vms_efwp()->product_sync = new VMS_EFWP_Product_Sync( vms_efwp()->api, vms_efwp()->settings );
		}

		do_action( 'vms_efwp_pro_modules_loaded' );
	}

	/**
	 * Require Pro class files (not shipped in the free plugin).
	 */
	private static function includes() {
		$base  = VMS_EFWP_PRO_PATH . 'includes/';
		$admin = $base . 'admin/';

		if ( ! class_exists( 'VMS_EFWP_Stats', false ) ) {
			require_once $base . 'class-vms-efwp-stats.php';
		}
		require_once $base . 'class-vms-efwp-product-sync.php';
		if ( ! class_exists( 'VMS_EFWP_Checkout_Overlay', false ) ) {
			require_once $base . 'class-vms-efwp-checkout-overlay.php';
		}
		require_once $base . 'class-vms-efwp-checkout-links.php';
		require_once $base . 'class-vms-efwp-payment-success.php';
		require_once $base . 'class-vms-efwp-shortcodes.php';
		require_once $base . 'class-vms-efwp-wc-account-subscriptions.php';
		if ( ! class_exists( 'VMS_EFWP_WC_Blocks', false ) ) {
			require_once $base . 'class-vms-efwp-wc-blocks.php';
		}

		require_once $admin . 'class-vms-efwp-pro-admin-dashboard.php';
		require_once $admin . 'class-vms-efwp-admin-subscriptions.php';
		require_once $admin . 'class-vms-efwp-admin-products.php';
		require_once $admin . 'class-vms-efwp-admin-coupons.php';
		require_once $admin . 'class-vms-efwp-admin-invoices.php';
		require_once $admin . 'class-vms-efwp-admin-quotes.php';
		require_once $admin . 'class-vms-efwp-admin-returns.php';
		require_once $admin . 'class-vms-efwp-admin-sessions.php';
		require_once $admin . 'class-vms-efwp-admin-accounts.php';
		require_once $admin . 'class-vms-efwp-admin-events.php';
		require_once $admin . 'class-vms-efwp-admin-reports.php';
		require_once $admin . 'class-vms-efwp-admin-webhooks.php';
		require_once $admin . 'class-vms-efwp-admin-tools.php';
		require_once $admin . 'class-vms-efwp-admin-shortcodes.php';
		require_once $admin . 'class-vms-efwp-pro-admin-ajax.php';
	}

	/**
	 * Pro frontend/admin init hooks.
	 */
	public static function on_init() {
		VMS_EFWP_Checkout_Links::init();
		VMS_EFWP_Checkout_Links::ensure_checkout_page();
		VMS_EFWP_Payment_Success::init();
		VMS_EFWP_Payment_Success::ensure_success_page();
		VMS_EFWP_Shortcodes::init();

		if ( function_exists( 'vms_efwp' ) && vms_efwp()->is_woocommerce_active() ) {
			VMS_EFWP_WC_Account_Subscriptions::init();
		}
	}

	/**
	 * Activation tasks for Pro (pages, rewrite rules).
	 */
	public static function activate() {
		if ( ! self::includes_for_activation() ) {
			return;
		}
		VMS_EFWP_Checkout_Links::ensure_checkout_page();
		VMS_EFWP_Payment_Success::ensure_success_page();
		VMS_EFWP_Payment_Success::flush_rewrite_rules_now();
		VMS_EFWP_Checkout_Links::flush_rewrite_rules_now();
		if ( class_exists( 'WooCommerce' ) ) {
			VMS_EFWP_WC_Account_Subscriptions::schedule_rewrite_flush();
		}
		flush_rewrite_rules();
	}

	/**
	 * Load only the files needed during Pro plugin activation.
	 *
	 * @return bool
	 */
	private static function includes_for_activation() {
		if ( ! function_exists( 'vms_efwp' ) ) {
			return false;
		}
		$base = VMS_EFWP_PRO_PATH . 'includes/';
		require_once $base . 'class-vms-efwp-checkout-links.php';
		require_once $base . 'class-vms-efwp-payment-success.php';
		require_once $base . 'class-vms-efwp-wc-account-subscriptions.php';
		return true;
	}
}
