<?php
/**
 * Pro add-on bootstrap.
 *
 * @package VMS_EFWP_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class VMS_EFWP_Pro.
 */
final class VMS_EFWP_Pro {

	/**
	 * Free base plugin basename relative to wp-content/plugins.
	 */
	const FREE_PLUGIN_BASENAME = 'vms-elements-fastspring-woo-payment/vms-elements-fastspring-woo-payment.php';

	/**
	 * Boot the Pro add-on (runs before the free plugin on plugins_loaded).
	 */
	public static function init() {
		if ( is_admin() ) {
			self::register_dependency_guards();
		}

		if ( ! self::free_plugin_active() ) {
			add_action( 'admin_notices', array( __CLASS__, 'render_missing_free_notice' ) );
			return;
		}

		add_action( 'init', array( __CLASS__, 'load_shared_textdomain' ), 1 );

		require_once VMS_EFWP_PRO_PATH . 'licensing/class-license-base.php';
		require_once VMS_EFWP_PRO_PATH . 'licensing/class-license-manager.php';
		require_once VMS_EFWP_PRO_PATH . 'licensing/class-license-admin.php';
		require_once VMS_EFWP_PRO_PATH . 'includes/class-vms-efwp-pro-license.php';

		VMS_EFWP_Pro\Licensing\License_Manager::instance();

		if ( is_admin() ) {
			new VMS_EFWP_Pro\Licensing\License_Admin();
			add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_license_heartbeat' ), 10 );
			require_once VMS_EFWP_PRO_PATH . 'includes/admin/class-vms-efwp-pro-admin.php';
			VMS_EFWP_Pro_Admin::init();

			if ( ! apply_filters( 'vms_efwp_is_pro', false ) ) {
				add_action( 'admin_notices', array( __CLASS__, 'render_inactive_license_notice' ) );
			}
		}

		if ( ! apply_filters( 'vms_efwp_is_pro', false ) ) {
			return;
		}

		require_once VMS_EFWP_PRO_PATH . 'includes/class-vms-efwp-pro-modules.php';
		add_action( 'vms_efwp_loaded', array( 'VMS_EFWP_Pro_Modules', 'boot' ), 20 );
	}

	/**
	 * Load translations from the free plugin languages directory (shared catalog, pro text domain).
	 */
	public static function load_shared_textdomain() {
		if ( ! defined( 'VMS_EFWP_PATH' ) ) {
			return;
		}

		$locale = function_exists( 'determine_locale' ) ? determine_locale() : get_locale();
		$mofile = VMS_EFWP_PATH . 'languages/vms-elements-fastspring-woo-payment-' . $locale . '.mo';
		if ( ! file_exists( $mofile ) ) {
			$mofile = VMS_EFWP_PATH . 'languages/vms-elements-fastspring-woo-payment.mo';
		}
		if ( file_exists( $mofile ) ) {
			load_textdomain( 'vms-elements-fastspring-woo-payment-pro', $mofile );
		}
	}

	/**
	 * Admin-side license heartbeat (re-validates every 5 minutes).
	 *
	 * @param string $hook_suffix Current admin page hook.
	 */
	public static function enqueue_license_heartbeat( $hook_suffix = '' ) {
		$hook_suffix = (string) $hook_suffix;
		if ( false === strpos( $hook_suffix, 'vms-efwp' ) ) {
			return;
		}

		if ( ! class_exists( 'VMS_EFWP_Pro\Licensing\License_Manager', false ) ) {
			return;
		}

		$manager = VMS_EFWP_Pro\Licensing\License_Manager::instance();
		if ( ! $manager->should_run_admin_heartbeat() ) {
			return;
		}

		$handle = 'vms-efwp-pro-license-heartbeat';
		wp_enqueue_script(
			$handle,
			VMS_EFWP_PRO_URL . 'assets/js/license-heartbeat.js',
			array( 'jquery' ),
			VMS_EFWP_PRO_VERSION,
			true
		);

		wp_localize_script(
			$handle,
			'VMSEFWPChecker',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'vms_efwp_pro_nonce' ),
				'license' => array(
					'heartbeat'       => true,
					'interval'        => VMS_EFWP_Pro\Licensing\License_Base::REFRESH_INTERVAL,
					'ajaxUrl'         => admin_url( 'admin-ajax.php' ),
					'nonce'           => wp_create_nonce( 'vms_efwp_pro_nonce' ),
					'licenseUrl'      => admin_url( 'admin.php?page=vms-efwp-pro-license' ),
					'redirectDelayMs' => 1500,
					'forceSelector'   => 'button[name="license_action"][value="verify"]',
				),
			)
		);
	}

	/**
	 * Activation hook.
	 */
	public static function activate() {
		if ( ! self::free_plugin_active() ) {
			deactivate_plugins( VMS_EFWP_PRO_BASENAME );
			wp_die(
				esc_html__( 'VMS Elements Fastspring Woo Payment Pro requires the free VMS Elements Fastspring Woo Payment plugin to be installed and active.', 'vms-elements-fastspring-woo-payment-pro' ),
				esc_html__( 'Plugin dependency check', 'vms-elements-fastspring-woo-payment-pro' ),
				array( 'back_link' => true )
			);
		}

		require_once VMS_EFWP_PRO_PATH . 'licensing/class-license-base.php';
		require_once VMS_EFWP_PRO_PATH . 'licensing/class-license-manager.php';
		VMS_EFWP_Pro\Licensing\License_Manager::instance()->ensure_cron_scheduled();

		require_once VMS_EFWP_PRO_PATH . 'includes/class-vms-efwp-pro-modules.php';
		VMS_EFWP_Pro_Modules::activate();
	}

	/**
	 * Deactivation hook.
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( 'vms_efwp_pro_license_refresh' );
		wp_clear_scheduled_hook( 'vms_efwp_pro_license_check' );
	}

	/**
	 * Register plugins-screen guards so Pro cannot be activated without the free plugin.
	 */
	public static function register_dependency_guards() {
		add_filter( 'plugin_action_links_' . VMS_EFWP_PRO_BASENAME, array( __CLASS__, 'filter_pro_action_links' ) );
		add_action( 'after_plugin_row_' . VMS_EFWP_PRO_BASENAME, array( __CLASS__, 'render_dependency_plugin_row' ), 10, 2 );
		add_action( 'pre_plugin_activate_' . VMS_EFWP_PRO_BASENAME, array( __CLASS__, 'guard_pro_activation' ) );
		add_action( 'deactivated_plugin', array( __CLASS__, 'deactivate_pro_when_free_deactivated' ), 10, 1 );
	}

	/**
	 * Remove/disable Activate when the free plugin is missing or inactive.
	 *
	 * @param string[] $links Plugin action links.
	 * @return string[]
	 */
	public static function filter_pro_action_links( $links ) {
		if ( self::free_plugin_active() ) {
			return $links;
		}

		unset( $links['activate'] );

		if ( self::free_plugin_installed() && current_user_can( 'activate_plugins' ) ) {
			$free_basename = self::FREE_PLUGIN_BASENAME;
			$activate_url  = wp_nonce_url(
				admin_url( 'plugins.php?action=activate&plugin=' . rawurlencode( $free_basename ) ),
				'activate-plugin_' . $free_basename
			);
			$links['activate-free-first'] = sprintf(
				'<a href="%1$s">%2$s</a>',
				esc_url( $activate_url ),
				esc_html__( 'Activate free plugin first', 'vms-elements-fastspring-woo-payment-pro' )
			);
		}

		return $links;
	}

	/**
	 * Inline dependency message under the Pro row on Plugins.
	 *
	 * @param string $plugin_file Plugin basename.
	 * @param array  $plugin_data Plugin metadata.
	 */
	public static function render_dependency_plugin_row( $plugin_file, $plugin_data ) {
		unset( $plugin_data );

		if ( self::free_plugin_active() || VMS_EFWP_PRO_BASENAME !== $plugin_file ) {
			return;
		}

		$message = self::free_plugin_installed()
			? __( 'VMS Elements Fastspring Woo Payment Pro requires the free VMS Elements Fastspring Woo Payment plugin to be active. Activate the free plugin first.', 'vms-elements-fastspring-woo-payment-pro' )
			: __( 'VMS Elements Fastspring Woo Payment Pro requires the free VMS Elements Fastspring Woo Payment plugin to be installed and active.', 'vms-elements-fastspring-woo-payment-pro' );

		$colspan = is_network_admin() ? 4 : 3;
		printf(
			'<tr class="plugin-update-tr vms-efwp-pro-dependency-row"><td colspan="%1$d" class="plugin-update colspanchange"><div class="update-message notice inline notice-error notice-alt"><p>%2$s</p></div></td></tr>',
			(int) $colspan,
			esc_html( $message )
		);
	}

	/**
	 * Block direct activation URLs when the free plugin is not active.
	 */
	public static function guard_pro_activation() {
		if ( self::free_plugin_active() ) {
			return;
		}

		if ( ! function_exists( 'deactivate_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		deactivate_plugins( VMS_EFWP_PRO_BASENAME, true );

		wp_safe_redirect(
			add_query_arg(
				array(
					'vms_efwp_pro_dependency' => '1',
				),
				self::plugins_admin_url()
			)
		);
		exit;
	}

	/**
	 * Deactivate Pro automatically when the free base plugin is turned off.
	 *
	 * @param string $plugin Deactivated plugin basename.
	 */
	public static function deactivate_pro_when_free_deactivated( $plugin ) {
		if ( self::FREE_PLUGIN_BASENAME !== $plugin ) {
			return;
		}

		if ( ! function_exists( 'deactivate_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		if ( is_plugin_active( VMS_EFWP_PRO_BASENAME ) ) {
			deactivate_plugins( VMS_EFWP_PRO_BASENAME, true );
		}
	}

	/**
	 * Plugins screen URL (site or network admin).
	 *
	 * @return string
	 */
	private static function plugins_admin_url() {
		return is_network_admin() ? network_admin_url( 'plugins.php' ) : admin_url( 'plugins.php' );
	}

	/**
	 * Whether the free base plugin is installed.
	 *
	 * @return bool
	 */
	public static function free_plugin_installed() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugins = get_plugins();
		return isset( $plugins[ self::FREE_PLUGIN_BASENAME ] );
	}

	/**
	 * Whether the free base plugin is active.
	 *
	 * @return bool
	 */
	public static function free_plugin_active() {
		if ( function_exists( 'vms_efwp' ) || class_exists( 'VMS_EFWP', false ) ) {
			return true;
		}

		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		return is_plugin_active( self::FREE_PLUGIN_BASENAME );
	}

	/**
	 * Admin notice when the free plugin is missing.
	 */
	public static function render_missing_free_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Query flag after guarded redirect only.
		if ( isset( $_GET['vms_efwp_pro_dependency'] ) && '1' === $_GET['vms_efwp_pro_dependency'] ) {
			printf(
				'<div class="notice notice-error is-dismissible"><p>%s</p></div>',
				esc_html__( 'VMS Elements Fastspring Woo Payment Pro requires the free VMS Elements Fastspring Woo Payment plugin to be installed and active.', 'vms-elements-fastspring-woo-payment-pro' )
			);
			return;
		}

		printf(
			'<div class="notice notice-error"><p>%s</p></div>',
			esc_html__( 'VMS Elements Fastspring Woo Payment Pro requires the free VMS Elements Fastspring Woo Payment plugin. Please install and activate it first.', 'vms-elements-fastspring-woo-payment-pro' )
		);
	}

	/**
	 * Admin notice when Pro is installed but the license is inactive.
	 */
	public static function render_inactive_license_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$url = admin_url( 'admin.php?page=vms-efwp-pro-license' );
		printf(
			'<div class="notice notice-warning"><p><strong>%1$s</strong> %2$s <a href="%3$s" class="button button-primary" style="margin-left:8px;">%4$s</a></p></div>',
			esc_html__( 'VMS Elements Fastspring Woo Payment Pro:', 'vms-elements-fastspring-woo-payment-pro' ),
			esc_html__( 'no license is active, so Pro features are disabled.', 'vms-elements-fastspring-woo-payment-pro' ),
			esc_url( $url ),
			esc_html__( 'Activate license', 'vms-elements-fastspring-woo-payment-pro' )
		);
	}
}
