<?php
/**
 * One-way product sync: WooCommerce -> FastSpring.
 *
 * @package VMS_EFWP
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class VMS_EFWP_Product_Sync.
 */
class VMS_EFWP_Product_Sync {

	/**
	 * API.
	 *
	 * @var VMS_EFWP_API
	 */
	private $api;

	/**
	 * Settings.
	 *
	 * @var VMS_EFWP_Settings
	 */
	private $settings;

	/**
	 * Constructor.
	 *
	 * @param VMS_EFWP_API      $api      API.
	 * @param VMS_EFWP_Settings $settings Settings.
	 */
	public function __construct( VMS_EFWP_API $api, VMS_EFWP_Settings $settings ) {
		$this->api      = $api;
		$this->settings = $settings;

		add_action( 'save_post_product', array( $this, 'on_product_save' ), 20, 3 );
	}

	/**
	 * Sync a product on save when the option is enabled.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post.
	 * @param bool    $update  Update flag.
	 */
	public function on_product_save( $post_id, $post, $update ) {
		unset( $post, $update );

		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}
		if ( 'yes' !== $this->settings->get( 'sync_products', 'no' ) ) {
			return;
		}
		if ( ! $this->settings->has_credentials() ) {
			return;
		}
		if ( ! function_exists( 'wc_get_product' ) ) {
			return;
		}

		$product = wc_get_product( $post_id );
		if ( ! $product ) {
			return;
		}

		$result = $this->push_wc_product_to_fastspring( $product );
		if ( is_wp_error( $result ) ) {
			VMS_EFWP_Logger::error( 'Product sync failed: ' . $result->get_error_message(), 'sync', array( 'product_id' => $post_id ) );
			update_post_meta( $post_id, '_fastspring_sync_error', $result->get_error_message() );
			return;
		}

		update_post_meta( $post_id, '_vms_efwp_product_path', $result );
		delete_post_meta( $post_id, '_fastspring_sync_error' );
		VMS_EFWP_Logger::info( 'Synced product to FastSpring: ' . $result, 'sync' );
	}

	/**
	 * Ensure every unique product in an order exists in FastSpring.
	 *
	 * Used by the per-product override pricing strategy at checkout, regardless
	 * of whether background product sync is enabled.
	 *
	 * @param WC_Order $order Order.
	 * @return true|WP_Error
	 */
	public function ensure_order_products_in_fastspring( WC_Order $order ) {
		if ( ! $this->settings->has_credentials() ) {
			return new WP_Error(
				'vms_efwp_ensure_products',
				__( 'FastSpring API credentials are not configured for the active mode.', 'vms-elements-fastspring-woo-payment-pro' )
			);
		}

		$currency = strtoupper( (string) $order->get_currency() );
		$seen     = array();

		foreach ( $order->get_items() as $item ) {
			if ( ! is_object( $item ) || ! method_exists( $item, 'get_product' ) ) {
				continue;
			}

			$product = $item->get_product();
			if ( ! $product instanceof WC_Product ) {
				continue;
			}

			$product_id = $product->get_id();
			if ( isset( $seen[ $product_id ] ) ) {
				continue;
			}
			$seen[ $product_id ] = true;

			$result = $this->ensure_wc_product_in_fastspring( $product, $currency );
			if ( is_wp_error( $result ) ) {
				return new WP_Error(
					'vms_efwp_ensure_products',
					sprintf(
						/* translators: 1: WooCommerce product name, 2: API error message */
						__( 'Could not add "%1$s" to FastSpring automatically: %2$s', 'vms-elements-fastspring-woo-payment-pro' ),
						$product->get_name(),
						$result->get_error_message()
					)
				);
			}
		}

		return true;
	}

	/**
	 * Create a FastSpring catalog product for a WooCommerce product when missing.
	 *
	 * @param WC_Product $product  Product.
	 * @param string     $currency Order currency code.
	 * @return string|WP_Error Product path on success.
	 */
	public function ensure_wc_product_in_fastspring( WC_Product $product, $currency = '' ) {
		if ( ! $this->settings->has_credentials() ) {
			return new WP_Error(
				'vms_efwp_ensure_product',
				__( 'FastSpring API credentials are not configured for the active mode.', 'vms-elements-fastspring-woo-payment-pro' )
			);
		}

		$currency = $currency ? strtoupper( $currency ) : strtoupper( get_woocommerce_currency() );
		$slug     = $this->build_path( $product );

		if ( $this->api->product_exists( $slug ) ) {
			update_post_meta( $product->get_id(), '_vms_efwp_product_path', $slug );
			delete_post_meta( $product->get_id(), '_fastspring_sync_error' );
			return $slug;
		}

		$payload = $this->build_upsert_payload(
			$product,
			array(
				'currency'           => $currency,
				'for_price_override' => true,
			)
		);

		$result = $this->api->upsert_product( $payload );
		if ( is_wp_error( $result ) ) {
			update_post_meta( $product->get_id(), '_fastspring_sync_error', $result->get_error_message() );
			return $result;
		}

		update_post_meta( $product->get_id(), '_vms_efwp_product_path', $slug );
		delete_post_meta( $product->get_id(), '_fastspring_sync_error' );
		VMS_EFWP_Logger::info(
			'Auto-provisioned FastSpring product at checkout: ' . $slug,
			'sync',
			array(
				'product_id' => $product->get_id(),
				'currency'   => $currency,
			)
		);

		return $slug;
	}

	/**
	 * Upsert a WooCommerce product to FastSpring.
	 *
	 * @param WC_Product $product Product.
	 * @param array      $args    Optional currency and pricing flags.
	 * @return string|WP_Error Product path on success.
	 */
	public function push_wc_product_to_fastspring( WC_Product $product, $args = array() ) {
		$payload = $this->build_upsert_payload( $product, $args );
		$slug    = $payload['product'];
		$result  = $this->api->upsert_product( $payload );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return $slug;
	}

	/**
	 * Build a FastSpring upsert payload from a WooCommerce product.
	 *
	 * @param WC_Product $product Product.
	 * @param array      $args    Optional currency and pricing flags.
	 * @return array
	 */
	public function build_upsert_payload( WC_Product $product, $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'currency'           => strtoupper( get_woocommerce_currency() ),
				'for_price_override' => false,
			)
		);

		$currency = strtoupper( (string) $args['currency'] );
		$slug     = $this->build_path( $product );
		$price    = (float) $product->get_price();
		if ( $price <= 0 ) {
			$price = 0.01;
		}

		$pricing = array(
			'price' => array(
				$currency => $price,
			),
		);

		if ( $args['for_price_override'] ) {
			$pricing['quantityBehavior'] = 'lock';
			$pricing['quantityDefault']  = 1;
		}

		$payload = array(
			'product'     => $slug,
			'display'     => array( 'en' => $product->get_name() ),
			'description' => array(
				'summary' => array( 'en' => wp_strip_all_tags( $product->get_short_description() ) ),
				'full'    => array( 'en' => wp_strip_all_tags( $product->get_description() ) ),
			),
			'pricing'     => $pricing,
			'sku'         => $product->get_sku() ? $product->get_sku() : 'wc-' . $product->get_id(),
			'format'      => 'digital',
		);

		return $payload;
	}

	/**
	 * Build the FastSpring product path slug.
	 *
	 * @param WC_Product $product Product.
	 * @return string
	 */
	public function build_path( WC_Product $product ) {
		$slug = sanitize_title( $product->get_slug() );
		if ( '' === $slug ) {
			$slug = 'wc-' . $product->get_id();
		}
		return $slug;
	}

	/**
	 * Sync all published WooCommerce products to FastSpring.
	 *
	 * @return array{synced:int,failed:int,skipped:int,errors:string[]}
	 */
	public function sync_all_products() {
		$summary = array(
			'synced'  => 0,
			'failed'  => 0,
			'skipped' => 0,
			'errors'  => array(),
		);

		if ( ! function_exists( 'wc_get_products' ) ) {
			$summary['errors'][] = __( 'WooCommerce is not available.', 'vms-elements-fastspring-woo-payment-pro' );
			return $summary;
		}

		if ( ! $this->settings->has_credentials() ) {
			$summary['errors'][] = __( 'FastSpring API credentials are not configured.', 'vms-elements-fastspring-woo-payment-pro' );
			return $summary;
		}

		$page = 1;
		do {
			$products = wc_get_products(
				array(
					'status' => 'publish',
					'limit'  => 50,
					'page'   => $page,
					'return' => 'objects',
				)
			);

			if ( empty( $products ) ) {
				break;
			}

			foreach ( $products as $product ) {
				if ( ! $product instanceof WC_Product ) {
					++$summary['skipped'];
					continue;
				}

				$slug   = $this->build_path( $product );
				$result = $this->push_wc_product_to_fastspring( $product );
				if ( is_wp_error( $result ) ) {
					++$summary['failed'];
					$summary['errors'][] = $slug . ': ' . $result->get_error_message();
					VMS_EFWP_Logger::error( 'Bulk product sync failed: ' . $result->get_error_message(), 'sync', array( 'product_id' => $product->get_id() ) );
					continue;
				}

				update_post_meta( $product->get_id(), '_vms_efwp_product_path', $slug );
				delete_post_meta( $product->get_id(), '_fastspring_sync_error' );
				++$summary['synced'];
			}

			++$page;
		} while ( count( $products ) === 50 );

		return $summary;
	}
}
