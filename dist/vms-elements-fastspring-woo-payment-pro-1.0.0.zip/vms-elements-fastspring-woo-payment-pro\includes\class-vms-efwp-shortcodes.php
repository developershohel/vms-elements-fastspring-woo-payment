<?php
/**
 * Frontend shortcodes for FastSpring overlay checkout buttons.
 *
 * @package VMS_EFWP
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class VMS_EFWP_Shortcodes.
 */
class VMS_EFWP_Shortcodes {

	const SBL_SCRIPT_URL = 'https://sbl.onfastspring.com/sbl/1.0.7/fastspring-builder.min.js';

	/**
	 * Whether a shortcode was rendered on the current request.
	 *
	 * @var bool
	 */
	private static $shortcode_used = false;

	/**
	 * Whether frontend shortcode assets were enqueued.
	 *
	 * @var bool
	 */
	private static $assets_enqueued = false;

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_shortcode( 'fastspring_product', array( __CLASS__, 'render_product_shortcode' ) );
		add_shortcode( 'fastspring_products', array( __CLASS__, 'render_product_shortcode' ) );
		add_shortcode( 'fastspring_subscription', array( __CLASS__, 'render_subscription_shortcode' ) );
		add_shortcode( 'fastspring_subscriptions', array( __CLASS__, 'render_subscription_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ), 5 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'maybe_enqueue_assets_early' ), 20 );
		add_filter( 'script_loader_tag', array( __CLASS__, 'filter_sbl_script_tag' ), 11, 3 );
	}

	/**
	 * Shortcode tags handled by this class.
	 *
	 * @return string[]
	 */
	public static function get_shortcode_tags() {
		return array(
			'fastspring_product',
			'fastspring_products',
			'fastspring_subscription',
			'fastspring_subscriptions',
		);
	}

	/**
	 * Whether post content includes one of our shortcodes.
	 *
	 * @param string $content Optional content. Defaults to current post content.
	 * @return bool
	 */
	public static function post_has_shortcode( $content = null ) {
		if ( null === $content ) {
			global $post;
			if ( ! $post instanceof WP_Post ) {
				return false;
			}
			$content = (string) $post->post_content;
		}

		foreach ( self::get_shortcode_tags() as $tag ) {
			if ( has_shortcode( $content, $tag ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Product overlay checkout button.
	 *
	 * @param array|string $atts Shortcode attributes.
	 * @return string
	 */
	public static function render_product_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'id'            => '',
				'redirect'      => '',
				'text'          => __( 'Buy now', 'vms-elements-fastspring-woo-payment-pro' ),
				'style'         => 'primary',
				'class'         => '',
				'align'         => 'left',
				'quantity'      => '1',
				'details'       => '',
				'bg'            => '',
				'color'         => '',
				'font_size'     => '',
				'padding'       => '',
				'margin'        => '',
				'border_radius' => '',
				'border_color'  => '',
				'border_width'  => '',
			),
			$atts,
			'fastspring_product'
		);

		return self::render_button( $atts, 'product' );
	}

	/**
	 * Subscription overlay checkout button.
	 *
	 * @param array|string $atts Shortcode attributes.
	 * @return string
	 */
	public static function render_subscription_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'id'            => '',
				'redirect'      => '',
				'text'          => __( 'Subscribe now', 'vms-elements-fastspring-woo-payment-pro' ),
				'style'         => 'primary',
				'class'         => '',
				'align'         => 'left',
				'quantity'      => '1',
				'details'       => '',
				'bg'            => '',
				'color'         => '',
				'font_size'     => '',
				'padding'       => '',
				'margin'        => '',
				'border_radius' => '',
				'border_color'  => '',
				'border_width'  => '',
			),
			$atts,
			'fastspring_subscription'
		);

		return self::render_button( $atts, 'subscription' );
	}

	/**
	 * Render a checkout button for a catalog product path.
	 *
	 * @param array  $atts Shortcode attributes.
	 * @param string $type product|subscription.
	 * @return string
	 */
	private static function render_button( $atts, $type ) {
		$product_path = sanitize_text_field( (string) $atts['id'] );
		if ( '' === $product_path ) {
			return current_user_can( 'manage_options' )
				? '<p class="vms-efwp-shortcode-error">' . esc_html__( 'FastSpring shortcode: missing id attribute (product path).', 'vms-elements-fastspring-woo-payment-pro' ) . '</p>'
				: '';
		}

		if ( ! function_exists( 'vms_efwp' ) || ! vms_efwp()->settings || ! vms_efwp()->settings->has_popup_checkout() ) {
			return current_user_can( 'manage_options' )
				? '<p class="vms-efwp-shortcode-error">' . esc_html__( 'FastSpring shortcode: configure the popup checkout path in FastSpring → Settings.', 'vms-elements-fastspring-woo-payment-pro' ) . '</p>'
				: '';
		}

		self::$shortcode_used = true;
		self::ensure_frontend_assets();

		$style    = self::sanitize_style( $atts['style'] );
		$align    = self::sanitize_align( $atts['align'] );
		$quantity = max( 1, absint( $atts['quantity'] ) );
		$redirect     = self::sanitize_redirect( $atts['redirect'] );
		$show_details = VMS_EFWP_Payment_Success::parse_details_flag( $atts['details'] );
		if ( null === $show_details ) {
			$show_details = VMS_EFWP_Payment_Success::default_show_details();
		}
		$resolved_redirect = VMS_EFWP_Payment_Success::resolve_post_payment_redirect( $redirect, $show_details );
		$text              = sanitize_text_field( (string) $atts['text'] );
		$classes           = self::sanitize_class_list( $atts['class'] );
		$button_style      = self::build_inline_style_attr( $atts );
		$wrapper_style     = self::build_wrapper_style_attr( $atts );

		$button_classes = array(
			'vms-efwp-shortcode-btn',
			'vms-efwp-shortcode-btn--' . $style,
			'vms-efwp-shortcode-trigger',
		);
		if ( $classes ) {
			$button_classes[] = $classes;
		}

		$wrapper_classes = array(
			'vms-efwp-shortcode',
			'vms-efwp-shortcode--' . sanitize_key( $type ),
			'vms-efwp-shortcode--align-' . $align,
		);

		ob_start();
		?>
		<div class="<?php echo esc_attr( implode( ' ', $wrapper_classes ) ); ?>"<?php echo $wrapper_style; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in helper. ?>>
			<button
				type="button"
				class="<?php echo esc_attr( implode( ' ', $button_classes ) ); ?>"
				data-product-path="<?php echo esc_attr( $product_path ); ?>"
				data-quantity="<?php echo esc_attr( (string) $quantity ); ?>"
				data-redirect="<?php echo esc_attr( $resolved_redirect ); ?>"
				data-show-details="<?php echo $show_details ? '1' : '0'; ?>"
				<?php if ( $redirect ) : ?>
				data-custom-redirect="1"
				<?php endif; ?>
				<?php echo $button_style; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in helper. ?>
			><?php echo esc_html( $text ); ?></button>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Register frontend assets.
	 */
	public static function register_assets() {
		if ( is_admin() ) {
			return;
		}

		wp_register_style(
			'vms-efwp-shortcode-checkout',
			vms_efwp_pro_asset_url( 'assets/css/shortcode-checkout.css' ),
			array(),
			VMS_EFWP_VERSION
		);

		wp_register_style(
			'vms-efwp-checkout-popup',
			vms_efwp_pro_asset_url( 'assets/css/checkout-popup.css' ),
			array(),
			VMS_EFWP_VERSION
		);

		wp_register_script(
			'fastspring-builder-shortcode',
			self::SBL_SCRIPT_URL,
			array(),
			'1.0.7',
			true
		);

		wp_register_script(
			'vms-efwp-overlay-shell',
			vms_efwp_pro_asset_url( 'assets/js/overlay-shell.js' ),
			array(),
			VMS_EFWP_VERSION,
			true
		);

		wp_register_script(
			'vms-efwp-shortcode-checkout',
			vms_efwp_pro_asset_url( 'assets/js/shortcode-checkout.js' ),
			array( 'fastspring-builder-shortcode', 'vms-efwp-overlay-shell' ),
			VMS_EFWP_VERSION,
			true
		);
	}

	/**
	 * Enqueue assets during wp_enqueue_scripts when the post content contains a shortcode.
	 */
	public static function maybe_enqueue_assets_early() {
		if ( is_admin() ) {
			return;
		}

		if ( self::post_has_shortcode() ) {
			self::$shortcode_used = true;
		}

		if ( ! self::$shortcode_used ) {
			return;
		}

		self::ensure_frontend_assets();
	}

	/**
	 * Enqueue frontend shortcode assets once per request.
	 */
	public static function ensure_frontend_assets() {
		if ( self::$assets_enqueued || is_admin() ) {
			return;
		}
		if ( ! function_exists( 'vms_efwp' ) || ! vms_efwp()->settings || ! vms_efwp()->settings->has_popup_checkout() ) {
			return;
		}

		self::$assets_enqueued = true;

		wp_enqueue_style( 'vms-efwp-shortcode-checkout' );
		wp_enqueue_style( 'vms-efwp-checkout-popup' );

		if ( ! wp_script_is( 'fastspring-builder', 'enqueued' ) ) {
			wp_enqueue_script( 'fastspring-builder-shortcode' );
		}

		wp_enqueue_script( 'vms-efwp-overlay-shell' );
		wp_localize_script(
			'vms-efwp-overlay-shell',
			'VMS_EFWP_OverlayShell',
			array(
				'i18n' => array(
					'checkoutAriaLabel' => __( 'FastSpring checkout', 'vms-elements-fastspring-woo-payment-pro' ),
				),
			)
		);
		wp_enqueue_script( 'vms-efwp-shortcode-checkout' );
		wp_localize_script(
			'vms-efwp-shortcode-checkout',
			'VMS_EFWP_Shortcode',
			array(
				'popupStorefront' => vms_efwp()->settings->popup_storefront(),
				'accessKey'       => vms_efwp()->settings->access_key(),
				'defaultRedirect' => VMS_EFWP_Payment_Success::resolve_post_payment_redirect( '', null ),
				'debug'           => defined( 'WP_DEBUG' ) && WP_DEBUG,
				'i18n'            => array_merge(
					VMS_EFWP_Assets::checkout_js_i18n(),
					array(
						'error'      => __( 'FastSpring checkout could not open. Confirm your popup checkout path and whitelisted domains.', 'vms-elements-fastspring-woo-payment-pro' ),
						'loadFailed' => __( 'FastSpring Store Builder did not load.', 'vms-elements-fastspring-woo-payment-pro' ),
					)
				),
			)
		);
		if ( function_exists( 'wp_set_script_translations' ) ) {
			wp_set_script_translations( 'vms-efwp-shortcode-checkout', 'vms-elements-fastspring-woo-payment-pro' );
			wp_set_script_translations( 'vms-efwp-overlay-shell', 'vms-elements-fastspring-woo-payment-pro' );
		}
	}

	/**
	 * Add Store Builder attributes for shortcode checkout.
	 *
	 * @param string $tag    Script tag.
	 * @param string $handle Handle.
	 * @param string $src    Source URL.
	 * @return string
	 */
	public static function filter_sbl_script_tag( $tag, $handle, $src ) {
		if ( 'fastspring-builder-shortcode' !== $handle || ( ! self::$shortcode_used && ! self::$assets_enqueued ) ) {
			return $tag;
		}
		if ( ! function_exists( 'vms_efwp' ) || ! vms_efwp()->settings ) {
			return $tag;
		}

		$popup_storefront = vms_efwp()->settings->popup_storefront();
		if ( '' === $popup_storefront ) {
			return $tag;
		}

		$access_key = vms_efwp()->settings->access_key();

		return VMS_EFWP_Assets::enhance_sbl_script_tag(
			$tag,
			$handle,
			'fastspring-builder-shortcode',
			$popup_storefront,
			array(
				'popup_closed'   => 'VMS_EFWP_ShortcodePopupClosed',
				'error_callback' => 'VMS_EFWP_ShortcodeErrorCallback',
				'access_key'     => $access_key,
			)
		);
	}

	/**
	 * Build a shortcode string for the admin builder.
	 *
	 * @param string $type product|subscription.
	 * @param array  $args Builder args.
	 * @return string
	 */
	public static function build_shortcode_string( $type, $args ) {
		$tag = 'subscription' === $type ? 'fastspring_subscription' : 'fastspring_product';
		$args = wp_parse_args(
			$args,
			array(
				'id'            => '',
				'redirect'      => '',
				'text'          => '',
				'style'         => 'primary',
				'class'         => '',
				'align'         => 'left',
				'quantity'      => '1',
				'details'       => '',
				'bg'            => '',
				'color'         => '',
				'font_size'     => '',
				'padding'       => '',
				'margin'        => '',
				'border_radius' => '',
				'border_color'  => '',
				'border_width'  => '',
			)
		);

		$parts = array();
		if ( $args['id'] ) {
			$parts[] = 'id="' . esc_attr( $args['id'] ) . '"';
		}
		if ( $args['redirect'] ) {
			$parts[] = 'redirect="' . esc_url( $args['redirect'] ) . '"';
		}
		if ( '' !== $args['details'] ) {
			$parts[] = 'details="' . esc_attr( $args['details'] ) . '"';
		}
		if ( $args['text'] ) {
			$parts[] = 'text="' . esc_attr( $args['text'] ) . '"';
		}
		if ( $args['style'] && 'primary' !== $args['style'] ) {
			$parts[] = 'style="' . esc_attr( self::sanitize_style( $args['style'] ) ) . '"';
		}
		if ( $args['class'] ) {
			$parts[] = 'class="' . esc_attr( self::sanitize_class_list( $args['class'] ) ) . '"';
		}
		if ( $args['align'] && 'left' !== $args['align'] ) {
			$parts[] = 'align="' . esc_attr( self::sanitize_align( $args['align'] ) ) . '"';
		}
		if ( isset( $args['quantity'] ) && (int) $args['quantity'] > 1 ) {
			$parts[] = 'quantity="' . absint( $args['quantity'] ) . '"';
		}

		foreach ( self::get_custom_style_fields() as $field => $css_property ) {
			if ( ! empty( $args[ $field ] ) ) {
				$parts[] = $field . '="' . esc_attr( self::sanitize_css_value( $args[ $field ], $css_property ) ) . '"';
			}
		}

		return '[' . $tag . ( $parts ? ' ' . implode( ' ', $parts ) : '' ) . ']';
	}

	/**
	 * Custom inline style shortcode attributes.
	 *
	 * @return array<string,string>
	 */
	public static function get_custom_style_fields() {
		return array(
			'bg'            => 'background-color',
			'color'         => 'color',
			'font_size'     => 'font-size',
			'padding'       => 'padding',
			'margin'        => 'margin',
			'border_radius' => 'border-radius',
			'border_color'  => 'border-color',
			'border_width'  => 'border-width',
		);
	}

	/**
	 * Build inline style attribute for the button.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public static function build_inline_style_attr( $atts ) {
		$styles = self::build_inline_styles( $atts, false );
		return $styles ? ' style="' . esc_attr( $styles ) . '"' : '';
	}

	/**
	 * Build inline style attribute for the wrapper.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public static function build_wrapper_style_attr( $atts ) {
		$margin = self::sanitize_css_value( $atts['margin'] ?? '', 'margin' );
		return $margin ? ' style="' . esc_attr( 'margin:' . $margin ) . '"' : '';
	}

	/**
	 * Build CSS declarations from shortcode attrs.
	 *
	 * @param array $atts       Shortcode attributes.
	 * @param bool  $with_margin Include margin on button.
	 * @return string
	 */
	public static function build_inline_styles( $atts, $with_margin = false ) {
		$declarations = array();

		foreach ( self::get_custom_style_fields() as $field => $property ) {
			if ( ! $with_margin && 'margin' === $field ) {
				continue;
			}
			if ( empty( $atts[ $field ] ) ) {
				continue;
			}
			$value = self::sanitize_css_value( $atts[ $field ], $property );
			if ( $value ) {
				$declarations[] = $property . ':' . $value;
			}
		}

		if ( ! empty( $atts['border_width'] ) || ! empty( $atts['border_color'] ) ) {
			$width = self::sanitize_css_value( $atts['border_width'] ?? '1px', 'border-width' );
			$color = self::sanitize_css_value( $atts['border_color'] ?? '#2271b1', 'border-color' );
			if ( $width && $color ) {
				$declarations[] = 'border-style:solid';
				$declarations[] = 'border-width:' . $width;
				$declarations[] = 'border-color:' . $color;
			}
		}

		return implode( ';', $declarations );
	}

	/**
	 * Sanitize a CSS value for inline styles.
	 *
	 * @param string $value    Raw value.
	 * @param string $property CSS property name.
	 * @return string
	 */
	public static function sanitize_css_value( $value, $property ) {
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return '';
		}

		if ( in_array( $property, array( 'background-color', 'color', 'border-color' ), true ) ) {
			$hex = sanitize_hex_color( $value );
			if ( $hex ) {
				return $hex;
			}
			if ( preg_match( '/^(rgb|rgba|hsl|hsla)\([^;{}]+\)$/i', $value ) ) {
				return $value;
			}
			return '';
		}

		if ( preg_match( '/^[0-9.\s%emrempxvhvw\-+(),\/]+$/i', $value ) ) {
			return $value;
		}

		return '';
	}

	/**
	 * Allowed style presets.
	 *
	 * @return string[]
	 */
	public static function get_style_presets() {
		return array( 'primary', 'secondary', 'outline', 'link' );
	}

	/**
	 * Allowed align values.
	 *
	 * @return string[]
	 */
	public static function get_alignments() {
		return array( 'left', 'center', 'right' );
	}

	/**
	 * @param string $style Style slug.
	 * @return string
	 */
	private static function sanitize_style( $style ) {
		$style = sanitize_key( (string) $style );
		return in_array( $style, self::get_style_presets(), true ) ? $style : 'primary';
	}

	/**
	 * @param string $align Alignment slug.
	 * @return string
	 */
	private static function sanitize_align( $align ) {
		$align = sanitize_key( (string) $align );
		return in_array( $align, self::get_alignments(), true ) ? $align : 'left';
	}

	/**
	 * @param string $redirect Redirect URL or path.
	 * @return string
	 */
	private static function sanitize_redirect( $redirect ) {
		$redirect = trim( (string) $redirect );
		if ( '' === $redirect ) {
			return '';
		}

		if ( 0 === strpos( $redirect, '/' ) ) {
			return esc_url_raw( home_url( $redirect ) );
		}

		return esc_url_raw( $redirect );
	}

	/**
	 * @param string $classes Space-separated class list.
	 * @return string
	 */
	private static function sanitize_class_list( $classes ) {
		$parts = preg_split( '/\s+/', (string) $classes, -1, PREG_SPLIT_NO_EMPTY );
		if ( ! is_array( $parts ) ) {
			return '';
		}

		$clean = array();
		foreach ( $parts as $part ) {
			$sanitized = sanitize_html_class( $part );
			if ( $sanitized ) {
				$clean[] = $sanitized;
			}
		}

		return implode( ' ', $clean );
	}
}
