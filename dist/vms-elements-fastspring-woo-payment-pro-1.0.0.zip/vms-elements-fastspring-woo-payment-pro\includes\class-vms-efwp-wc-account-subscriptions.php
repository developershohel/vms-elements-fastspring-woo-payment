<?php
/**
 * FastSpring subscriptions on the WooCommerce My Account page.
 *
 * @package VMS_EFWP
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class VMS_EFWP_WC_Account_Subscriptions.
 */
class VMS_EFWP_WC_Account_Subscriptions {

	const ENDPOINT = 'subscriptions';

	const REWRITE_VERSION_OPTION = 'vms_efwp_wc_account_subscriptions_rewrite_version';

	const REWRITE_VERSION = '2';

	const SYNC_TRANSIENT_PREFIX = 'vms_efwp_sub_sync_';

	const LIST_TRANSIENT_PREFIX = 'vms_efwp_sub_list_v2_';

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'add_endpoint' ), 5 );
		add_action( 'init', array( __CLASS__, 'maybe_flush_rewrite_rules' ), 11 );
		add_filter( 'woocommerce_account_menu_items', array( __CLASS__, 'add_menu_item' ) );
		add_filter( 'woocommerce_get_query_vars', array( __CLASS__, 'add_query_var' ) );
		add_action( 'woocommerce_account_' . self::ENDPOINT . '_endpoint', array( __CLASS__, 'render_endpoint' ) );
		add_action( 'template_redirect', array( __CLASS__, 'handle_actions' ), 9 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_filter( 'login_redirect', array( __CLASS__, 'filter_login_redirect' ), 100, 3 );
		add_filter( 'woocommerce_login_redirect', array( __CLASS__, 'filter_woocommerce_login_redirect' ), 100, 2 );
	}

	/**
	 * Register the My Account rewrite endpoint.
	 */
	public static function add_endpoint() {
		global $wp_rewrite;

		if ( ! $wp_rewrite instanceof WP_Rewrite ) {
			return;
		}

		add_rewrite_endpoint( self::ENDPOINT, EP_ROOT | EP_PAGES );
	}

	/**
	 * Ensure WooCommerce recognizes the endpoint query var.
	 *
	 * @param array $vars Query vars.
	 * @return array
	 */
	public static function add_query_var( $vars ) {
		$vars[ self::ENDPOINT ] = self::ENDPOINT;
		return $vars;
	}

	/**
	 * Flush rewrite rules after endpoint registration changes.
	 */
	public static function maybe_flush_rewrite_rules() {
		global $wp_rewrite;

		if ( ! $wp_rewrite instanceof WP_Rewrite ) {
			return;
		}

		$stored = (string) get_option( self::REWRITE_VERSION_OPTION, '' );
		if ( $stored === self::REWRITE_VERSION ) {
			return;
		}

		self::add_endpoint();
		flush_rewrite_rules( false );
		update_option( self::REWRITE_VERSION_OPTION, self::REWRITE_VERSION, false );
	}

	/**
	 * Queue a rewrite flush on the next init (activation-safe).
	 */
	public static function schedule_rewrite_flush() {
		delete_option( self::REWRITE_VERSION_OPTION );
	}

	/**
	 * Flush rewrite rules immediately (manual repair).
	 */
	public static function flush_rewrite_rules_now() {
		global $wp_rewrite;

		if ( ! $wp_rewrite instanceof WP_Rewrite ) {
			self::schedule_rewrite_flush();
			return;
		}

		self::add_endpoint();
		flush_rewrite_rules( false );
		update_option( self::REWRITE_VERSION_OPTION, self::REWRITE_VERSION, false );
	}

	/**
	 * Insert the Subscriptions item after Orders.
	 *
	 * @param array $items Menu items.
	 * @return array
	 */
	public static function add_menu_item( $items ) {
		$new_items = array();

		foreach ( $items as $key => $label ) {
			$new_items[ $key ] = $label;
			if ( 'orders' === $key ) {
				$new_items[ self::ENDPOINT ] = __( 'Subscriptions', 'vms-elements-fastspring-woo-payment-pro' );
			}
		}

		if ( ! isset( $new_items[ self::ENDPOINT ] ) ) {
			$new_items[ self::ENDPOINT ] = __( 'Subscriptions', 'vms-elements-fastspring-woo-payment-pro' );
		}

		return $new_items;
	}

	/**
	 * Send dashboard-capable users to wp-admin instead of My Account after login.
	 *
	 * @param string           $redirect_to           Login redirect URL.
	 * @param string           $requested_redirect_to Original requested redirect.
	 * @param WP_User|WP_Error $user                  Logged-in user.
	 * @return string
	 */
	public static function filter_login_redirect( $redirect_to, $requested_redirect_to, $user ) {
		if ( is_wp_error( $user ) || ! ( $user instanceof WP_User ) || ! $user->exists() ) {
			return $redirect_to;
		}

		if ( ! self::user_can_access_dashboard( $user ) ) {
			return $redirect_to;
		}

		if ( $requested_redirect_to && ! self::is_my_account_url( $requested_redirect_to ) ) {
			$validated = wp_validate_redirect( $requested_redirect_to, admin_url() );
			if ( $validated && ! self::is_my_account_url( $validated ) ) {
				return $validated;
			}
		}

		if ( empty( $redirect_to ) || self::is_my_account_url( $redirect_to ) ) {
			return admin_url();
		}

		return $redirect_to;
	}

	/**
	 * Avoid sending dashboard-capable users back to My Account after WooCommerce login.
	 *
	 * @param string  $redirect Redirect URL.
	 * @param WP_User $user     Logged-in user.
	 * @return string
	 */
	public static function filter_woocommerce_login_redirect( $redirect, $user ) {
		if ( ! ( $user instanceof WP_User ) || ! $user->exists() ) {
			return $redirect;
		}

		if ( ! self::user_can_access_dashboard( $user ) ) {
			return $redirect;
		}

		if ( empty( $redirect ) || self::is_my_account_url( $redirect ) ) {
			return admin_url();
		}

		return $redirect;
	}

	/**
	 * Whether a user should be allowed into wp-admin.
	 *
	 * @param WP_User $user User object.
	 * @return bool
	 */
	private static function user_can_access_dashboard( $user ) {
		foreach ( array( 'manage_options', 'edit_posts', 'manage_woocommerce', 'view_admin_dashboard' ) as $cap ) {
			if ( user_can( $user, $cap ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check whether a URL points to the WooCommerce My Account page.
	 *
	 * @param string $url URL to test.
	 * @return bool
	 */
	private static function is_my_account_url( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url || ! function_exists( 'wc_get_page_permalink' ) ) {
			return false;
		}

		$my_account = wc_get_page_permalink( 'myaccount' );
		if ( ! $my_account ) {
			return false;
		}

		$url_path = wp_parse_url( $url, PHP_URL_PATH );
		$account_path = wp_parse_url( $my_account, PHP_URL_PATH );

		if ( ! $url_path || ! $account_path ) {
			return false;
		}

		$url_path     = untrailingslashit( $url_path );
		$account_path = untrailingslashit( $account_path );

		return $url_path === $account_path || 0 === strpos( $url_path, $account_path . '/' );
	}

	/**
	 * Enqueue frontend styles on the account subscriptions screen.
	 */
	public static function enqueue_assets() {
		if ( ! is_account_page() || ! self::is_subscriptions_endpoint() ) {
			return;
		}

		wp_enqueue_style(
			'vms-efwp-account-subscriptions',
			vms_efwp_pro_asset_url( 'assets/css/account-subscriptions.css' ),
			array(),
			VMS_EFWP_VERSION
		);
	}

	/**
	 * Handle subscription actions submitted from the account page.
	 */
	public static function handle_actions() {
		if ( ! is_user_logged_in() || ! is_account_page() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified below.
		if ( empty( $_POST['vms_efwp_sub_action'] ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified below.
		if ( ! isset( $_POST['vms_efwp_sub_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vms_efwp_sub_nonce'] ) ), 'vms_efwp_account_sub_action' ) ) {
			wc_add_notice( __( 'Security check failed. Please try again.', 'vms-elements-fastspring-woo-payment-pro' ), 'error' );
			wp_safe_redirect( self::get_endpoint_url() );
			exit;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		$action = sanitize_key( wp_unslash( $_POST['vms_efwp_sub_action'] ) );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		$subscription_id = isset( $_POST['subscription_id'] ) ? sanitize_text_field( wp_unslash( $_POST['subscription_id'] ) ) : '';

		if ( ! $subscription_id ) {
			wc_add_notice( __( 'Missing subscription ID.', 'vms-elements-fastspring-woo-payment-pro' ), 'error' );
			wp_safe_redirect( self::get_endpoint_url() );
			exit;
		}

		if ( ! self::user_owns_subscription( $subscription_id ) ) {
			wc_add_notice( __( 'You do not have permission to manage this subscription.', 'vms-elements-fastspring-woo-payment-pro' ), 'error' );
			wp_safe_redirect( self::get_endpoint_url() );
			exit;
		}

		if ( ! vms_efwp()->settings->has_credentials() ) {
			wc_add_notice( __( 'Subscription management is temporarily unavailable.', 'vms-elements-fastspring-woo-payment-pro' ), 'error' );
			wp_safe_redirect( self::get_endpoint_url() );
			exit;
		}

		$api    = vms_efwp()->api;
		$result = null;
		$notice = '';
		$type   = 'success';

		switch ( $action ) {
			case 'cancel':
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
				$immediate_raw = isset( $_POST['immediate'] ) ? sanitize_text_field( wp_unslash( $_POST['immediate'] ) ) : '';
				$immediate     = '1' === $immediate_raw;
				$result    = $api->cancel_subscription( $subscription_id, $immediate );
				if ( ! is_wp_error( $result ) ) {
					VMS_EFWP_Data_Store::set_subscription_status( $subscription_id, 'canceled' );
					$notice = $immediate
						? __( 'Your subscription has been canceled.', 'vms-elements-fastspring-woo-payment-pro' )
						: __( 'Your subscription cancellation has been scheduled.', 'vms-elements-fastspring-woo-payment-pro' );
				}
				break;

			case 'uncancel':
				$stored       = VMS_EFWP_Data_Store::get_subscription_by_fs_id( $subscription_id );
				$subscription = $stored ? vms_efwp()->api->subscription_payload_from_row( $stored ) : array();
				$fresh        = $api->get_subscription( $subscription_id );
				if ( ! is_wp_error( $fresh ) ) {
					$parsed = $api->parse_subscription( $fresh );
					if ( ! is_wp_error( $parsed ) ) {
						$subscription = $parsed;
					}
				}

				if ( ! $api->subscription_can_uncancel( $subscription ) ) {
					wc_add_notice( __( 'This subscription has already ended and cannot be resumed.', 'vms-elements-fastspring-woo-payment-pro' ), 'error' );
					wp_safe_redirect( self::get_endpoint_url() );
					exit;
				}

				$result = $api->uncancel_subscription( $subscription_id );
				if ( ! is_wp_error( $result ) ) {
					$updated = $api->parse_subscription( $result );
					if ( ! is_wp_error( $updated ) ) {
						VMS_EFWP_Data_Store::upsert_subscription( $updated, vms_efwp()->settings->is_sandbox() );
					} else {
						VMS_EFWP_Data_Store::set_subscription_status( $subscription_id, 'active' );
					}
					$notice = __( 'Your subscription cancellation has been reversed.', 'vms-elements-fastspring-woo-payment-pro' );
				}
				break;

			case 'resume':
				$result = $api->resume_subscription( $subscription_id );
				if ( ! is_wp_error( $result ) ) {
					$subscription = $api->parse_subscription( $result );
					if ( ! is_wp_error( $subscription ) ) {
						VMS_EFWP_Data_Store::upsert_subscription( $subscription, vms_efwp()->settings->is_sandbox() );
					} else {
						VMS_EFWP_Data_Store::set_subscription_status( $subscription_id, 'active' );
					}
					$notice = __( 'Your subscription has been resumed.', 'vms-elements-fastspring-woo-payment-pro' );
				}
				break;

			case 'pause':
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
				$periods = isset( $_POST['pause_period_count'] ) ? max( 1, min( 12, (int) $_POST['pause_period_count'] ) ) : 1;
				$result  = $api->pause_subscription( $subscription_id, array( 'pausePeriodCount' => $periods ) );
				if ( ! is_wp_error( $result ) ) {
					$subscription = $api->parse_subscription( $result );
					if ( ! is_wp_error( $subscription ) ) {
						VMS_EFWP_Data_Store::upsert_subscription( $subscription, vms_efwp()->settings->is_sandbox() );
					} else {
						VMS_EFWP_Data_Store::set_subscription_status( $subscription_id, 'paused' );
					}
					$notice = 1 === $periods
						? __( 'Your subscription has been paused for one billing period.', 'vms-elements-fastspring-woo-payment-pro' )
						: sprintf(
							/* translators: %d: number of billing periods */
							__( 'Your subscription has been paused for %d billing periods.', 'vms-elements-fastspring-woo-payment-pro' ),
							$periods
						);
				}
				break;

			default:
				wc_add_notice( __( 'Unknown subscription action.', 'vms-elements-fastspring-woo-payment-pro' ), 'error' );
				wp_safe_redirect( self::get_endpoint_url() );
				exit;
		}

		if ( is_wp_error( $result ) ) {
			$message = $result->get_error_message();
			if ( 'uncancel' === $action && false !== stripos( $message, 'not active' ) ) {
				$message = __( 'This subscription has already ended and cannot be resumed.', 'vms-elements-fastspring-woo-payment-pro' );
			}
			wc_add_notice( $message, 'error' );
		} elseif ( $notice ) {
			wc_add_notice( $notice, $type );
		}

		self::clear_subscription_cache( get_current_user_id() );

		wp_safe_redirect( self::get_endpoint_url() );
		exit;
	}

	/**
	 * Clear cached subscription lists for a user.
	 *
	 * @param int $user_id User ID.
	 */
	private static function clear_subscription_cache( $user_id ) {
		if ( ! $user_id ) {
			return;
		}

		delete_transient( self::LIST_TRANSIENT_PREFIX . $user_id );
		delete_transient( self::SYNC_TRANSIENT_PREFIX . $user_id );
	}

	/**
	 * Render the subscriptions endpoint content.
	 */
	public static function render_endpoint() {
		if ( ! is_user_logged_in() ) {
			return;
		}

		$user_id = get_current_user_id();
		if ( ! $user_id ) {
			return;
		}

		$page     = absint( get_query_var( self::ENDPOINT ) );
		if ( ! $page ) {
			$page = 1;
		}
		$per_page = 20;
		$result   = self::get_customer_subscriptions( $user_id, $page, $per_page );

		$total_pages = max( 1, (int) ceil( $result['total'] / $per_page ) );
		?>
		<h2><?php esc_html_e( 'Subscriptions', 'vms-elements-fastspring-woo-payment-pro' ); ?></h2>
		<p class="vms-efwp-account-subscriptions__intro">
			<?php esc_html_e( 'Manage your FastSpring subscriptions linked to your account.', 'vms-elements-fastspring-woo-payment-pro' ); ?>
		</p>

		<?php if ( empty( $result['rows'] ) ) : ?>
			<div class="woocommerce-message woocommerce-message--info woocommerce-Message woocommerce-Message--info woocommerce-info">
				<?php esc_html_e( 'You do not have any subscriptions yet.', 'vms-elements-fastspring-woo-payment-pro' ); ?>
			</div>
		<?php else : ?>
			<table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table shop_table_responsive my_account_orders account-orders-table vms-efwp-account-subscriptions__table">
				<thead>
					<tr>
						<th class="woocommerce-orders-table__header"><span class="nobr"><?php esc_html_e( 'Product', 'vms-elements-fastspring-woo-payment-pro' ); ?></span></th>
						<th class="woocommerce-orders-table__header"><span class="nobr"><?php esc_html_e( 'Price', 'vms-elements-fastspring-woo-payment-pro' ); ?></span></th>
						<th class="woocommerce-orders-table__header"><span class="nobr"><?php esc_html_e( 'Billing', 'vms-elements-fastspring-woo-payment-pro' ); ?></span></th>
						<th class="woocommerce-orders-table__header"><span class="nobr"><?php esc_html_e( 'Next charge', 'vms-elements-fastspring-woo-payment-pro' ); ?></span></th>
						<th class="woocommerce-orders-table__header"><span class="nobr"><?php esc_html_e( 'Status', 'vms-elements-fastspring-woo-payment-pro' ); ?></span></th>
						<th class="woocommerce-orders-table__header"><span class="nobr"><?php esc_html_e( 'Actions', 'vms-elements-fastspring-woo-payment-pro' ); ?></span></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $result['rows'] as $row ) : ?>
						<tr class="woocommerce-orders-table__row">
							<td class="woocommerce-orders-table__cell" data-title="<?php esc_attr_e( 'Product', 'vms-elements-fastspring-woo-payment-pro' ); ?>">
								<strong><?php echo esc_html( $row['product'] ? $row['product'] : $row['fs_subscription_id'] ); ?></strong>
								<?php if ( (int) $row['is_test'] ) : ?>
									<span class="vms-efwp-account-subscriptions__badge"><?php esc_html_e( 'Test', 'vms-elements-fastspring-woo-payment-pro' ); ?></span>
								<?php endif; ?>
							</td>
							<td class="woocommerce-orders-table__cell" data-title="<?php esc_attr_e( 'Price', 'vms-elements-fastspring-woo-payment-pro' ); ?>">
								<?php
								echo esc_html(
									trim( ( $row['currency'] ? $row['currency'] . ' ' : '' ) . number_format_i18n( (float) $row['price'], 2 ) )
								);
								?>
							</td>
							<td class="woocommerce-orders-table__cell" data-title="<?php esc_attr_e( 'Billing', 'vms-elements-fastspring-woo-payment-pro' ); ?>">
								<?php
								echo esc_html(
									sprintf(
										/* translators: 1: interval length 2: interval unit */
										__( 'Every %1$d %2$s', 'vms-elements-fastspring-woo-payment-pro' ),
										max( 1, (int) $row['interval_length'] ),
										$row['interval_unit'] ? $row['interval_unit'] : '-'
									)
								);
								?>
							</td>
							<td class="woocommerce-orders-table__cell" data-title="<?php esc_attr_e( 'Next charge', 'vms-elements-fastspring-woo-payment-pro' ); ?>">
								<?php echo esc_html( $row['next_charge'] ? mysql2date( get_option( 'date_format' ), $row['next_charge'] ) : '—' ); ?>
							</td>
							<td class="woocommerce-orders-table__cell" data-title="<?php esc_attr_e( 'Status', 'vms-elements-fastspring-woo-payment-pro' ); ?>">
								<span class="vms-efwp-status vms-efwp-status--<?php echo esc_attr( sanitize_key( $row['status'] ) ); ?>">
									<?php echo esc_html( ucfirst( (string) $row['status'] ) ); ?>
								</span>
							</td>
							<td class="woocommerce-orders-table__cell vms-efwp-account-subscriptions__actions" data-title="<?php esc_attr_e( 'Actions', 'vms-elements-fastspring-woo-payment-pro' ); ?>">
								<?php self::render_row_actions( $row ); ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<?php if ( $total_pages > 1 ) : ?>
				<div class="woocommerce-pagination woocommerce-pagination--without-numbers woocommerce-Pagination">
					<?php if ( $page > 1 ) : ?>
						<a class="woocommerce-button woocommerce-button--previous button" href="<?php echo esc_url( self::get_endpoint_url( $page - 1 ) ); ?>">
							<?php esc_html_e( 'Previous', 'vms-elements-fastspring-woo-payment-pro' ); ?>
						</a>
					<?php endif; ?>
					<?php if ( $page < $total_pages ) : ?>
						<a class="woocommerce-button woocommerce-button--next button" href="<?php echo esc_url( self::get_endpoint_url( $page + 1 ) ); ?>">
							<?php esc_html_e( 'Next', 'vms-elements-fastspring-woo-payment-pro' ); ?>
						</a>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		<?php endif; ?>
		<?php
	}

	/**
	 * Render action forms for a subscription row.
	 *
	 * @param array $row Subscription row.
	 */
	private static function render_row_actions( $row ) {
		$api             = vms_efwp()->api;
		$subscription_id = $row['fs_subscription_id'] ?? '';
		$status          = sanitize_key( (string) ( $row['status'] ?? '' ) );
		$payload         = $api->subscription_payload_from_row( $row );
		$can_uncancel    = $api->subscription_can_uncancel( $payload );

		if ( $can_uncancel ) {
			self::render_action_form(
				$subscription_id,
				'uncancel',
				__( 'Keep subscription', 'vms-elements-fastspring-woo-payment-pro' ),
				__( 'Reverse the scheduled cancellation and keep this subscription active?', 'vms-elements-fastspring-woo-payment-pro' )
			);
		} elseif ( in_array( $status, array( 'active', 'trial', 'overdue' ), true ) ) {
			self::render_pause_form( $subscription_id );
			self::render_action_form(
				$subscription_id,
				'cancel',
				__( 'Cancel', 'vms-elements-fastspring-woo-payment-pro' ),
				__( 'Cancel this subscription at the end of the current billing period?', 'vms-elements-fastspring-woo-payment-pro' )
			);
			self::render_action_form(
				$subscription_id,
				'cancel',
				__( 'Cancel now', 'vms-elements-fastspring-woo-payment-pro' ),
				__( 'Cancel this subscription immediately? This cannot be undone.', 'vms-elements-fastspring-woo-payment-pro' ),
				array( 'immediate' => '1' )
			);
		} elseif ( 'paused' === $status ) {
			self::render_action_form(
				$subscription_id,
				'resume',
				__( 'Resume', 'vms-elements-fastspring-woo-payment-pro' ),
				__( 'Resume this subscription?', 'vms-elements-fastspring-woo-payment-pro' )
			);
		} elseif ( in_array( $status, array( 'canceled', 'deactivated' ), true ) ) {
			echo '<span class="vms-efwp-account-subscriptions__muted">' . esc_html__( 'This subscription has ended.', 'vms-elements-fastspring-woo-payment-pro' ) . '</span>';
		} else {
			echo '<span class="vms-efwp-account-subscriptions__muted">' . esc_html__( 'No actions available', 'vms-elements-fastspring-woo-payment-pro' ) . '</span>';
		}
	}

	/**
	 * Output a POST form to pause a subscription.
	 *
	 * @param string $subscription_id Subscription ID.
	 */
	private static function render_pause_form( $subscription_id ) {
		$confirm = __( 'Pause this subscription for the selected number of billing periods?', 'vms-elements-fastspring-woo-payment-pro' );
		?>
		<form method="post" class="vms-efwp-account-subscriptions__action-form vms-efwp-account-subscriptions__pause-form">
			<?php wp_nonce_field( 'vms_efwp_account_sub_action', 'vms_efwp_sub_nonce' ); ?>
			<input type="hidden" name="vms_efwp_sub_action" value="pause" />
			<input type="hidden" name="subscription_id" value="<?php echo esc_attr( $subscription_id ); ?>" />
			<label class="vms-efwp-account-subscriptions__pause-label" for="vms-efwp-pause-<?php echo esc_attr( $subscription_id ); ?>">
				<?php esc_html_e( 'Pause for', 'vms-elements-fastspring-woo-payment-pro' ); ?>
				<select id="vms-efwp-pause-<?php echo esc_attr( $subscription_id ); ?>" name="pause_period_count">
					<?php for ( $i = 1; $i <= 12; $i++ ) : ?>
						<option value="<?php echo esc_attr( (string) $i ); ?>">
							<?php
							echo esc_html(
								sprintf(
									/* translators: %d: number of billing periods */
									_n( '%d period', '%d periods', $i, 'vms-elements-fastspring-woo-payment-pro' ),
									$i
								)
							);
							?>
						</option>
					<?php endfor; ?>
				</select>
			</label>
			<button type="submit" class="woocommerce-button button" onclick="return confirm('<?php echo esc_js( $confirm ); ?>');">
				<?php esc_html_e( 'Pause', 'vms-elements-fastspring-woo-payment-pro' ); ?>
			</button>
		</form>
		<?php
	}

	/**
	 * Output a POST form for a subscription action.
	 *
	 * @param string $subscription_id Subscription ID.
	 * @param string $action          Action key.
	 * @param string $label           Button label.
	 * @param string $confirm         Confirm message.
	 * @param array  $extra_fields      Hidden fields.
	 */
	private static function render_action_form( $subscription_id, $action, $label, $confirm, $extra_fields = array() ) {
		?>
		<form method="post" class="vms-efwp-account-subscriptions__action-form">
			<?php wp_nonce_field( 'vms_efwp_account_sub_action', 'vms_efwp_sub_nonce' ); ?>
			<input type="hidden" name="vms_efwp_sub_action" value="<?php echo esc_attr( $action ); ?>" />
			<input type="hidden" name="subscription_id" value="<?php echo esc_attr( $subscription_id ); ?>" />
			<?php foreach ( $extra_fields as $name => $value ) : ?>
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" />
			<?php endforeach; ?>
			<button type="submit" class="woocommerce-button button" onclick="return confirm('<?php echo esc_js( $confirm ); ?>');">
				<?php echo esc_html( $label ); ?>
			</button>
		</form>
		<?php
	}

	/**
	 * Load paginated subscriptions for the current customer from FastSpring.
	 *
	 * @param int $user_id  User ID.
	 * @param int $page     Page number.
	 * @param int $per_page Items per page.
	 * @return array{rows:array[],total:int}
	 */
	private static function get_customer_subscriptions( $user_id, $page, $per_page ) {
		if ( ! vms_efwp()->settings->has_credentials() ) {
			return array(
				'rows'  => array(),
				'total' => 0,
			);
		}

		$cache_key = self::LIST_TRANSIENT_PREFIX . $user_id;
		$all_rows  = get_transient( $cache_key );
		if ( false === $all_rows || ! is_array( $all_rows ) ) {
			$all_rows = self::build_subscription_rows_from_api( $user_id );
			set_transient( $cache_key, $all_rows, 5 * MINUTE_IN_SECONDS );
		}

		$offset = max( 0, ( $page - 1 ) * $per_page );

		return array(
			'rows'  => array_slice( $all_rows, $offset, $per_page ),
			'total' => count( $all_rows ),
		);
	}

	/**
	 * Fetch all subscriptions for a customer from FastSpring account IDs.
	 *
	 * @param int $user_id User ID.
	 * @return array[]
	 */
	private static function build_subscription_rows_from_api( $user_id ) {
		$api             = vms_efwp()->api;
		$is_test_default = vms_efwp()->settings->is_sandbox();
		$account_ids     = self::resolve_account_ids_for_user( $user_id );
		$seen            = array();
		$rows            = array();

		foreach ( $account_ids as $account_id ) {
			$subscriptions = $api->list_all_subscriptions_for_account( $account_id );
			foreach ( $subscriptions as $subscription ) {
				if ( ! is_array( $subscription ) ) {
					continue;
				}

				$subscription_id = $subscription['id'] ?? $subscription['subscription'] ?? '';
				if ( ! $subscription_id || isset( $seen[ $subscription_id ] ) ) {
					continue;
				}

				$seen[ $subscription_id ] = true;
				$is_test                  = isset( $subscription['live'] ) ? ! $subscription['live'] : $is_test_default;
				VMS_EFWP_Data_Store::upsert_subscription( $subscription, $is_test, $user_id );
				$rows[] = self::map_subscription_to_row( $subscription, $is_test_default );
			}
		}

		$local = VMS_EFWP_Data_Store::get_subscriptions_for_user(
			$user_id,
			array(
				'per_page' => 500,
				'page'     => 1,
			)
		);
		foreach ( (array) $local['rows'] as $row ) {
			$subscription_id = $row['fs_subscription_id'] ?? '';
			if ( ! $subscription_id || isset( $seen[ $subscription_id ] ) ) {
				continue;
			}
			$seen[ $subscription_id ] = true;
			$rows[]                   = $row;
		}

		usort(
			$rows,
			static function ( $a, $b ) {
				$a_time = ! empty( $a['next_charge'] ) ? strtotime( $a['next_charge'] ) : 0;
				$b_time = ! empty( $b['next_charge'] ) ? strtotime( $b['next_charge'] ) : 0;
				if ( $a_time === $b_time ) {
					return strcmp( (string) $b['fs_subscription_id'], (string) $a['fs_subscription_id'] );
				}
				return $b_time <=> $a_time;
			}
		);

		return $rows;
	}

	/**
	 * Resolve every FastSpring account ID linked to a WordPress user.
	 *
	 * @param int $user_id User ID.
	 * @return string[]
	 */
	private static function resolve_account_ids_for_user( $user_id ) {
		$user_id = (int) $user_id;
		$ids     = VMS_EFWP_Data_Store::get_account_ids_for_user( $user_id );

		if ( function_exists( 'wc_get_orders' ) ) {
			$order_ids = wc_get_orders(
				array(
					'customer_id' => $user_id,
					'limit'       => 100,
					'return'      => 'ids',
				)
			);

			foreach ( (array) $order_ids as $order_id ) {
				$order = wc_get_order( $order_id );
				if ( ! $order ) {
					continue;
				}

				$account_id = (string) $order->get_meta( '_vms_efwp_fs_account_id' );
				if ( $account_id ) {
					$ids[] = $account_id;
				}
			}
		}

		if ( vms_efwp()->settings->has_credentials() ) {
			$emails = self::get_user_emails( $user_id );
			foreach ( $emails as $email ) {
				$ids = array_merge( $ids, vms_efwp()->api->get_account_ids_by_email( $email ) );
			}
			$ids = array_merge( $ids, VMS_EFWP_Data_Store::get_account_ids_for_emails( $emails ) );
		}

		return array_values( array_unique( array_filter( $ids ) ) );
	}

	/**
	 * Map a FastSpring subscription payload to a stored-row shape.
	 *
	 * @param array $subscription      Subscription payload.
	 * @param bool  $is_test_default Default test flag.
	 * @return array
	 */
	private static function map_subscription_to_row( $subscription, $is_test_default ) {
		$state = $subscription['state'] ?? $subscription['status'] ?? 'active';

		return array(
			'fs_subscription_id' => $subscription['id'] ?? $subscription['subscription'] ?? '',
			'email'              => VMS_EFWP_Data_Store::resolve_subscription_email( $subscription ),
			'product'            => $subscription['product'] ?? '',
			'currency'           => $subscription['currency'] ?? '',
			'price'              => isset( $subscription['price'] ) ? (float) $subscription['price'] : 0,
			'interval_unit'      => $subscription['intervalUnit'] ?? '',
			'interval_length'    => isset( $subscription['intervalLength'] ) ? (int) $subscription['intervalLength'] : 1,
			'status'             => sanitize_key( (string) $state ),
			'next_charge'        => VMS_EFWP_Data_Store::parse_payload_datetime( $subscription, 'nextChargeDate', array( 'next' ) ),
			'is_test'            => isset( $subscription['live'] ) ? ( $subscription['live'] ? 0 : 1 ) : ( $is_test_default ? 1 : 0 ),
		);
	}

	/**
	 * Determine whether the current request is on the subscriptions endpoint.
	 *
	 * @return bool
	 */
	private static function is_subscriptions_endpoint() {
		global $wp;

		return isset( $wp->query_vars[ self::ENDPOINT ] );
	}

	/**
	 * Build the My Account subscriptions endpoint URL.
	 *
	 * @param int $page Page number.
	 * @return string
	 */
	private static function get_endpoint_url( $page = 1 ) {
		return wc_get_endpoint_url( self::ENDPOINT, $page > 1 ? (string) $page : '', wc_get_page_permalink( 'myaccount' ) );
	}

	/**
	 * Get the primary customer email for a user.
	 *
	 * @param int $user_id User ID.
	 * @return string
	 */
	private static function get_customer_email( $user_id ) {
		$user = get_user_by( 'id', $user_id );
		if ( ! $user || ! $user->user_email ) {
			return '';
		}

		if ( function_exists( 'wc_get_customer' ) ) {
			$customer = wc_get_customer( $user_id );
			if ( $customer ) {
				$billing = $customer->get_billing_email();
				if ( $billing && is_email( $billing ) ) {
					return sanitize_email( $billing );
				}
			}
		}

		return sanitize_email( $user->user_email );
	}

	/**
	 * Collect normalized email addresses associated with a user.
	 *
	 * @param int    $user_id User ID.
	 * @param string $primary Optional primary email already resolved.
	 * @return string[]
	 */
	private static function get_user_emails( $user_id, $primary = '' ) {
		$emails = array();

		if ( $primary && is_email( $primary ) ) {
			$emails[] = strtolower( $primary );
		}

		$user = get_user_by( 'id', $user_id );
		if ( $user && is_email( $user->user_email ) ) {
			$emails[] = strtolower( $user->user_email );
		}

		if ( function_exists( 'wc_get_customer' ) ) {
			$customer = wc_get_customer( $user_id );
			if ( $customer ) {
				$billing = $customer->get_billing_email();
				if ( $billing && is_email( $billing ) ) {
					$emails[] = strtolower( $billing );
				}
			}
		}

		return array_values( array_unique( array_filter( $emails ) ) );
	}

	/**
	 * Check whether an email belongs to the given user.
	 *
	 * @param string $email   Email to compare.
	 * @param int    $user_id User ID.
	 * @param string $primary Optional primary email.
	 * @return bool
	 */
	private static function email_matches_user( $email, $user_id, $primary = '' ) {
		$email = strtolower( trim( (string) $email ) );
		if ( ! $email || ! is_email( $email ) ) {
			return false;
		}

		return in_array( $email, self::get_user_emails( $user_id, $primary ), true );
	}

	/**
	 * Verify that the logged-in user owns a subscription.
	 *
	 * @param string $subscription_id FastSpring subscription ID.
	 * @param int    $user_id         Optional user ID.
	 * @return bool
	 */
	public static function user_owns_subscription( $subscription_id, $user_id = 0 ) {
		$user_id = $user_id ? (int) $user_id : get_current_user_id();
		if ( ! $user_id || ! $subscription_id ) {
			return false;
		}

		$row = VMS_EFWP_Data_Store::get_subscription_by_fs_id( $subscription_id );
		if ( $row ) {
			if ( ! empty( $row['wc_user_id'] ) && (int) $row['wc_user_id'] === $user_id ) {
				return true;
			}
			if ( self::email_matches_user( $row['email'], $user_id ) ) {
				return true;
			}
		}

		if ( ! vms_efwp()->settings->has_credentials() ) {
			return false;
		}

		$response = vms_efwp()->api->get_subscription( $subscription_id );
		if ( is_wp_error( $response ) ) {
			return false;
		}

		$subscription = vms_efwp()->api->parse_subscription( $response );
		if ( is_wp_error( $subscription ) ) {
			return false;
		}

		$owner_id = VMS_EFWP_Data_Store::resolve_wc_user_id_from_payload( $subscription );
		if ( $owner_id && $owner_id === $user_id ) {
			return true;
		}

		$account_id = VMS_EFWP_Data_Store::extract_account_id_from_payload( $subscription );
		if ( $account_id ) {
			$user_accounts = self::resolve_account_ids_for_user( $user_id );
			if ( in_array( $account_id, $user_accounts, true ) ) {
				return true;
			}
		}

		$sub_email = VMS_EFWP_Data_Store::resolve_subscription_email( $subscription );
		return self::email_matches_user( $sub_email, $user_id );
	}
}
