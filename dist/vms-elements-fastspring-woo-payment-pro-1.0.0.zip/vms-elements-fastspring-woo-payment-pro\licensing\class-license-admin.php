<?php
/**
 * License admin page + activation/deactivation handler.
 *
 * Wires the `License` sub-menu, renders {@see templates/license-settings.php},
 * and handles activate / deactivate form submissions.
 *
 * @package VMS_EFWP_Pro
 */

namespace VMS_EFWP_Pro\Licensing;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/class-license-manager.php';

/**
 * Admin UI + form handler for the License page.
 */
class License_Admin {

	const PAGE_SLUG  = 'vms-efwp-pro-license';
	const NONCE_NAME = 'vms_efwp_pro_license_nonce';
	const NOTICE_KEY = 'vms_efwp_pro_license_notice';

	/**
	 * @var License_Manager
	 */
	private $manager;

	public function __construct() {
		$this->manager = License_Manager::instance();
		add_action( 'admin_menu', array( $this, 'register_menu' ), 100 );
		add_action( 'admin_post_vms_efwp_pro_license_save', array( $this, 'handle_post' ) );
		add_action( 'admin_notices', array( $this, 'maybe_render_notice' ) );
	}

	/**
	 * Hook into the existing top-level admin menu.
	 *
	 * The License page is only registered when the Pro plugin is installed and
	 * active — the free plugin alone has nothing to license, so showing a
	 * "License" menu would be misleading.
	 */
	public function register_menu(): void {
		if ( ! function_exists( 'vms_efwp' ) ) {
			return;
		}

		add_submenu_page(
			'vms-efwp',
			__( 'Pro License', 'vms-elements-fastspring-woo-payment-pro' ),
			__( 'Pro License', 'vms-elements-fastspring-woo-payment-pro' ),
			'manage_options',
			self::PAGE_SLUG,
			array( $this, 'render_page' )
		);
	}

	/**
	 * Render the License settings template.
	 */
	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$manager     = $this->manager;
		$info        = $manager->get_info();
		$is_active   = $manager->is_pro_active();
		$status      = $manager->status_label();
		$action_url  = admin_url( 'admin-post.php' );
		$nonce_field = wp_nonce_field( self::NONCE_NAME, self::NONCE_NAME, true, false );
		$upgrade_url = defined( 'VMS_EFWP_PRO_UPGRADE_URL' ) ? VMS_EFWP_PRO_UPGRADE_URL : 'https://vmselements.com/product/vms-elements-fastspring-woo-payment-pro';
		include VMS_EFWP_PRO_PATH . 'templates/license-settings.php';
	}

	/**
	 * Handle activate / deactivate form submissions.
	 */
	public function handle_post(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to do this.', 'vms-elements-fastspring-woo-payment-pro' ) );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce is checked immediately below.
		$nonce = isset( $_POST[ self::NONCE_NAME ] ) ? sanitize_text_field( wp_unslash( (string) $_POST[ self::NONCE_NAME ] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, self::NONCE_NAME ) ) {
			wp_die( esc_html__( 'Security check failed.', 'vms-elements-fastspring-woo-payment-pro' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		$action = isset( $_POST['license_action'] ) ? sanitize_key( wp_unslash( (string) $_POST['license_action'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		$license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['license_key'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		$email = isset( $_POST['license_email'] ) ? sanitize_email( wp_unslash( (string) $_POST['license_email'] ) ) : '';

		$result = array(
			'success' => false,
			'message' => __( 'Unknown action.', 'vms-elements-fastspring-woo-payment-pro' ),
		);

		switch ( $action ) {
			case 'activate':
				$result = $this->manager->activate( $license_key, $email );
				break;
			case 'deactivate':
				$result = $this->manager->deactivate();
				break;
			case 'verify':
				$result = $this->manager->verify();
				break;
		}

		$notice_type = 'success';
		if ( empty( $result['success'] ) ) {
			$notice_type = ! empty( $result['blocked'] ) ? 'error' : 'error';
		} elseif ( ! empty( $result['throttled'] ) ) {
			$notice_type = 'warning';
		}

		set_transient(
			self::NOTICE_KEY,
			array(
				'type'    => $notice_type,
				'message' => (string) $result['message'],
			),
			60
		);

		$redirect = add_query_arg(
			array(
				'page'    => self::PAGE_SLUG,
				'updated' => $result['success'] ? '1' : '0',
			),
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Render the one-shot admin notice after a POST.
	 */
	public function maybe_render_notice(): void {
		$notice = get_transient( self::NOTICE_KEY );
		if ( ! is_array( $notice ) || empty( $notice['message'] ) ) {
			return;
		}
		delete_transient( self::NOTICE_KEY );
		$type    = (string) ( $notice['type'] ?? 'error' );
		$class   = 'success' === $type ? 'notice-success' : ( 'warning' === $type ? 'notice-warning' : 'notice-error' );
		$message = (string) $notice['message'];
		printf(
			'<div class="notice %1$s is-dismissible"><p>%2$s</p></div>',
			esc_attr( $class ),
			esc_html( $message )
		);
	}
}
