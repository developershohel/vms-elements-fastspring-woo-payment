=== VMS Elements Fastspring Woo Payment Pro ===
Contributors: vmsuniverse
Tags: woocommerce, fastspring, payment, subscriptions, pro
Requires at least: 6.0
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Pro add-on for VMS Elements Fastspring Woo Payment. Requires the free plugin.

== Description ==

Unlock the full FastSpring operations hub:

* Analytics dashboard with revenue charts and MRR
* Subscription products and customer self-service
* Popup overlay checkout and WooCommerce Blocks
* Shortcodes, checkout links, and payment success pages
* Full FastSpring API admin toolkit

Purchase at [VMS Elements](https://vmselements.com/product/vms-elements-fastspring-woo-payment-pro).

== Installation ==

1. Install and activate **VMS Elements Fastspring Woo Payment** (free) from WordPress.org.
2. Upload and activate this Pro add-on.
3. Go to **FastSpring → Pro License** and enter your license key.

== Changelog ==

= 1.0.0 =
* Initial Pro add-on release with EDD Software Licensing support.
