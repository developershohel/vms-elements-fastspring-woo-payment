<?php
/**
 * License settings page (Pro plugin).
 *
 * @package VMS_EFWP_Pro
 *
 * @var \VMS_EFWP_Pro\Licensing\License_Manager $manager
 * @var object|null                                 $info
 * @var bool                                        $is_active
 * @var string                                      $status
 * @var string                                      $action_url
 * @var string                                      $nonce_field
 * @var string                                      $upgrade_url
 */

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Locals come from License_Admin::render_page().

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$existing_key   = is_object( $info ) && ! empty( $info->license_key ) ? (string) $info->license_key : '';
$license_title  = is_object( $info ) && ! empty( $info->license_title ) ? (string) $info->license_title : '';
$expire         = is_object( $info ) && ! empty( $info->expire_date ) ? (string) $info->expire_date : '';
$support_end    = is_object( $info ) && ! empty( $info->support_end ) ? (string) $info->support_end : '';
$renew_link     = is_object( $info ) && ! empty( $info->renew_link ) ? (string) $info->renew_link : '';
$domains_used   = is_object( $info ) && isset( $info->domains_used ) ? (int) $info->domains_used : 0;
$domains_limit  = is_object( $info ) && isset( $info->domains_limit ) ? (int) $info->domains_limit : 0;
$default_email  = (string) get_option( 'admin_email', '' );
?>
<div class="wrap vms-efwp-wrap vms-efwp-pro-license">
	<div class="vms-efwp-header">
		<div class="vms-efwp-header__title">
			<h1><?php esc_html_e( 'Pro License', 'vms-elements-fastspring-woo-payment-pro' ); ?></h1>
			<p><?php esc_html_e( 'Activate your VMS Elements Fastspring Woo Payment Pro license to unlock advanced features.', 'vms-elements-fastspring-woo-payment-pro' ); ?></p>
		</div>
	</div>

	<div class="vms-license-card" style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:24px;max-width:780px;margin-top:16px;">
		<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
			<div>
				<h2 style="margin:0 0 4px;font-size:18px;">
					<?php esc_html_e( 'License status', 'vms-elements-fastspring-woo-payment-pro' ); ?>
				</h2>
				<p style="margin:0;color:#646970;">
					<?php if ( $is_active ) : ?>
						<span class="dashicons dashicons-yes-alt" style="color:#00a32a;"></span>
						<strong><?php echo esc_html( $status ); ?></strong>
					<?php else : ?>
						<span class="dashicons dashicons-lock" style="color:#d63638;"></span>
						<strong><?php echo esc_html( $status ); ?></strong> —
						<?php esc_html_e( 'enter your license key below to unlock Pro features.', 'vms-elements-fastspring-woo-payment-pro' ); ?>
					<?php endif; ?>
				</p>
			</div>
			<?php if ( ! $is_active ) : ?>
				<a href="<?php echo esc_url( $upgrade_url ); ?>" target="_blank" class="button button-primary">
					<?php esc_html_e( 'Get a license', 'vms-elements-fastspring-woo-payment-pro' ); ?>
				</a>
			<?php endif; ?>
		</div>

		<?php if ( $is_active && is_object( $info ) ) : ?>
			<table class="widefat striped" style="margin-top:18px;">
				<tbody>
					<?php if ( '' !== $license_title ) : ?>
						<tr>
							<th style="width:180px;"><?php esc_html_e( 'Product', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
							<td><?php echo esc_html( $license_title ); ?></td>
						</tr>
					<?php endif; ?>
					<tr>
						<th><?php esc_html_e( 'Expires', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
						<td><?php echo esc_html( '' !== $expire ? $expire : __( 'Unlimited', 'vms-elements-fastspring-woo-payment-pro' ) ); ?></td>
					</tr>
					<?php if ( '' !== $support_end ) : ?>
						<tr>
							<th><?php esc_html_e( 'Support until', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
							<td><?php echo esc_html( $support_end ); ?></td>
						</tr>
					<?php endif; ?>
					<?php if ( $domains_limit > 0 ) : ?>
						<tr>
							<th><?php esc_html_e( 'Domain slots', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
							<td>
								<?php
								echo esc_html(
									sprintf(
										/* translators: 1: used count, 2: total slots */
										__( '%1$d of %2$d used', 'vms-elements-fastspring-woo-payment-pro' ),
										$domains_used,
										$domains_limit
									)
								);
								?>
							</td>
						</tr>
					<?php endif; ?>
					<?php if ( '' !== $renew_link ) : ?>
						<tr>
							<th><?php esc_html_e( 'Renew', 'vms-elements-fastspring-woo-payment-pro' ); ?></th>
							<td>
								<a href="<?php echo esc_url( $renew_link ); ?>" target="_blank">
									<?php esc_html_e( 'Renew this license', 'vms-elements-fastspring-woo-payment-pro' ); ?>
								</a>
							</td>
						</tr>
					<?php endif; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>

	<form method="post" action="<?php echo esc_url( $action_url ); ?>" class="vms-license-form" style="margin-top:24px;max-width:780px;">
		<?php echo $nonce_field; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_nonce_field already escapes. ?>
		<input type="hidden" name="action" value="vms_efwp_pro_license_save" />

		<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:24px;">
			<table class="form-table" role="presentation">
				<tbody>
					<tr>
						<th scope="row">
							<label for="license_key"><?php esc_html_e( 'License key', 'vms-elements-fastspring-woo-payment-pro' ); ?></label>
						</th>
						<td>
							<input
								type="text"
								id="license_key"
								name="license_key"
								class="regular-text code"
								value="<?php echo esc_attr( $existing_key ); ?>"
								<?php echo $is_active ? 'readonly' : ''; ?>
								placeholder="ABCD-1234-WXYZ-7890"
							/>
							<p class="description">
								<?php esc_html_e( 'Paste the license key from your account at vmselements.com.', 'vms-elements-fastspring-woo-payment-pro' ); ?>
							</p>
						</td>
					</tr>
					<tr>
						<th scope="row">
							<label for="license_email"><?php esc_html_e( 'Email', 'vms-elements-fastspring-woo-payment-pro' ); ?></label>
						</th>
						<td>
							<input
								type="email"
								id="license_email"
								name="license_email"
								class="regular-text"
								value="<?php echo esc_attr( $default_email ); ?>"
								<?php echo $is_active ? 'readonly' : ''; ?>
							/>
							<p class="description">
								<?php esc_html_e( 'The email tied to your purchase. Defaults to the site admin email.', 'vms-elements-fastspring-woo-payment-pro' ); ?>
							</p>
						</td>
					</tr>
				</tbody>
			</table>

			<p>
				<?php if ( $is_active ) : ?>
					<button type="submit" name="license_action" value="verify" class="button">
						<span class="dashicons dashicons-update" style="vertical-align:text-bottom;"></span>
						<?php esc_html_e( 'Re-verify', 'vms-elements-fastspring-woo-payment-pro' ); ?>
					</button>
					<button type="submit" name="license_action" value="deactivate" class="button button-secondary">
						<?php esc_html_e( 'Deactivate license', 'vms-elements-fastspring-woo-payment-pro' ); ?>
					</button>
				<?php else : ?>
					<button type="submit" name="license_action" value="activate" class="button button-primary button-large">
						<?php esc_html_e( 'Activate license', 'vms-elements-fastspring-woo-payment-pro' ); ?>
					</button>
				<?php endif; ?>
			</p>
		</div>
	</form>

	<p style="max-width:780px;margin-top:16px;color:#646970;font-size:12px;">
		<?php
		echo wp_kses(
			__( 'Licenses are managed at <code>vmselements.com</code>. Activation binds this site hostname to your key. Failed activation attempts are counted; after 5 failures the license is blocked until support clears it. The plugin re-validates every 5 minutes.', 'vms-elements-fastspring-woo-payment-pro' ),
			array( 'code' => array() )
		);
		?>
	</p>
</div>
