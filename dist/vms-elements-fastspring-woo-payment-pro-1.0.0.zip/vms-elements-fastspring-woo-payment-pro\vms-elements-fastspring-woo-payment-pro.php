<?php
/**
 * Plugin Name:       VMS Elements Fastspring Woo Payment Pro
 * Plugin URI:        https://vmselements.com/product/vms-elements-fastspring-woo-payment-pro
 * Description:       Pro add-on for VMS Elements Fastspring Woo Payment — analytics, subscriptions, catalog tools, overlay checkout, and more.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Requires Plugins:  vms-elements-fastspring-woo-payment
 * Author:            VMS Elements
 * Author URI:        https://vmselements.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       vms-elements-fastspring-woo-payment-pro
 * WC requires at least: 7.0
 * WC tested up to:   9.0
 *
 * @package VMS_EFWP_Pro
 */

defined( 'ABSPATH' ) || exit;

define( 'VMS_EFWP_PRO_VERSION', '1.0.0' );
define( 'VMS_EFWP_PRO_FILE', __FILE__ );
define( 'VMS_EFWP_PRO_PATH', plugin_dir_path( __FILE__ ) );
define( 'VMS_EFWP_PRO_URL', plugin_dir_url( __FILE__ ) );
define( 'VMS_EFWP_PRO_BASENAME', plugin_basename( __FILE__ ) );

/**
 * License API — VMS Elements (vmselements.com). Pro plugin only; free has no license code.
 */
if ( ! defined( 'VMS_EFWP_PRO_LICENSE_API' ) ) {
	define( 'VMS_EFWP_PRO_LICENSE_API', 'https://vmselements.com/api/licenses' );
}
if ( ! defined( 'VMS_EFWP_PRO_LICENSE_LEGACY_KEY' ) ) {
	define( 'VMS_EFWP_PRO_LICENSE_LEGACY_KEY', 'Vms5pAn2026PrOK1' );
}
if ( ! defined( 'VMS_EFWP_PRO_LICENSE_STORAGE_SALT' ) ) {
	define( 'VMS_EFWP_PRO_LICENSE_STORAGE_SALT', 'vms_license_api_v1' );
}
if ( ! defined( 'VMS_EFWP_PRO_PRODUCT_ID' ) ) {
	define( 'VMS_EFWP_PRO_PRODUCT_ID', 'vms-elements-fastspring-woo-payment-pro' );
}
if ( ! defined( 'VMS_EFWP_PRO_PRODUCT_BASE' ) ) {
	define( 'VMS_EFWP_PRO_PRODUCT_BASE', 'vms_efwp_pro_options' );
}
if ( ! defined( 'VMS_EFWP_PRO_UPGRADE_URL' ) ) {
	define( 'VMS_EFWP_PRO_UPGRADE_URL', 'https://vmselements.com/product/vms-elements-fastspring-woo-payment-pro' );
}

require_once VMS_EFWP_PRO_PATH . 'includes/class-vms-efwp-pro.php';

register_activation_hook( __FILE__, array( 'VMS_EFWP_Pro', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'VMS_EFWP_Pro', 'deactivate' ) );

add_action( 'plugins_loaded', array( 'VMS_EFWP_Pro', 'init' ), 5 );
